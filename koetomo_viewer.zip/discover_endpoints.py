"""
koetomo.fun のAPIエンドポイントを自動探索するツール。

使い方:
  1. python discover_endpoints.py を実行（Chromeが開く）
  2. すでにログイン済みならそのまま、未ログインならログインする
  3. TL（タイムライン）、プロフィール画面、投稿など、知りたい機能を
     実際に画面上で普通に操作する
  4. a.koetomo.fun/api/ への通信をすべて検知し、
     endpoint_report.jsonl に「メソッド・URL・ステータス・レスポンス本文」を記録する
  5. 「停止して保存」を押すとログを確定し、endpoint_report.jsonl の中身を
     Claudeに貼れば、その機能をアプリに追加できる

token_fetcher.py と同じくCDP直結方式。selenium/selenium-wire不要。
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import scrolledtext, ttk

import requests

PROFILE_DIR = r"C:\Temp\ChromeProfile_Koetomo"
DEBUG_PORT = 9334  # token_fetcher(9333)/AutoJoin(9222)と衝突しないよう別ポート
TARGET_HOST = "a.koetomo.fun"
REPORT_PATH = Path(__file__).parent / "endpoint_report.jsonl"

CHROME_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
]

logging.basicConfig(
    filename=Path(__file__).parent / "discover_endpoints.log",
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    encoding="utf-8",
)
logger = logging.getLogger(__name__)


def find_chrome() -> str:
    for path in CHROME_CANDIDATES:
        if Path(path).exists():
            return path
    raise FileNotFoundError("chrome.exe が見つかりませんでした。CHROME_CANDIDATES を確認してください。")


class DiscoverApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("koetomo API自動探索ツール")
        self.geometry("680x460")

        self.worker: threading.Thread | None = None
        self.chrome_proc: subprocess.Popen | None = None
        self.stop_flag = threading.Event()
        self.captured_count = 0

        frame = ttk.Frame(self, padding=10)
        frame.pack(fill="both", expand=True)

        ttk.Label(
            frame,
            text=(
                "「開始」でChromeが開きます。TL・プロフィール・投稿など、\n"
                "調べたい機能を実際に画面で操作してください。\n"
                "a.koetomo.fun/api/ への通信を自動で記録します。\n"
                "操作し終わったら「停止して保存」を押してください。"
            ),
            wraplength=640,
            justify="left",
        ).pack(anchor="w", pady=(0, 8))

        btn_row = ttk.Frame(frame)
        btn_row.pack(anchor="w")
        self.start_btn = ttk.Button(btn_row, text="開始", command=self.start)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(btn_row, text="停止して保存", command=self.stop, state="disabled")
        self.stop_btn.pack(side="left", padx=6)

        self.count_var = tk.StringVar(value="検知件数: 0")
        ttk.Label(frame, textvariable=self.count_var, foreground="#555").pack(anchor="w", pady=(4, 0))

        self.log_widget = scrolledtext.ScrolledText(frame, height=18, state="disabled")
        self.log_widget.pack(fill="both", expand=True, pady=(8, 0))

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def log_line(self, text: str) -> None:
        logger.info(text)

        def _append() -> None:
            self.log_widget.config(state="normal")
            self.log_widget.insert("end", text + "\n")
            self.log_widget.see("end")
            self.log_widget.config(state="disabled")
        self.after(0, _append)

    def start(self) -> None:
        if self.worker and self.worker.is_alive():
            return
        self.stop_flag.clear()
        self.captured_count = 0
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.worker = threading.Thread(target=self._run, daemon=True)
        self.worker.start()

    def stop(self) -> None:
        self.stop_flag.set()
        self.stop_btn.config(state="disabled")

    def _run(self) -> None:
        try:
            self._watch()
        except Exception as e:  # noqa: BLE001
            logger.exception("discover failed")
            self.log_line(f"エラー: {type(e).__name__}: {e}（詳細は discover_endpoints.log 参照）")
        finally:
            self.after(0, lambda: self.start_btn.config(state="normal"))
            self.after(0, lambda: self.stop_btn.config(state="disabled"))

    def _launch_chrome(self) -> None:
        chrome_path = find_chrome()
        Path(PROFILE_DIR).mkdir(parents=True, exist_ok=True)
        args = [
            chrome_path,
            f"--remote-debugging-port={DEBUG_PORT}",
            f"--user-data-dir={PROFILE_DIR}",
            "--remote-allow-origins=*",
            "--no-first-run",
            "--no-default-browser-check",
            "https://koetomo.fun",
        ]
        self.log_line(f"Chromeを起動しています… ({chrome_path})")
        self.chrome_proc = subprocess.Popen(args)
        for _ in range(30):
            try:
                requests.get(f"http://127.0.0.1:{DEBUG_PORT}/json/version", timeout=1)
                return
            except requests.RequestException:
                time.sleep(0.5)
        raise RuntimeError("Chromeのデバッグポートに接続できませんでした")

    def _get_page_ws_url(self) -> str:
        resp = requests.get(f"http://127.0.0.1:{DEBUG_PORT}/json", timeout=5)
        targets = resp.json()
        for t in targets:
            if t.get("type") == "page" and "koetomo" in t.get("url", ""):
                return t["webSocketDebuggerUrl"]
        for t in targets:
            if t.get("type") == "page":
                return t["webSocketDebuggerUrl"]
        raise RuntimeError("対象タブが見つかりませんでした")

    def _watch(self) -> None:
        import websocket  # websocket-client

        self._launch_chrome()
        time.sleep(1.5)
        ws_url = self._get_page_ws_url()
        self.log_line("DevTools Protocolに接続しました。記録を開始します…")

        ws = websocket.create_connection(ws_url, timeout=5)
        ws.settimeout(1.0)

        next_id = 1

        def send(method: str, params: dict | None = None) -> int:
            nonlocal next_id
            cmd_id = next_id
            next_id += 1
            ws.send(json.dumps({"id": cmd_id, "method": method, "params": params or {}}))
            return cmd_id

        send("Network.enable")

        pending_req: dict[str, dict] = {}   # requestId -> {url, method}
        pending_body_cmd: dict[int, dict] = {}  # cmd_id -> {requestId, url, method, status}

        report_file = REPORT_PATH.open("a", encoding="utf-8")
        try:
            while not self.stop_flag.is_set():
                try:
                    raw = ws.recv()
                except Exception:
                    continue

                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    continue

                # コマンドへの応答（getResponseBodyの結果）
                if "id" in msg and msg["id"] in pending_body_cmd:
                    info = pending_body_cmd.pop(msg["id"])
                    body = (msg.get("result", {}) or {}).get("body", "")
                    record = {
                        "method": info["method"],
                        "url": info["url"],
                        "status": info.get("status"),
                        "body": body[:4000],
                    }
                    report_file.write(json.dumps(record, ensure_ascii=False) + "\n")
                    report_file.flush()
                    self.captured_count += 1
                    self.after(0, lambda c=self.captured_count: self.count_var.set(f"検知件数: {c}"))
                    self.log_line(f"[{info.get('status')}] {info['method']} {info['url']}")
                    continue

                method = msg.get("method")
                params = msg.get("params", {})

                if method == "Network.requestWillBeSent":
                    req_id = params.get("requestId")
                    url = params.get("request", {}).get("url", "")
                    http_method = params.get("request", {}).get("method", "GET")
                    if req_id and TARGET_HOST in url:
                        pending_req[req_id] = {"url": url, "method": http_method}

                elif method == "Network.responseReceived":
                    req_id = params.get("requestId")
                    if req_id in pending_req:
                        pending_req[req_id]["status"] = params.get("response", {}).get("status")

                elif method == "Network.loadingFinished":
                    req_id = params.get("requestId")
                    info = pending_req.pop(req_id, None)
                    if info:
                        cmd_id = send("Network.getResponseBody", {"requestId": req_id})
                        pending_body_cmd[cmd_id] = info
        finally:
            report_file.close()
            ws.close()

        self.log_line(f"停止しました。合計 {self.captured_count} 件を {REPORT_PATH.name} に保存しました。")

    def _on_close(self) -> None:
        self.stop_flag.set()
        if self.chrome_proc and self.chrome_proc.poll() is None:
            self.chrome_proc.terminate()
        self.destroy()


if __name__ == "__main__":
    app = DiscoverApp()
    app.mainloop()
