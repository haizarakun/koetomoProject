"""
koetomo.fun の API通信を自動で記録する探索ツール。

Chromeを起動し、a.koetomo.fun 宛のすべてのAPIリクエスト（URL・メソッド・
リクエストヘッダー・レスポンス本文）を記録し続ける。TL・プロフィール・
投稿など、まだ分かっていないエンドポイントを見つけるためのツール。

使い方:
  1. python api_explorer.py を実行
  2. 開いたChromeで koetomo.fun にログインし、TLを見る・プロフィールを開く・
     投稿する、など普段通りに操作する
  3. 「記録停止」を押す（または5分で自動停止）
  4. api_explorer_log.jsonl が生成されるので、その中身を貼ってもらえれば
     エンドポイントを実装する

依存: requests, websocket-client
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import threading
import time
import tkinter as tk
from collections import deque
from pathlib import Path
from tkinter import scrolledtext, ttk

import requests

PROFILE_DIR = r"C:\Temp\ChromeProfile_Koetomo"
DEBUG_PORT = 9334  # token_fetcher(9333) / AutoJoin(9222) と衝突しないポート
TARGET_URL_PART = "a.koetomo.fun/api"
LOG_JSONL_PATH = Path(__file__).parent / "api_explorer_log.jsonl"

CHROME_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
]

logging.basicConfig(
    filename=Path(__file__).parent / "api_explorer.log",
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    encoding="utf-8",
)
logger = logging.getLogger(__name__)


def find_chrome() -> str:
    for path in CHROME_CANDIDATES:
        if Path(path).exists():
            return path
    raise FileNotFoundError("chrome.exe が見つかりません。CHROME_CANDIDATES を確認してください。")


class CDPConn:
    """Chrome DevTools Protocolへの薄い同期ラッパー。"""

    def __init__(self, ws_url: str):
        import websocket
        self.ws = websocket.create_connection(ws_url, timeout=10)
        self.ws.settimeout(0.5)
        self._id = 0
        self._pending_events: deque = deque()

    def _send(self, method: str, params: dict | None = None) -> int:
        self._id += 1
        self.ws.send(json.dumps({"id": self._id, "method": method, "params": params or {}}))
        return self._id

    def send_and_wait(self, method: str, params: dict | None = None, timeout: float = 3.0) -> dict | None:
        msg_id = self._send(method, params)
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                raw = self.ws.recv()
            except Exception:
                continue
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if msg.get("id") == msg_id:
                return msg.get("result")
            self._pending_events.append(msg)
        return None

    def poll_events(self) -> list[dict]:
        events = list(self._pending_events)
        self._pending_events.clear()
        while True:
            try:
                raw = self.ws.recv()
            except Exception:
                break
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if "id" not in msg:
                events.append(msg)
        return events

    def close(self) -> None:
        try:
            self.ws.close()
        except Exception:
            pass


class ExplorerApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("koetomo API探索ツール")
        self.geometry("640x420")

        self.worker: threading.Thread | None = None
        self.chrome_proc: subprocess.Popen | None = None
        self.stop_flag = threading.Event()
        self.record_count = 0

        frame = ttk.Frame(self, padding=10)
        frame.pack(fill="both", expand=True)

        ttk.Label(
            frame,
            text=(
                "「記録開始」でChromeが開きます。ログインし、\n"
                "TLを見る・プロフィールを開く・投稿する、など普段通り操作してください。\n"
                f"通信は {LOG_JSONL_PATH.name} に自動で書き出されます。"
            ),
            wraplength=600,
            justify="left",
        ).pack(anchor="w", pady=(0, 8))

        btns = ttk.Frame(frame)
        btns.pack(anchor="w")
        self.start_btn = ttk.Button(btns, text="記録開始", command=self.start)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(btns, text="記録停止", command=self.stop, state="disabled")
        self.stop_btn.pack(side="left", padx=6)

        self.log_widget = scrolledtext.ScrolledText(frame, height=18, state="disabled")
        self.log_widget.pack(fill="both", expand=True, pady=(8, 0))

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def log_line(self, text: str) -> None:
        logger.info(text)

        def _append() -> None:
            self.log_widget.config(state="normal")
            self.log_widget.insert("end", text + "\n")
            self.log_widget.see("end")
            self.log_widget.config(state="disabled")
        self.after(0, _append)

    def start(self) -> None:
        if self.worker and self.worker.is_alive():
            return
        self.stop_flag.clear()
        self.record_count = 0
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.worker = threading.Thread(target=self._run, daemon=True)
        self.worker.start()

    def stop(self) -> None:
        self.stop_flag.set()
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")

    def _run(self) -> None:
        try:
            self._explore()
        except Exception as e:  # noqa: BLE001
            logger.exception("explore failed")
            self.log_line(f"エラー: {type(e).__name__}: {e}（詳細は api_explorer.log 参照）")
        finally:
            self.after(0, lambda: (self.start_btn.config(state="normal"), self.stop_btn.config(state="disabled")))

    def _launch_chrome(self) -> None:
        chrome_path = find_chrome()
        Path(PROFILE_DIR).mkdir(parents=True, exist_ok=True)
        args = [
            chrome_path,
            f"--remote-debugging-port={DEBUG_PORT}",
            f"--user-data-dir={PROFILE_DIR}",
            "--remote-allow-origins=*",
            "--no-first-run",
            "--no-default-browser-check",
            "https://koetomo.fun",
        ]
        self.log_line(f"Chromeを起動しています… ({chrome_path})")
        self.chrome_proc = subprocess.Popen(args)
        for _ in range(30):
            try:
                requests.get(f"http://127.0.0.1:{DEBUG_PORT}/json/version", timeout=1)
                return
            except requests.RequestException:
                time.sleep(0.5)
        raise RuntimeError("Chromeのデバッグポートに接続できませんでした")

    def _get_page_ws_url(self) -> str:
        resp = requests.get(f"http://127.0.0.1:{DEBUG_PORT}/json", timeout=5)
        targets = resp.json()
        for t in targets:
            if t.get("type") == "page" and "koetomo" in t.get("url", ""):
                return t["webSocketDebuggerUrl"]
        for t in targets:
            if t.get("type") == "page":
                return t["webSocketDebuggerUrl"]
        raise RuntimeError("対象タブが見つかりませんでした")

    def _explore(self) -> None:
        self._launch_chrome()
        time.sleep(1.5)
        ws_url = self._get_page_ws_url()
        conn = CDPConn(ws_url)
        conn.send_and_wait("Network.enable")
        self.log_line("記録中… ブラウザでTL・プロフィール・投稿などを操作してください。")

        pending: dict[str, dict] = {}
        deadline = time.time() + 300  # 最長5分

        with LOG_JSONL_PATH.open("a", encoding="utf-8") as out:
            while not self.stop_flag.is_set() and time.time() < deadline:
                for msg in conn.poll_events():
                    method = msg.get("method")
                    params = msg.get("params", {})

                    if method == "Network.requestWillBeSent":
                        req_id = params.get("requestId")
                        url = params.get("request", {}).get("url", "")
                        if TARGET_URL_PART in url:
                            pending[req_id] = {
                                "url": url,
                                "method": params.get("request", {}).get("method", ""),
                            }

                    elif method == "Network.requestWillBeSentExtraInfo":
                        req_id = params.get("requestId")
                        if req_id in pending:
                            pending[req_id]["req_headers"] = params.get("headers", {})

                    elif method == "Network.responseReceived":
                        req_id = params.get("requestId")
                        if req_id in pending:
                            resp = params.get("response", {})
                            pending[req_id]["status"] = resp.get("status")
                            pending[req_id]["mimeType"] = resp.get("mimeType")

                    elif method == "Network.loadingFinished":
                        req_id = params.get("requestId")
                        info = pending.pop(req_id, None)
                        if not info:
                            continue
                        body = ""
                        result = conn.send_and_wait(
                            "Network.getResponseBody", {"requestId": req_id}, timeout=3
                        )
                        if result:
                            body = result.get("body", "")
                        record = {
                            "url": info.get("url"),
                            "method": info.get("method"),
                            "status": info.get("status"),
                            "mimeType": info.get("mimeType"),
                            "request_headers": info.get("req_headers", {}),
                            "response_body": body[:4000],
                        }
                        out.write(json.dumps(record, ensure_ascii=False) + "\n")
                        out.flush()
                        self.record_count += 1
                        self.log_line(f"[{self.record_count}] {record['method']} {record['url']} -> {record['status']}")
                time.sleep(0.2)
        conn.close()
        self.log_line(f"記録終了。合計 {self.record_count} 件を {LOG_JSONL_PATH.name} に保存しました。")

    def _on_close(self) -> None:
        self.stop_flag.set()
        if self.chrome_proc and self.chrome_proc.poll() is None:
            self.chrome_proc.terminate()
        self.destroy()


if __name__ == "__main__":
    app = ExplorerApp()
    app.mainloop()
