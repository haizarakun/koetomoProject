' koetomo_viewer をコンソールなしで起動するランチャー
' 使い方: このファイルをダブルクリックするだけ
Set objShell = CreateObject("WScript.Shell")
objShell.CurrentDirectory = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
objShell.Run "pythonw gui_app.py", 0, False
