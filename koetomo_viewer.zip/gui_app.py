"""
声とも ビューア（閲覧専用・複数アカウント/開発者モード/TL/プロフィール対応）

- ルーム一覧の表示、選択したルームをブラウザで開く
- TLの閲覧・投稿・いいね・ブックマーク・コメント・削除

---- 開発者向けメモ ----
・非公式クライアントです。KoeTomo公式のAPIドキュメントは存在せず、ブラウザの通信を
  観察して作られています。エンドポイント仕様が変わると壊れる前提で読んでください。
・api.py 内の POST/PUT 系メソッド（create_post, comment_post, send_message,
  send_image_message, send_voice_message, follow_user 等）は、実際のリクエスト本文
  (request body) をキャプチャできていないため、フィールド名は「レスポンスの構造から
  推測」したものです。動かない場合はここが最初に疑うべき場所です。
・投稿(create_post)はサーバー側でreCAPTCHA検証が入っているため、API直叩きでは
  成功しません。意図的にブラウザに委譲する設計にしています。
・画像/音声のアップロード先は `https://s3.ap-northeast-1.amazonaws.com/production.meetscom.com/`
  配下（images/, audio/）で、読み取りは認証不要のパブリックGETで動作しています。
・GUIは複数アカウント(config.json内のprofiles)を切り替え可能。切り替えは
  KoetomoAPI.switch_profile() が担当し、requests.Session自体は使い回しつつ
  ヘッダー生成(_headers())だけをアカウントごとに切り替えます。

- 自分のプロフィール閲覧・編集
- 複数アカウント切り替え、テーマカラー変更、開発者モード（生レスポンス表示）
- 自動入室・自動検知・キーワード監視は含まれていない
"""
from __future__ import annotations

import logging
import sys
import threading
import tkinter as tk
import tkinter.font as tkfont
import webbrowser
from tkinter import colorchooser, filedialog, messagebox, scrolledtext, simpledialog, ttk

try:
    from PIL import Image, ImageTk
    _HAS_PIL = True
except ImportError:
    _HAS_PIL = False

try:
    import winsound
    _HAS_WINSOUND = True
except ImportError:
    _HAS_WINSOUND = False


def play_sound(kind: str) -> None:
    """DL不要のシステム内蔵ビープ音のみ使用。失敗しても無視する。"""
    if not _HAS_WINSOUND:
        return
    try:
        if kind == "success":
            winsound.Beep(880, 70)
        elif kind == "error":
            winsound.Beep(220, 150)
        elif kind == "message":
            winsound.Beep(660, 50)
    except Exception:
        pass

import os
import subprocess
from pathlib import Path as _Path

from api import AuthError, ConfigMissingError, KoetomoAPI, CONFIG_PATH, load_raw_config, save_raw_config

ROOM_PROFILE_DIR = r"C:\Temp\ChromeProfile_Koetomo"
CHROME_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
]


def _find_chrome() -> str | None:
    for p in CHROME_CANDIDATES:
        if _Path(p).exists():
            return p
    return None

logging.basicConfig(
    filename="app.log",
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    encoding="utf-8",
)
logger = logging.getLogger(__name__)


class KoetomoViewerApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("koetomoクライアント！")
        self.geometry("880x620")

        self.api: KoetomoAPI | None = None
        self.room_url_template = "https://koetomo.fun/rooms/{token}"

        self._setup_style()
        self._avatar_cache: dict[str, object] = {}
        self.cur_bg = "#313338"
        self.cur_fg = "#dbdee1"
        self._build_ui()
        self._setup_copy_bindings()
        self._init_api()

    def _setup_copy_bindings(self) -> None:
        # 全てのLabel/Entryを右クリックでコピーできるようにする
        self.bind_class("TLabel", "<Button-3>", self._copy_widget_text)
        self.bind_class("Label", "<Button-3>", self._copy_widget_text)
        self.bind_class("TEntry", "<Button-3>", self._copy_entry_text)

    def _copy_widget_text(self, event) -> None:
        widget = event.widget
        text = widget.cget("text") if "text" in widget.keys() else ""
        if text:
            self.clipboard_clear()
            self.clipboard_append(text)
            self._set_status("コピーしました")

    def _copy_entry_text(self, event) -> None:
        widget = event.widget
        try:
            text = widget.get()
        except tk.TclError:
            text = ""
        if text:
            self.clipboard_clear()
            self.clipboard_append(text)
            self._set_status("コピーしました")

    def _setup_style(self) -> None:
        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass
        base_font = tkfont.nametofont("TkDefaultFont")
        base_font.configure(family="Yu Gothic UI", size=10)
        self.option_add("*Font", base_font)
        self.style.configure("TButton", padding=6)
        self.style.configure("Treeview", rowheight=26, font=(base_font.actual("family"), 10))
        self.style.configure("Treeview.Heading", font=(base_font.actual("family"), 10, "bold"))
        self.style.configure("TNotebook.Tab", padding=(14, 8))
        self.configure(padx=0, pady=0)

    # ---------- 初期化 ----------

    def _init_api(self) -> None:
        try:
            self.api = KoetomoAPI()
            self.room_url_template = self.api.room_url_template
            self._refresh_account_menu()
            self.dev_mode_var.set(self.api.developer_mode)
            self._apply_theme(self.api.config.get("theme_color", "#3478f6"))
            self._set_status("設定読み込みOK")
            self.refresh_rooms()
            self.refresh_feed()
            self.refresh_profile()
            self.refresh_friends()
            self._config_mtime = self._get_config_mtime()
            self._watch_config_file()
        except ConfigMissingError as e:
            logger.info("config missing: %s", e)
            self._set_status("config.json が未設定です")
            messagebox.showwarning(
                "設定が必要です",
                f"{CONFIG_PATH.name} が見つからないか不完全です。\n"
                "token_fetcher.py を実行してアカウントを追加してください。",
            )

    # ---------- UI構築 ----------

    def _build_ui(self) -> None:
        self.dev_mode_var = tk.BooleanVar(value=False)
        self.status_var = tk.StringVar(value="起動中…")
        self.account_var = tk.StringVar()

        root_frame = ttk.Frame(self)
        root_frame.pack(fill="both", expand=True)

        # ---- 左レール: アカウント切替 + 設定 ----
        self.rail = tk.Frame(root_frame, width=60)
        self.rail.pack(side="left", fill="y")
        self.rail.pack_propagate(False)
        self.rail_account_frame = tk.Frame(self.rail)
        self.rail_account_frame.pack(side="top", fill="x", pady=(10, 14))
        tk.Button(
            self.rail, text="⚙", width=3, command=self.open_settings, relief="flat",
        ).pack(side="bottom", pady=8)

        # ---- チャンネル一覧列 ----
        self.channel_col = tk.Frame(root_frame, width=210)
        self.channel_col.pack(side="left", fill="y")
        self.channel_col.pack_propagate(False)
        tk.Label(
            self.channel_col, text="koetomoクライアント！", font=("Yu Gothic UI", 12, "bold"), anchor="w",
        ).pack(fill="x", padx=10, pady=(16, 6))

        self._section_buttons: dict[str, tk.Button] = {}
        for key, label in [("rooms", "# グループ通話"), ("feed", "# タイムライン"), ("profile", "# プロフィール"), ("dm", "# DM"), ("search", "# 検索")]:
            btn = tk.Button(
                self.channel_col, text=label, anchor="w", relief="flat", borderwidth=0,
                command=lambda k=key: self.show_section(k),
            )
            btn.pack(fill="x", padx=6, pady=1)
            self._add_hover(btn, "#2b2d31", "#3a3d44")
            self._section_buttons[key] = btn

        ttk.Separator(self.channel_col, orient="horizontal").pack(fill="x", pady=8, padx=6)
        tk.Label(self.channel_col, text="フレンド", font=("Yu Gothic UI", 9, "bold"), anchor="w").pack(
            fill="x", padx=10
        )
        self.friend_list_frame = tk.Frame(self.channel_col, background="#2b2d31")
        self.friend_list_frame.pack(fill="both", expand=True, padx=4, pady=4)

        self.lookup_user_id_var = tk.StringVar()
        self.lookup_user_name_var = tk.StringVar()

        # ---- メインコンテンツ ----
        main_wrap = ttk.Frame(root_frame)
        main_wrap.pack(side="left", fill="both", expand=True)

        status_row = ttk.Frame(main_wrap, padding=(8, 4))
        status_row.pack(fill="x")
        ttk.Label(status_row, textvariable=self.status_var, foreground="#888").pack(side="right")

        self.content_container = tk.Frame(main_wrap)
        self.content_container.pack(fill="both", expand=True)
        self.content_container.grid_rowconfigure(0, weight=1)
        self.content_container.grid_columnconfigure(0, weight=1)

        self._sections: dict[str, tk.Frame] = {}
        self._build_rooms_tab()
        self._build_feed_tab()
        self._build_profile_tab()
        self._build_dm_tab()
        self._build_search_tab()
        self.show_section("rooms")

        # 開発者モード用パネル（既定では非表示）
        self.dev_frame = ttk.Frame(main_wrap, padding=(8, 0, 8, 8))
        ttk.Label(self.dev_frame, text="直近のAPIレスポンス（開発者モード）", font=("Yu Gothic UI", 9, "bold")).pack(anchor="w")
        self.dev_text = scrolledtext.ScrolledText(self.dev_frame, height=8, state="disabled")
        self.dev_text.pack(fill="both", expand=True)

    BUTTON_PRESETS = {
        "Discord風": {"accent": "#5865F2", "accent_hover": "#4752C4", "text": "#ffffff", "pad": (10, 6)},
        "フラット": {"accent": "#4a4a4a", "accent_hover": "#5a5a5a", "text": "#ffffff", "pad": (8, 4)},
        "ネイティブ": {"accent": "#e0e0e0", "accent_hover": "#d0d0d0", "text": "#000000", "pad": (6, 3)},
    }

    def _current_button_preset(self) -> dict:
        name = self.api.config.get("button_style", "Discord風") if self.api else "Discord風"
        return self.BUTTON_PRESETS.get(name, self.BUTTON_PRESETS["Discord風"])

    def _style_button(self, btn) -> None:
        preset = self._current_button_preset()
        try:
            btn.configure(
                background=preset["accent"], foreground=preset["text"],
                activebackground=preset["accent_hover"], activeforeground=preset["text"],
                relief="flat", borderwidth=0, cursor="hand2",
                padx=preset["pad"][0], pady=preset["pad"][1],
            )
            btn.bind("<Enter>", lambda e: btn.configure(background=preset["accent_hover"]))
            btn.bind("<Leave>", lambda e: btn.configure(background=preset["accent"]))
        except tk.TclError:
            pass

    def _restyle_all_buttons(self, root=None) -> None:
        root = root or self
        for child in root.winfo_children():
            if isinstance(child, tk.Button) and child not in self._section_buttons.values():
                self._style_button(child)
            if isinstance(child, (tk.Frame, ttk.Frame)):
                self._restyle_all_buttons(child)

    def _bind_mousewheel(self, canvas: tk.Canvas) -> None:
        def on_wheel(event):
            delta = -1 * int(event.delta / 120) if event.delta else (1 if event.num == 5 else -1)
            canvas.yview_scroll(delta, "units")

        def on_enter(_e):
            canvas.bind_all("<MouseWheel>", on_wheel)
            canvas.bind_all("<Button-4>", on_wheel)
            canvas.bind_all("<Button-5>", on_wheel)

        def on_leave(_e):
            canvas.unbind_all("<MouseWheel>")
            canvas.unbind_all("<Button-4>")
            canvas.unbind_all("<Button-5>")

        canvas.bind("<Enter>", on_enter)
        canvas.bind("<Leave>", on_leave)

    def _add_hover(self, widget, normal_bg: str, hover_bg: str) -> None:
        widget.bind("<Enter>", lambda e: widget.configure(background=hover_bg))
        widget.bind("<Leave>", lambda e: widget.configure(background=normal_bg))

    def show_section(self, key: str) -> None:
        frame = self._sections.get(key)
        if frame:
            frame.tkraise()
        for k, btn in self._section_buttons.items():
            btn.config(relief=("sunken" if k == key else "flat"))
        if key == "dm":
            self.refresh_chats()


    def _build_rooms_tab(self) -> None:
        tab = ttk.Frame(self.content_container)
        tab.grid(row=0, column=0, sticky="nsew")
        self._sections["rooms"] = tab

        control = ttk.Frame(tab)
        control.pack(fill="x", padx=4, pady=4)
        ttk.Button(control, text="一覧を更新", command=self.refresh_rooms_ui).pack(side="left")

        ttk.Label(control, text="並び替え:").pack(side="left", padx=(12, 2))
        self.room_order_var = tk.StringVar(value="新しい順")
        ttk.Combobox(
            control, textvariable=self.room_order_var, state="readonly", width=10,
            values=["新しい順", "古い順", "人数が多い順"],
        ).pack(side="left")

        ttk.Label(control, text="取得ページ数:").pack(side="left", padx=(12, 2))
        self.room_pages_var = tk.StringVar(value="1")
        ttk.Combobox(
            control, textvariable=self.room_pages_var, state="readonly", width=4,
            values=["1", "2", "3", "5", "10"],
        ).pack(side="left")

        ttk.Label(control, text="説明で検索:").pack(side="left", padx=(12, 2))
        self.room_search_var = tk.StringVar()
        search_entry = ttk.Entry(control, textvariable=self.room_search_var, width=20)
        search_entry.pack(side="left")
        search_entry.bind("<KeyRelease>", lambda e: self._apply_room_filter())

        columns = ("desc", "members", "owner", "opened", "id")
        self.tree = ttk.Treeview(tab, columns=columns, show="headings", height=16)
        self._room_tokens: dict[str, str] = {}
        self._all_rooms: list[dict] = []
        for col, label, width in [
            ("desc", "ルーム説明", 280),
            ("members", "人数", 60),
            ("owner", "オーナー", 160),
            ("opened", "開始時刻", 160),
            ("id", "room_id", 90),
        ]:
            self.tree.heading(col, text=label)
            self.tree.column(col, width=width, anchor="w")
        self.tree.pack(fill="both", expand=True, padx=4, pady=4)
        self.tree.bind("<Double-1>", lambda e: self.open_selected_room())

        bottom = ttk.Frame(tab)
        bottom.pack(fill="x", padx=4, pady=4)
        ttk.Button(bottom, text="選択したグループ通話を開く", command=self.open_selected_room).pack(side="left")
        ttk.Label(bottom, text="（ダブルクリックでも開けます）", foreground="#888").pack(side="left", padx=8)

    def _build_feed_tab(self) -> None:
        tab = ttk.Frame(self.content_container)
        tab.grid(row=0, column=0, sticky="nsew")
        self._sections["feed"] = tab

        post_row = ttk.Frame(tab, padding=4)
        post_row.pack(fill="x")
        ttk.Button(post_row, text="ブラウザで投稿する", command=self.open_post_composer).pack(side="left")
        ttk.Button(post_row, text="TL更新", command=self.refresh_feed).pack(side="left", padx=4)
        ttk.Label(post_row, text="取得ページ数:").pack(side="left", padx=(12, 2))
        self.feed_pages_var = tk.StringVar(value="1")
        ttk.Combobox(
            post_row, textvariable=self.feed_pages_var, state="readonly", width=4,
            values=["1", "2", "3", "5", "10"],
        ).pack(side="left")
        ttk.Label(post_row, text="（投稿・コメントはreCAPTCHA対策のためブラウザで行います）", foreground="#888").pack(side="left", padx=8)

        feed_container = ttk.Frame(tab)
        feed_container.pack(fill="both", expand=True, padx=4, pady=4)
        self.feed_canvas = tk.Canvas(feed_container, highlightthickness=0)
        feed_scroll = tk.Scrollbar(feed_container, orient="vertical", command=self.feed_canvas.yview,
                                    background="#3a3d44", troughcolor=self.cur_bg, highlightthickness=0, borderwidth=0)
        self.feed_inner = ttk.Frame(self.feed_canvas)
        self.feed_inner.bind(
            "<Configure>", lambda e: self.feed_canvas.configure(scrollregion=self.feed_canvas.bbox("all"))
        )
        self.feed_canvas.create_window((0, 0), window=self.feed_inner, anchor="nw")
        self.feed_canvas.configure(yscrollcommand=feed_scroll.set)
        self.feed_canvas.pack(side="left", fill="both", expand=True)
        self._bind_mousewheel(self.feed_canvas)
        feed_scroll.pack(side="right", fill="y")
        self._feed_posts: list[dict] = []

    def _build_profile_tab(self) -> None:
        tab = ttk.Frame(self.content_container, padding=8)
        tab.grid(row=0, column=0, sticky="nsew")
        self._sections["profile"] = tab

        self.profile_banner = tk.Canvas(tab, width=480, height=190, highlightthickness=0)
        self.profile_banner.pack(fill="x", pady=(0, 4))
        self._banner_header_img = None
        self._banner_avatar_img = None
        self._banner_name_text_id = None

        img_btn_row = ttk.Frame(tab)
        img_btn_row.pack(fill="x", pady=(0, 8))
        ttk.Button(img_btn_row, text="アイコン変更", command=self.change_avatar).pack(side="left")
        ttk.Button(img_btn_row, text="ヘッダー変更", command=self.change_header).pack(side="left", padx=4)

        self.profile_vars: dict[str, tk.StringVar] = {}
        for key, label in [("name", "名前"), ("comment", "自己紹介"), ("age", "年齢")]:
            row = ttk.Frame(tab)
            row.pack(fill="x", pady=3)
            ttk.Label(row, text=label, width=10).pack(side="left")
            var = tk.StringVar()
            ttk.Entry(row, textvariable=var, width=50).pack(side="left", fill="x", expand=True)
            self.profile_vars[key] = var

        btn_row = ttk.Frame(tab)
        btn_row.pack(fill="x", pady=8)
        ttk.Button(btn_row, text="読み込み直し", command=self.refresh_profile).pack(side="left")
        ttk.Button(btn_row, text="保存", command=self.save_profile).pack(side="left", padx=4)

        stats = ttk.Frame(tab, padding=(0, 6))
        stats.pack(fill="x")
        self.stats_var = tk.StringVar()
        ttk.Label(stats, textvariable=self.stats_var, foreground="#444", justify="left").pack(anchor="w")

        self._json_visible = False
        self.toggle_json_btn = ttk.Button(tab, text="詳細(JSON)を表示", command=self._toggle_json)
        self.toggle_json_btn.pack(anchor="w", pady=(4, 0))

        self.profile_raw = scrolledtext.ScrolledText(tab, height=12, state="disabled")
        # 既定では非表示（トグルで表示）

        ttk.Separator(tab, orient="horizontal").pack(fill="x", pady=10)
        account_row = ttk.Frame(tab)
        account_row.pack(fill="x")
        ttk.Label(account_row, text="アカウント:").pack(side="left")
        self.account_combo = ttk.Combobox(account_row, textvariable=self.account_var, state="readonly", width=16)
        self.account_combo.pack(side="left", padx=4)
        self.account_combo.bind("<<ComboboxSelected>>", self._on_account_change)
        ttk.Button(account_row, text="更新", width=4, command=self.reload_accounts).pack(side="left")
        ttk.Button(account_row, text="ログイン追加", command=self.add_account).pack(side="left", padx=4)
        ttk.Button(account_row, text="ログアウト", command=self.logout_account).pack(side="left")

    # ---------- アカウント ----------

    def _refresh_account_menu(self) -> None:
        if not self.api:
            return
        profiles = self.api.list_profiles()
        self.account_combo["values"] = profiles
        self.account_var.set(self.api.active_profile or "")
        self._rebuild_rail_accounts(profiles)

    def _rebuild_rail_accounts(self, profiles: list[str]) -> None:
        for child in self.rail_account_frame.winfo_children():
            child.destroy()
        for name in profiles:
            label = (name[:1] if name else "?").upper()
            is_active = name == (self.api.active_profile if self.api else None)
            btn = tk.Button(
                self.rail_account_frame, text=label, width=3, height=1,
                background=("#5865F2" if is_active else "#2b2d31"), foreground="#fff",
                relief="flat", borderwidth=0, cursor="hand2",
                command=lambda n=name: self._switch_from_rail(n),
            )
            btn.pack(pady=3)
            # ツールチップ代わりにアカウント名をタイトルバー的に表示するのは省略し、
            # ホバーでアカウント名を確認できるようにする
            _tip = None
            def show_name(_e, n=name, b=btn):
                self._set_status(f"アカウント: {n}")
            btn.bind("<Enter>", show_name)

    def _switch_from_rail(self, name: str) -> None:
        if not self.api:
            return
        try:
            self.api.switch_profile(name)
            self.account_var.set(name)
            self._refresh_account_menu()
            self.refresh_rooms()
            self.refresh_feed()
            self.refresh_profile()
            self.refresh_friends()
        except KeyError as e:
            messagebox.showerror("エラー", str(e))

    def _on_account_change(self, _event=None) -> None:
        if not self.api:
            return
        name = self.account_var.get()
        try:
            self.api.switch_profile(name)
            logger.info("account switched to %s", name)
            self._set_status(f"アカウント切替: {name}")
            self.refresh_rooms()
            self.refresh_feed()
            self.refresh_profile()
            self.refresh_friends()
        except KeyError as e:
            messagebox.showerror("エラー", str(e))

    def _get_config_mtime(self) -> float:
        try:
            return _Path(self.api.config_path).stat().st_mtime if self.api else 0.0
        except OSError:
            return 0.0

    def _watch_config_file(self) -> None:
        # token_fetcher.py等が外部プロセスとしてconfig.jsonを書き換えた場合に自動検知して再読込する(軽量: 3秒間隔でmtimeだけ確認)
        mtime = self._get_config_mtime()
        if mtime and mtime != getattr(self, "_config_mtime", 0.0):
            self._config_mtime = mtime
            logger.info("config.json changed on disk, auto-reloading")
            self.reload_accounts()
        self.after(3000, self._watch_config_file)

    def reload_accounts(self) -> None:
        if not self.api:
            return
        self.api.config = load_raw_config(self.api.config_path)
        self._refresh_account_menu()
        self.refresh_rooms()
        self.refresh_feed()
        self.refresh_profile()
        self.refresh_friends()
        self._set_status("アカウント一覧を更新しました")

    def add_account(self) -> None:
        try:
            launcher = sys.executable.replace("python.exe", "pythonw.exe")
            if not _Path(launcher).exists():
                launcher = "pythonw"
            subprocess.Popen([launcher, "token_fetcher.py"], cwd=str(_Path(__file__).parent))
            messagebox.showinfo(
                "ログイン",
                "token_fetcher.py を起動しました。ログインが完了すると自動で反映されます（更新操作は不要です）。",
            )
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("起動失敗", str(e))

    def logout_account(self) -> None:
        if not self.api or not self.api.active_profile:
            return
        name = self.api.active_profile
        if not messagebox.askyesno("確認", f"アカウント「{name}」をログアウト（削除）しますか？"):
            return
        profiles = self.api.config.get("profiles", {})
        profiles.pop(name, None)
        self.api.config["profiles"] = profiles
        self.api.config["active_profile"] = next(iter(profiles), None)
        save_raw_config(self.api.config, self.api.config_path)
        logger.info("account removed: %s", name)
        if profiles:
            self.api.switch_profile(self.api.config["active_profile"])
            self._refresh_account_menu()
            self.refresh_rooms()
            self.refresh_feed()
            self.refresh_profile()
        else:
            self.account_combo["values"] = []
            self.account_var.set("")
            self._set_status("アカウントがありません。ログイン追加してください")

    # ---------- テーマ ----------

    def _apply_theme(self, bg_color: str | None = None, text_color: str | None = None) -> None:
        if not self.api:
            return
        bg_color = bg_color or self.api.config.get("theme_color", "#3478f6")
        text_color = text_color or self.api.config.get("theme_text_color", "#000000")
        self.cur_bg = bg_color
        self.cur_fg = text_color
        try:
            self.configure(background=bg_color)
            self.style.configure("TFrame", background=bg_color)
            self.style.configure("TLabel", background=bg_color, foreground=text_color)
            self.style.configure("TNotebook", background=bg_color)
            self.style.configure("TButton", foreground=text_color)
            self.style.configure("Treeview", background=bg_color, fieldbackground=bg_color, foreground=text_color)
            self.style.map("Treeview", background=[("selected", "#5865F2")], foreground=[("selected", "#ffffff")])
        except tk.TclError:
            pass
        for widget_name in ("feed_canvas", "dev_text", "profile_raw", "feed_inner"):
            w = getattr(self, widget_name, None)
            if w is not None:
                try:
                    w.configure(background=bg_color, foreground=text_color)
                except tk.TclError:
                    try:
                        w.configure(bg=bg_color)
                    except tk.TclError:
                        pass
        rail_bg = "#1e1f22" if bg_color == "#313338" else bg_color
        channel_bg = "#2b2d31" if bg_color == "#313338" else bg_color
        for widget_name, bg in (("rail", rail_bg), ("channel_col", channel_bg)):
            w = getattr(self, widget_name, None)
            if w is not None:
                try:
                    w.configure(background=bg)
                    for child in w.winfo_children():
                        try:
                            child.configure(background=bg, foreground=text_color)
                        except tk.TclError:
                            pass
                except tk.TclError:
                    pass
        self.style.configure("TCheckbutton", background=bg_color, foreground=text_color)
        self.style.configure("TCombobox", fieldbackground="white", foreground="black")
        self.style.configure("TEntry", fieldbackground="white", foreground="black")
        preset = self._current_button_preset()
        self.style.configure("TButton", background=preset["accent"], foreground=preset["text"], padding=preset["pad"])
        self.style.map("TButton", background=[("active", preset["accent_hover"])])
        self._restyle_all_buttons()
        self._apply_background_image()

    def _bytes_to_circular_photoimage(self, data: bytes, size: int = 32):
        if not _HAS_PIL:
            return self._bytes_to_photoimage(data, size)
        import io
        img = Image.open(io.BytesIO(data)).convert("RGBA")
        img.thumbnail((size, size))
        mask = Image.new("L", img.size, 0)
        from PIL import ImageDraw
        draw = ImageDraw.Draw(mask)
        draw.ellipse((0, 0) + img.size, fill=255)
        img.putalpha(mask)
        return ImageTk.PhotoImage(img)

    def _bytes_to_photoimage(self, data: bytes, size: int | None = None):
        if _HAS_PIL:
            import io
            img = Image.open(io.BytesIO(data))
            if size:
                img.thumbnail((size, size))
            return ImageTk.PhotoImage(img)
        # PIL未導入時はPNG/GIFのみ対応
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            f.write(data)
            path = f.name
        img = tk.PhotoImage(file=path)
        if size:
            factor = max(1, img.width() // size)
            if factor > 1:
                img = img.subsample(factor, factor)
        return img

    def _apply_background_image(self) -> None:
        if not self.api:
            return
        path = self.api.config.get("background_image_path")
        if not path:
            if getattr(self, "_bg_label", None):
                self._bg_label.destroy()
                self._bg_label = None
            return
        try:
            with open(path, "rb") as f:
                data = f.read()
            img = self._bytes_to_photoimage(data)
            self._bg_image_ref = img
            if getattr(self, "_bg_label", None) is None:
                self._bg_label = tk.Label(self, image=img, borderwidth=0)
                self._bg_label.place(x=0, y=0, relwidth=1, relheight=1)
                self._bg_label.lower()
            else:
                self._bg_label.configure(image=img)
        except Exception as e:  # noqa: BLE001
            logger.warning("background image load failed: %s", e)

    def open_settings(self) -> None:
        if not self.api:
            return
        if getattr(self, "_settings_win", None) is not None and self._settings_win.winfo_exists():
            self._settings_win.lift()
            self._settings_win.focus_force()
            return
        win = tk.Toplevel(self)
        self._settings_win = win
        win.title("設定")
        win.geometry("400x760")
        bg = self.api.config.get("theme_color", "#313338")
        win.configure(background=bg)
        win.protocol("WM_DELETE_WINDOW", lambda: (win.destroy(), setattr(self, "_settings_win", None)))

        # スクロール可能に(項目が増えても画面に収まらない問題を防ぐ)
        canvas = tk.Canvas(win, background=bg, highlightthickness=0)
        scroll = ttk.Scrollbar(win, orient="vertical", command=canvas.yview)
        frame = ttk.Frame(canvas, padding=12)
        frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=frame, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        ttk.Label(frame, text="UIスタイル").pack(anchor="w")
        style_var = tk.StringVar(value=self.style.theme_use())
        style_combo = ttk.Combobox(frame, textvariable=style_var, state="readonly", values=self.style.theme_names())
        style_combo.pack(fill="x", pady=4)
        style_combo.bind("<<ComboboxSelected>>", lambda e: self._change_ui_style(style_var.get()))

        ttk.Label(frame, text="ボタンスタイル").pack(anchor="w", pady=(6, 0))
        btn_style_var = tk.StringVar(value=self.api.config.get("button_style", "Discord風"))
        btn_style_combo = ttk.Combobox(
            frame, textvariable=btn_style_var, state="readonly", values=list(self.BUTTON_PRESETS.keys())
        )
        btn_style_combo.pack(fill="x", pady=4)
        btn_style_combo.bind("<<ComboboxSelected>>", lambda e: self._change_button_style(btn_style_var.get()))

        ttk.Button(
            frame, text="Chromeのマイク設定を開く",
            command=lambda: webbrowser.open("chrome://settings/content/microphone"),
        ).pack(fill="x", pady=(8, 2))
        self.ext_var = tk.BooleanVar(value=bool(self.api.config.get("chrome_allow_extensions", True)))
        ttk.Checkbutton(
            frame, text="拡張機能を使う（Chromeで開く時、通常ウィンドウにする）",
            variable=self.ext_var, command=self._toggle_extensions,
        ).pack(anchor="w", pady=2)
        ttk.Label(
            frame, text="※マイク/スピーカー選択やChrome拡張機能はブラウザ本体の機能です",
            foreground="#888", wraplength=320, justify="left",
        ).pack(anchor="w", pady=(0, 8))

        ttk.Separator(frame, orient="horizontal").pack(fill="x", pady=8)
        ttk.Button(frame, text="背景色を選ぶ", command=self._pick_bg_color).pack(fill="x", pady=4)
        ttk.Button(frame, text="文字色を選ぶ", command=self._pick_text_color).pack(fill="x", pady=4)

        ttk.Separator(frame, orient="horizontal").pack(fill="x", pady=8)
        ttk.Label(frame, text="グループ通話は常にChromeの固定ウィンドウで開きます（追加ソフト不要）", foreground="#888", wraplength=320, justify="left").pack(anchor="w", pady=4)

        win_row = ttk.Frame(frame)
        win_row.pack(fill="x", pady=4)
        ttk.Label(win_row, text="ウィンドウ幅×高さ:").pack(side="left")
        self.win_w_var = tk.StringVar(value=str(self.api.config.get("chrome_window_width", 430)))
        self.win_h_var = tk.StringVar(value=str(self.api.config.get("chrome_window_height", 830)))
        ttk.Entry(win_row, textvariable=self.win_w_var, width=5).pack(side="left", padx=2)
        ttk.Label(win_row, text="x").pack(side="left")
        ttk.Entry(win_row, textvariable=self.win_h_var, width=5).pack(side="left", padx=2)
        ttk.Button(win_row, text="保存", command=self._save_window_size).pack(side="left", padx=6)

        ttk.Separator(frame, orient="horizontal").pack(fill="x", pady=8)
        ttk.Button(frame, text="ログファイルを開く (app.log)", command=self._open_log_file).pack(fill="x", pady=4)
        ttk.Button(frame, text="ログを表示（コピー可）", command=self._show_log_viewer).pack(fill="x", pady=4)
        ttk.Button(frame, text="ログを削除", command=self._clear_log_file).pack(fill="x", pady=4)
        ttk.Button(frame, text="全部まとめて更新", command=self._refresh_all).pack(fill="x", pady=4)

        ttk.Separator(frame, orient="horizontal").pack(fill="x", pady=8)
        ttk.Label(frame, text="ログ（選択してコピー可能）").pack(anchor="w")
        log_box = scrolledtext.ScrolledText(frame, height=10, width=38)
        log_box.pack(fill="both", expand=True, pady=(4, 0))
        try:
            log_path = _Path(__file__).parent / "app.log"
            text = log_path.read_text(encoding="utf-8", errors="replace")
            tail = "\n".join(text.splitlines()[-200:])
        except FileNotFoundError:
            tail = "(まだログがありません)"
        log_box.insert("1.0", tail)
        log_box.see("end")

        ttk.Separator(frame, orient="horizontal").pack(fill="x", pady=8)
        ttk.Button(
            frame, text="GitHubへ",
            command=lambda: webbrowser.open("https://github.com/haizarakun/koetomoProject"),
        ).pack(fill="x", pady=2)
        ttk.Label(
            frame, text="koetomoProject\nhttps://github.com/haizarakun/koetomoProject",
            foreground="#888", justify="left", wraplength=340,
        ).pack(anchor="w", pady=(4, 0))
        ttk.Checkbutton(
            frame, text="開発者モード（直近のAPIレスポンスを表示）",
            variable=self.dev_mode_var, command=self.toggle_dev_mode,
        ).pack(anchor="w", pady=4)

    def _show_log_viewer(self) -> None:
        log_path = _Path(__file__).parent / "app.log"
        try:
            text = log_path.read_text(encoding="utf-8", errors="replace")
        except FileNotFoundError:
            text = "(まだログがありません)"
        tail = "\n".join(text.splitlines()[-500:])  # 直近500行のみ(軽量化)

        win = tk.Toplevel(self)
        win.title("ログ (app.log) — 選択してCtrl+Cでコピーできます")
        win.geometry("640x480")
        bg = self.api.config.get("theme_color", "#313338") if self.api else "#313338"
        fg = self.api.config.get("theme_text_color", "#dbdee1") if self.api else "#dbdee1"
        win.configure(background=bg)

        box = scrolledtext.ScrolledText(win, background=bg, foreground=fg)
        box.pack(fill="both", expand=True, padx=8, pady=8)
        box.insert("1.0", tail)
        box.see("end")
        # 誤操作で内容を書き換えないよう編集は禁止、選択とコピーは可能なままにする
        box.bind("<Key>", lambda e: "break" if e.keysym not in ("c", "C") or not (e.state & 0x4) else None)

        btn_row = ttk.Frame(win)
        btn_row.pack(fill="x", padx=8, pady=(0, 8))
        def copy_all():
            self.clipboard_clear()
            self.clipboard_append(tail)
            self._set_status("ログ全文をコピーしました")
        ttk.Button(btn_row, text="全文コピー", command=copy_all).pack(side="left")
        ttk.Button(btn_row, text="再読み込み", command=lambda: (win.destroy(), self._show_log_viewer())).pack(side="left", padx=4)

    def _refresh_all(self) -> None:
        self.refresh_rooms()
        self.refresh_feed()
        self.refresh_profile()
        self.refresh_friends()
        self.refresh_chats()
        self._set_status("すべて更新しました")

    def _clear_log_file(self) -> None:
        if not messagebox.askyesno("確認", "app.log の内容を削除しますか？"):
            return
        try:
            log_path = _Path(__file__).parent / "app.log"
            log_path.write_text("", encoding="utf-8")
            self._set_status("ログを削除しました")
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("失敗", str(e))

    def _open_log_file(self) -> None:
        log_path = _Path(__file__).parent / "app.log"
        try:
            os.startfile(str(log_path))  # noqa: S606 - Windows専用
        except Exception:
            webbrowser.open(log_path.as_uri())

    def _change_button_style(self, name: str) -> None:
        if not self.api:
            return
        self.api.config["button_style"] = name
        from api import save_raw_config as _save
        _save(self.api.config, self.api.config_path)
        self._apply_theme()

    def _change_ui_style(self, name: str) -> None:
        try:
            self.style.theme_use(name)
            self._apply_theme()
        except tk.TclError as e:
            messagebox.showerror("失敗", str(e))

    def _apply_discord_preset(self) -> None:
        if not self.api:
            return
        self.api.config["theme_color"] = "#313338"
        self.api.config["theme_text_color"] = "#dbdee1"
        self.api.config["accent_color"] = "#5865F2"
        from api import save_raw_config as _save
        _save(self.api.config, self.api.config_path)
        self._apply_theme(bg_color="#313338", text_color="#dbdee1")
        self.style.configure("TButton", background="#5865F2", foreground="#ffffff")
        self.style.map("TButton", background=[("active", "#4752C4")])
        self.style.configure("TNotebook.Tab", background="#2b2d31", foreground="#dbdee1")
        self.style.map("TNotebook.Tab", background=[("selected", "#313338")], foreground=[("selected", "#ffffff")])

    def _toggle_extensions(self) -> None:
        if not self.api:
            return
        self.api.config["chrome_allow_extensions"] = self.ext_var.get()
        from api import save_raw_config as _save
        _save(self.api.config, self.api.config_path)
        if not self.api:
            return
        self.api.config["open_room_external"] = self.external_browser_var.get()
        from api import save_raw_config as _save
        _save(self.api.config, self.api.config_path)

    def _save_window_size(self) -> None:
        if not self.api:
            return
        try:
            w = int(self.win_w_var.get())
            h = int(self.win_h_var.get())
        except ValueError:
            messagebox.showerror("エラー", "数値を入力してください")
            return
        self.api.config["chrome_window_width"] = w
        self.api.config["chrome_window_height"] = h
        from api import save_raw_config as _save
        _save(self.api.config, self.api.config_path)
        self._set_status("ウィンドウサイズを保存しました")

    def _pick_bg_color(self) -> None:
        color = colorchooser.askcolor(title="背景色を選択")
        if color and color[1] and self.api:
            self.api.set_theme_color(color[1])
            self._apply_theme(bg_color=color[1])

    def _pick_text_color(self) -> None:
        color = colorchooser.askcolor(title="文字色を選択")
        if color and color[1] and self.api:
            self.api.config["theme_text_color"] = color[1]
            from api import save_raw_config as _save
            _save(self.api.config, self.api.config_path)
            self._apply_theme(text_color=color[1])

    def _pick_bg_image(self) -> None:
        path = filedialog.askopenfilename(filetypes=[("画像", "*.png;*.jpg;*.jpeg;*.gif;*.bmp"), ("すべて", "*.*")])
        if path and self.api:
            self.api.config["background_image_path"] = path
            from api import save_raw_config as _save
            _save(self.api.config, self.api.config_path)
            self._apply_background_image()

    def _clear_bg_image(self) -> None:
        if not self.api:
            return
        self.api.config["background_image_path"] = None
        from api import save_raw_config as _save
        _save(self.api.config, self.api.config_path)
        self._apply_background_image()

    # ---------- 開発者モード ----------

    def toggle_dev_mode(self) -> None:
        enabled = self.dev_mode_var.get()
        if self.api:
            self.api.set_developer_mode(enabled)
        logger.info("developer mode: %s", enabled)
        if enabled:
            self.dev_frame.pack(fill="both")
        else:
            self.dev_frame.pack_forget()

    def _update_dev_panel(self) -> None:
        if not (self.api and self.dev_mode_var.get()):
            return
        info = self.api.last_request
        text = (
            f"URL: {info.get('url', '')}\n"
            f"Status: {info.get('status', '')}\n\n"
            f"{info.get('raw_text', '')}"
        )
        self.dev_text.config(state="normal")
        self.dev_text.delete("1.0", "end")
        self.dev_text.insert("1.0", text)
        self.dev_text.config(state="disabled")

    # ---------- ルームURL形式 ----------

    def edit_url_template(self) -> None:
        if not self.api:
            return
        new_template = simpledialog.askstring(
            "ルームURL形式",
            "例: https://koetomo.fun/rooms/{token}\n{token} の部分に room_id が入ります。",
            initialvalue=self.room_url_template,
        )
        if new_template:
            self.room_url_template = new_template
            self.api.set_room_url_template(new_template)
            logger.info("room_url_template updated: %s", new_template)
            self._set_status("URL形式を更新しました")

    # ---------- ルーム一覧 ----------

    def refresh_rooms(self) -> None:
        if not self.api:
            return
        order_label = getattr(self, "room_order_var", None)
        order_text = order_label.get() if order_label else "新しい順"
        order = {
            "新しい順": "opened_at_desc",
            "古い順": "opened_at_asc",
            "人数が多い順": "member_count_desc",
        }.get(order_text, "opened_at_desc")
        pages_label = getattr(self, "room_pages_var", None)
        try:
            pages = int(pages_label.get()) if pages_label else 1
        except ValueError:
            pages = 1
        try:
            rooms = self.api.get_rooms_multi(pages=pages, order=order)
        except AuthError as e:
            self._set_status(str(e))
            return
        except Exception as e:  # noqa: BLE001
            logger.exception("refresh_rooms failed")
            self._set_status(f"取得失敗: {type(e).__name__}")
            return
        finally:
            self._update_dev_panel()
        self._all_rooms = rooms
        self._apply_room_filter()
        self._set_status(f"{len(rooms)}件のグループ通話を取得しました")

    def refresh_rooms_ui(self) -> None:
        self.refresh_rooms()

    def _apply_room_filter(self) -> None:
        keyword = self.room_search_var.get().strip() if hasattr(self, "room_search_var") else ""
        rooms = self._all_rooms
        if keyword:
            rooms = [r for r in rooms if keyword in (r.get("description") or "")]
        self.tree.delete(*self.tree.get_children())
        self._room_tokens.clear()
        for room in rooms:
            room_id = room.get("id")
            owner = room.get("ownerUser") or {}
            values = (
                room.get("description", ""),
                len(room.get("members", []) or []),
                owner.get("comment") or owner.get("id", ""),
                room.get("openedAt", ""),
                room_id,
            )
            self.tree.insert("", "end", iid=str(room_id), values=values)
            self._room_tokens[str(room_id)] = room.get("token", str(room_id))

    def open_selected_room(self) -> None:
        sel = self.tree.selection()
        if not sel:
            return
        room_id = sel[0]
        values = self.tree.item(room_id, "values")
        desc = values[0] if values else ""
        url = self.room_url_template.format(id=room_id, token=room_id)
        logger.info("room open attempt: id=%s desc=%r url=%s", room_id, desc, url)
        self._open_chrome_app_window(url)

    def _open_chrome_app_window(self, url: str) -> None:
        """
        タブなし・固定サイズ・固定位置のChromeウィンドウ(app-mode)で開く。
        AutoJoin_Stable.py等と同じプロファイルを使うため、ログイン状態と
        マイク許可設定がすでに保存済みで、毎回聞かれにくい。
        """
        chrome_path = _find_chrome()
        if not chrome_path:
            webbrowser.open(url)
            self._set_status(f"ブラウザで開きました: {url}")
            return

        cfg = self.api.config if self.api else {}
        w = cfg.get("chrome_window_width", 430)
        h = cfg.get("chrome_window_height", 830)
        x = cfg.get("chrome_window_x", 120)
        y = cfg.get("chrome_window_y", 80)

        _Path(ROOM_PROFILE_DIR).mkdir(parents=True, exist_ok=True)
        allow_ext = bool(cfg.get("chrome_allow_extensions", True))
        if allow_ext:
            args = [
                chrome_path,
                url,
                f"--window-size={w},{h}",
                f"--window-position={x},{y}",
                f"--user-data-dir={ROOM_PROFILE_DIR}",
            ]
        else:
            args = [
                chrome_path,
                f"--app={url}",
                f"--window-size={w},{h}",
                f"--window-position={x},{y}",
                f"--user-data-dir={ROOM_PROFILE_DIR}",
            ]
        try:
            subprocess.Popen(args)
            self._set_status(f"固定ウィンドウで開きました: {url}")
            self._show_call_overlay()
        except Exception as e:  # noqa: BLE001
            logger.exception("chrome app-mode failed, falling back")
            webbrowser.open(url)
            self._set_status(f"ブラウザで開きました: {url}")

    def _show_call_overlay(self) -> None:
        """
        Discordのゲーム内オーバーレイ風の、常に最前面・半透明の小さいステータス表示。
        注意: 実際の通話状態(マイクON/OFF等)は取得できないため見た目だけの表示です。
        """
        if getattr(self, "_overlay_win", None) is not None and self._overlay_win.winfo_exists():
            self._overlay_win.lift()
            return
        win = tk.Toplevel(self)
        self._overlay_win = win
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        try:
            win.attributes("-alpha", 0.85)
        except tk.TclError:
            pass
        bg = self.api.config.get("theme_color", "#313338") if self.api else "#313338"
        fg = self.api.config.get("theme_text_color", "#dbdee1") if self.api else "#dbdee1"
        win.configure(background=bg)
        win.geometry("+40+40")
        frame = tk.Frame(win, background=bg, padx=10, pady=6)
        frame.pack()
        tk.Label(frame, text="🔊 通話中（表示のみ）", background=bg, foreground=fg, font=("Yu Gothic UI", 9)).pack(side="left")
        tk.Button(frame, text="×", command=win.destroy, background=bg, foreground=fg, borderwidth=0).pack(side="left", padx=(8, 0))
        # ドラッグで移動できるように
        def start_move(e): win._dx, win._dy = e.x, e.y
        def do_move(e): win.geometry(f"+{e.x_root - win._dx}+{e.y_root - win._dy}")
        frame.bind("<Button-1>", start_move)
        frame.bind("<B1-Motion>", do_move)

    def refresh_feed(self) -> None:
        if not self.api:
            return
        pages_var = getattr(self, "feed_pages_var", None)
        try:
            pages = int(pages_var.get()) if pages_var else 1
        except ValueError:
            pages = 1
        try:
            posts = self.api.get_feed_posts_multi(pages=pages)
        except AuthError as e:
            self._set_status(str(e))
            return
        except Exception as e:  # noqa: BLE001
            logger.exception("refresh_feed failed")
            self._set_status(f"TL取得失敗: {type(e).__name__}")
            return
        finally:
            self._update_dev_panel()
        self._feed_posts = posts
        self._post_widgets: dict = {}
        for child in self.feed_inner.winfo_children():
            child.destroy()
        for p in posts:
            self._build_post_card(p)
        self._set_status(f"TL {len(posts)}件取得しました")

    def _build_post_card(self, post: dict) -> None:
        user = post.get("user", {})
        card = ttk.Frame(self.feed_inner, padding=10)
        card.pack(fill="x", pady=1)

        header = ttk.Frame(card)
        header.pack(fill="x")
        name_lbl = ttk.Label(header, text=user.get("name", "?"), font=("Yu Gothic UI", 10, "bold"), cursor="hand2", foreground="#5865F2")
        name_lbl.pack(side="left")
        name_lbl.bind("<Button-1>", lambda e, uid=user.get("id"): self._show_user_popup_by_id(uid))
        age = user.get("age")
        meta = f"  {age}歳" if age else ""
        ttk.Label(header, text=f"{meta}   {post.get('createdAt', '')}", foreground="#888").pack(side="left")

        body = ttk.Label(
            card, text=post.get("decodedDescription") or "(画像/ボイス投稿)", wraplength=560, justify="left"
        )
        body.pack(fill="x", anchor="w", pady=(4, 6))

        footer = ttk.Frame(card)
        footer.pack(fill="x")
        like_mark = "♥" if post.get("isLiked") else "♡"
        like_btn = ttk.Button(
            footer, text=f"{like_mark} {post.get('likedCount', 0)}",
            command=lambda pid=post["id"]: self.like_post_by_id(pid),
        )
        like_btn.pack(side="left")
        bm_mark = "★" if post.get("isBookmarked") else "☆"
        bm_btn = ttk.Button(
            footer, text=f"{bm_mark} 保存",
            command=lambda pid=post["id"]: self.bookmark_post_by_id(pid),
        )
        bm_btn.pack(side="left", padx=4)
        ttk.Button(
            footer, text=f"💬 {post.get('commentCount', 0)}",
            command=lambda pid=post["id"]: self.open_comment_browser(pid),
        ).pack(side="left", padx=4)
        if str(user.get("id")) == str(self.api.uid if self.api else ""):
            ttk.Button(
                footer, text="削除",
                command=lambda pid=post["id"]: self.delete_post_by_id(pid),
            ).pack(side="left", padx=4)

        sep = ttk.Separator(self.feed_inner, orient="horizontal")
        sep.pack(fill="x")
        self._post_widgets[post["id"]] = {
            "card": card, "sep": sep, "like_btn": like_btn, "bm_btn": bm_btn, "post": post,
        }

    def open_post_composer(self) -> None:
        # 投稿はreCAPTCHA(bot対策)がかかっているため、API直叩きではなくブラウザに委譲する
        webbrowser.open("https://koetomo.fun/")
        self._set_status("ブラウザでTLを開きました。投稿はそちらで行ってください")

    def like_post_by_id(self, post_id) -> None:
        if not self.api:
            return
        try:
            self.api.like_post(post_id)
            w = self._post_widgets.get(post_id)
            if w:
                post = w["post"]
                post["isLiked"] = not post.get("isLiked")
                post["likedCount"] = post.get("likedCount", 0) + (1 if post["isLiked"] else -1)
                mark = "♥" if post["isLiked"] else "♡"
                w["like_btn"].config(text=f"{mark} {post['likedCount']}")
            self._set_status("いいねしました")
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("失敗", str(e))
        finally:
            self._update_dev_panel()

    def bookmark_post_by_id(self, post_id) -> None:
        if not self.api:
            return
        try:
            self.api.bookmark_post(post_id)
            w = self._post_widgets.get(post_id)
            if w:
                post = w["post"]
                post["isBookmarked"] = not post.get("isBookmarked")
                mark = "★" if post["isBookmarked"] else "☆"
                w["bm_btn"].config(text=f"{mark} 保存")
            self._set_status("ブックマークしました")
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("失敗", str(e))
        finally:
            self._update_dev_panel()

    def open_comment_browser(self, post_id) -> None:
        url = f"https://koetomo.fun/posts/{post_id}"
        webbrowser.open(url)
        self._set_status(f"ブラウザで開きました（URL形式は未検証）: {url}")

    def delete_post_by_id(self, post_id) -> None:
        if not self.api:
            return
        if not messagebox.askyesno("確認", "この投稿を削除しますか？"):
            return
        try:
            self.api.delete_post(post_id)
            w = self._post_widgets.pop(post_id, None)
            if w:
                w["card"].destroy()
                w["sep"].destroy()
            self._set_status("削除しました")
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("失敗", str(e))
        finally:
            self._update_dev_panel()

    # ---------- プロフィール ----------

    def refresh_profile(self) -> None:
        if not self.api:
            return
        try:
            profile = self.api.get_user()
        except Exception as e:  # noqa: BLE001
            logger.exception("refresh_profile failed")
            self._set_status(f"プロフィール取得失敗: {type(e).__name__}")
            return
        finally:
            self._update_dev_panel()
        self.profile_vars["name"].set(str(profile.get("name", "")))
        self.profile_vars["comment"].set(str(profile.get("comment", "")))
        self.profile_vars["age"].set(str(profile.get("age", "")))
        self._load_profile_images(profile)

        stats_lines = [
            f"フォロワー: {profile.get('followerCount', '-')}    フォロー中: {profile.get('followeeCount', '-')}    フレンド: {profile.get('friendCount', '-')}",
            f"ログイン状況: {profile.get('loginStatusWithUnit', '-')}    いいねされた数: {profile.get('likedCount', '-')}",
            f"トーク許可: {profile.get('talkRequestPermissionLevel', '-')}    チャット許可: {profile.get('chatPermissionLevel', '-')}",
            f"アカウント作成時期: {self._extract_created_at(profile)}",
        ]
        self.stats_var.set("\n".join(stats_lines))

        import json as _json
        self.profile_raw.config(state="normal")
        self.profile_raw.delete("1.0", "end")
        self.profile_raw.insert("1.0", _json.dumps(profile, ensure_ascii=False, indent=2))
        self.profile_raw.config(state="disabled")

    def _toggle_json(self) -> None:
        self._json_visible = not self._json_visible
        if self._json_visible:
            self.profile_raw.pack(fill="both", expand=True, pady=(8, 0))
            self.toggle_json_btn.config(text="詳細(JSON)を隠す")
        else:
            self.profile_raw.pack_forget()
            self.toggle_json_btn.config(text="詳細(JSON)を表示")

    def _load_profile_images(self, profile: dict) -> None:
        import requests as _requests

        canvas = self.profile_banner
        canvas.delete("all")
        W, H = 480, 190
        HEADER_H = 140
        bg = self.api.config.get("theme_color", "#313338") if self.api else "#313338"
        canvas.configure(background=bg, width=W, height=H)
        # 土台: ヘッダー領域(プレースホルダーのグラデーション風単色)+フッター領域
        canvas.create_rectangle(0, 0, W, HEADER_H, fill="#3a3d55", outline="", tags="placeholder")
        canvas.create_rectangle(0, HEADER_H, W, H, fill="#22232a", outline="")
        canvas.create_text(W // 2, H - 20, text=profile.get("name", "?"), fill="#fff",
                            font=("Yu Gothic UI", 13, "bold"), tags="nametext")

        def cover_crop(img):
            """PIL Imageを W x HEADER_H を覆うように拡大/中央クロップする"""
            if not _HAS_PIL:
                return img
            iw, ih = img.size
            scale = max(W / iw, HEADER_H / ih)
            nw, nh = int(iw * scale), int(ih * scale)
            img = img.resize((nw, nh))
            left = (nw - W) // 2
            top = (nh - HEADER_H) // 2
            return img.crop((left, top, left + W, top + HEADER_H))

        def load_header(url: str | None) -> None:
            if not url:
                return
            cache_key = f"banner2:{url}"
            cached = self._avatar_cache.get(cache_key)
            if cached is not None:
                self._banner_header_img = cached
                img_id = canvas.create_image(W // 2, HEADER_H // 2, image=cached)
                canvas.tag_raise(img_id, "placeholder")
                return
            def worker():
                try:
                    resp = _requests.get(url, timeout=10)
                    resp.raise_for_status()
                    if _HAS_PIL:
                        import io
                        pil_img = Image.open(io.BytesIO(resp.content)).convert("RGB")
                        pil_img = cover_crop(pil_img)
                        img = ImageTk.PhotoImage(pil_img)
                    else:
                        img = self._bytes_to_photoimage(resp.content, size=HEADER_H)
                    def apply():
                        self._avatar_cache[cache_key] = img
                        self._banner_header_img = img
                        img_id = canvas.create_image(W // 2, HEADER_H // 2, image=img)
                        canvas.tag_raise(img_id, "placeholder")
                    self.after(0, apply)
                except Exception as e:  # noqa: BLE001
                    logger.warning("banner image load failed: %s", e)
            threading.Thread(target=worker, daemon=True).start()

        def load_avatar(url: str | None) -> None:
            if not url:
                return
            cache_key = f"circ72:{url}"
            cx, cy = W // 2, HEADER_H
            def draw(img):
                canvas.create_oval(cx - 38, cy - 38, cx + 38, cy + 38, fill=bg, outline="")  # 縁取り
                canvas.create_image(cx, cy, image=img)
                canvas.tag_lower("nametext")
                canvas.tag_raise("nametext")
            cached = self._avatar_cache.get(cache_key)
            if cached is not None:
                self._banner_avatar_img = cached
                draw(cached)
                return
            def worker():
                try:
                    resp = _requests.get(url, timeout=10)
                    resp.raise_for_status()
                    img = self._bytes_to_circular_photoimage(resp.content, size=68)
                    def apply():
                        self._avatar_cache[cache_key] = img
                        self._banner_avatar_img = img
                        draw(img)
                    self.after(0, apply)
                except Exception as e:  # noqa: BLE001
                    logger.warning("avatar image load failed: %s", e)
            threading.Thread(target=worker, daemon=True).start()

        if self.api:
            load_header(self.api.image_url(profile.get("headerImageFilePath")))
            load_avatar(self.api.image_url(profile.get("profilePictureFilePath")))

    def _extract_created_at(self, profile: dict) -> str:
        for key in ("createdAt", "registeredAt", "joinedAt", "registrationDate", "createdDate"):
            if profile.get(key):
                return str(profile[key])
        return "不明（APIに情報なし）"

    def _build_search_tab(self) -> None:
        tab = ttk.Frame(self.content_container, padding=8)
        tab.grid(row=0, column=0, sticky="nsew")
        self._sections["search"] = tab

        row = ttk.Frame(tab)
        row.pack(fill="x")
        ttk.Label(row, text="id:").pack(side="left")
        ttk.Entry(row, textvariable=self.lookup_user_id_var, width=14).pack(side="left", padx=(2, 8))
        ttk.Button(row, text="検索", command=self.lookup_other_user).pack(side="left", padx=6)

        self.search_result_frame = ttk.Frame(tab, padding=(0, 12))
        self.search_result_frame.pack(fill="both", expand=True)
        ttk.Label(self.search_result_frame, text="ここに検索結果が表示されます", foreground="#888").pack(anchor="w")

    def _render_user_in_search_tab(self, profile: dict) -> None:
        for child in self.search_result_frame.winfo_children():
            child.destroy()
        frame = self.search_result_frame

        img_row = ttk.Frame(frame)
        img_row.pack(fill="x")
        avatar_label = ttk.Label(img_row)
        avatar_label.pack(side="left")
        if self.api:
            url = self.api.image_url(profile.get("profilePictureFilePath"))
            if url:
                try:
                    import requests as _requests
                    resp = _requests.get(url, timeout=10)
                    resp.raise_for_status()
                    img = self._bytes_to_photoimage(resp.content, size=80)
                    self._search_avatar_ref = img
                    avatar_label.config(image=img)
                except Exception:
                    avatar_label.config(text="(画像読込失敗)")

        ttk.Label(frame, text=profile.get("name", "?"), font=("Yu Gothic UI", 13, "bold")).pack(anchor="w", pady=(8, 0))
        ttk.Label(frame, text=f"年齢: {profile.get('age', '-')}").pack(anchor="w")
        ttk.Label(frame, text=profile.get("comment") or "", wraplength=460, justify="left").pack(anchor="w", pady=4)
        ttk.Label(
            frame,
            text=f"フォロワー: {profile.get('followerCount', '-')}   フォロー中: {profile.get('followeeCount', '-')}   フレンド: {profile.get('friendCount', '-')}",
        ).pack(anchor="w", pady=(8, 0))
        ttk.Label(frame, text=f"ログイン状況: {profile.get('loginStatusWithUnit', '-')}").pack(anchor="w")
        ttk.Label(frame, text=f"アカウント作成時期: {self._extract_created_at(profile)}").pack(anchor="w", pady=(4, 0))

        uid = profile.get("id")
        action_row = ttk.Frame(frame)
        action_row.pack(fill="x", pady=(10, 0))
        ttk.Button(action_row, text="フォロー", command=lambda: self._user_action(self.api.follow_user, uid, "フォローしました")).pack(side="left")
        ttk.Button(action_row, text="フレンド申請", command=lambda: self._user_action(self.api.send_friend_request, uid, "申請を送りました")).pack(side="left", padx=4)
        ttk.Button(action_row, text="ブロック", command=lambda: self._user_action(self.api.block_user, uid, "ブロックしました")).pack(side="left", padx=4)
        ttk.Button(action_row, text="DM", command=lambda: self.open_dm_window(uid, profile.get("name", "?"))).pack(side="left", padx=4)

        notebook = ttk.Notebook(frame)
        notebook.pack(fill="both", expand=True, pady=(12, 0))
        tweet_tab = ttk.Frame(notebook, padding=6)
        talk_tab = ttk.Frame(notebook, padding=6)
        notebook.add(tweet_tab, text="つぶやき")
        notebook.add(talk_tab, text="話そう")

        def render_posts(container, posts):
            for p in posts:
                text = p.get("decodedDescription") or "(画像/ボイス投稿)"
                ttk.Label(container, text=f"・{text[:80]}", wraplength=440, justify="left").pack(anchor="w", pady=1)
            if not posts:
                ttk.Label(container, text="(投稿なし)", foreground="#888").pack(anchor="w")

        try:
            tweets = self.api.get_user_feed_posts(uid) if uid else []
        except Exception:  # noqa: BLE001
            tweets = []
        try:
            talks = self.api.get_user_timeline_posts(uid) if uid else []
        except Exception:  # noqa: BLE001
            talks = []
        render_posts(tweet_tab, tweets)
        render_posts(talk_tab, talks)

    def _build_friends_tab(self) -> None:
        tab = ttk.Frame(self.content_container, padding=8)
        tab.grid(row=0, column=0, sticky="nsew")
        self._sections["friends"] = tab

        ttk.Button(tab, text="更新", command=self.refresh_friends_tab).pack(anchor="w")

        canvas = tk.Canvas(tab, highlightthickness=0)
        scroll = ttk.Scrollbar(tab, orient="vertical", command=canvas.yview)
        self.friends_tab_inner = tk.Frame(canvas, background=self.cur_bg)
        self.friends_tab_inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.friends_tab_inner, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True, pady=6)
        scroll.pack(side="right", fill="y")
        self._bind_mousewheel(canvas)

    def refresh_friends_tab(self) -> None:
        if not self.api:
            return
        for child in self.friends_tab_inner.winfo_children():
            child.destroy()
        try:
            data = self.api.get_friends()
        except Exception as e:  # noqa: BLE001
            logger.warning("friends tab failed: %s", e)
            tk.Label(self.friends_tab_inner, text=f"取得失敗: {type(e).__name__}", background=self.cur_bg,
                     foreground="#e74c3c").pack(anchor="w")
            return
        finally:
            self._update_dev_panel()
        users = data.get("users", []) if isinstance(data, dict) else []
        meta = data.get("meta", {}) if isinstance(data, dict) else {}
        tk.Label(
            self.friends_tab_inner, background=self.cur_bg, foreground=self.cur_fg,
            text=f"フレンド {meta.get('friendCount', len(users))}人 ／ 受信中の申請 {meta.get('receiveFriendRequestCount', 0)}件 ／ 送信中 {meta.get('sendFriendRequestCount', 0)}件",
        ).pack(anchor="w", pady=(0, 8))
        if not users:
            tk.Label(self.friends_tab_inner, text="(フレンドがいません)", background=self.cur_bg, foreground="#888").pack(anchor="w")
            return
        for u in users:
            row = tk.Frame(self.friends_tab_inner, background=self.cur_bg)
            row.pack(fill="x", pady=2)
            avatar = tk.Label(row, background=self.cur_bg)
            avatar.pack(side="left", padx=4)
            self._load_small_avatar(u.get("profilePictureFilePath"), avatar)
            info = tk.Frame(row, background=self.cur_bg)
            info.pack(side="left", fill="x", expand=True, padx=6)
            name_lbl = tk.Label(info, text=u.get("name", "?"), background=self.cur_bg, foreground=self.cur_fg,
                                 font=("Yu Gothic UI", 10, "bold"), anchor="w", cursor="hand2")
            name_lbl.pack(fill="x", anchor="w")
            name_lbl.bind("<Button-1>", lambda e, uid=u.get("id"): self._show_user_popup_by_id(uid))
            tk.Label(info, text=u.get("comment") or "", background=self.cur_bg, foreground="#888",
                     anchor="w", wraplength=300, justify="left").pack(fill="x", anchor="w")
            tk.Button(row, text="DM", command=lambda uid=u.get("id"), n=u.get("name", "?"): self.open_dm_window(uid, n),
                      background="#5865F2", foreground="#fff", relief="flat", borderwidth=0).pack(side="right", padx=4)
            ttk.Separator(self.friends_tab_inner, orient="horizontal").pack(fill="x")

    def _build_notices_tab(self) -> None:
        tab = ttk.Frame(self.content_container, padding=8)
        tab.grid(row=0, column=0, sticky="nsew")
        self._sections["notices"] = tab

        ttk.Button(tab, text="更新", command=self.refresh_notices).pack(anchor="w")

        canvas = tk.Canvas(tab, highlightthickness=0)
        scroll = ttk.Scrollbar(tab, orient="vertical", command=canvas.yview)
        self.notices_inner = tk.Frame(canvas, background=self.cur_bg)
        self.notices_inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.notices_inner, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True, pady=6)
        scroll.pack(side="right", fill="y")
        self._bind_mousewheel(canvas)

    def refresh_notices(self) -> None:
        if not self.api:
            return
        for child in self.notices_inner.winfo_children():
            child.destroy()
        import re as _re

        def render_section(title: str, items: list[dict], text_key: str = "text") -> None:
            ttk.Label(self.notices_inner, text=title, font=("Yu Gothic UI", 11, "bold")).pack(anchor="w", pady=(8, 2))
            if not items:
                ttk.Label(self.notices_inner, text="(なし)", foreground="#888").pack(anchor="w", padx=4)
                return
            for n in items:
                card = ttk.Frame(self.notices_inner, padding=8)
                card.pack(fill="x", pady=1)
                ttk.Label(card, text=n.get("title") or n.get("message", ""), font=("Yu Gothic UI", 10, "bold"),
                          wraplength=500, justify="left").pack(anchor="w")
                text = _re.sub("<[^>]+>", "", n.get(text_key, "") or "")
                if text:
                    ttk.Label(card, text=text[:200], wraplength=500, justify="left", foreground="#ccc").pack(anchor="w", pady=(4, 0))
                ttk.Separator(self.notices_inner, orient="horizontal").pack(fill="x")

        try:
            notices = self.api.get_notices()
        except Exception as e:  # noqa: BLE001
            logger.warning("get_notices failed: %s", e)
            notices = []
        try:
            important = self.api.get_important_notifications()
        except Exception as e:  # noqa: BLE001
            logger.warning("get_important_notifications failed: %s", e)
            important = []
        try:
            normal = self.api.get_normal_notifications()
        except Exception as e:  # noqa: BLE001
            logger.warning("get_normal_notifications failed: %s", e)
            normal = []
        finally:
            self._update_dev_panel()

        render_section("運営からのお知らせ", notices, "text")
        render_section("重要な通知", important, "message")
        render_section("通常の通知", normal, "message")

    def _build_dm_tab(self) -> None:
        tab = ttk.Frame(self.content_container, padding=8)
        tab.grid(row=0, column=0, sticky="nsew")
        self._sections["dm"] = tab

        top = ttk.Frame(tab)
        top.pack(fill="x")
        ttk.Button(top, text="更新", command=self.refresh_chats).pack(side="left")
        ttk.Label(top, text="（会話一覧。クリックでメッセージ画面を開きます）", foreground="#888").pack(side="left", padx=8)

        chat_container = ttk.Frame(tab)
        chat_container.pack(fill="both", expand=True, pady=6)
        self.chat_canvas = tk.Canvas(chat_container, highlightthickness=0)
        chat_scroll = tk.Scrollbar(chat_container, orient="vertical", command=self.chat_canvas.yview,
                                    background="#3a3d44", troughcolor=self.cur_bg, highlightthickness=0, borderwidth=0)
        self.chat_inner = tk.Frame(self.chat_canvas, background=self.cur_bg)
        self.chat_inner.bind(
            "<Configure>", lambda e: self.chat_canvas.configure(scrollregion=self.chat_canvas.bbox("all"))
        )
        self.chat_canvas.create_window((0, 0), window=self.chat_inner, anchor="nw")
        self.chat_canvas.configure(yscrollcommand=chat_scroll.set)
        self.chat_canvas.pack(side="left", fill="both", expand=True)
        chat_scroll.pack(side="right", fill="y")
        self._bind_mousewheel(self.chat_canvas)
        self._chats: list[dict] = []

    def refresh_chats(self) -> None:
        if not self.api:
            return
        try:
            chats = self.api.get_chats()
        except Exception as e:  # noqa: BLE001
            logger.warning("get_chats failed: %s", e)
            self._set_status(f"DM一覧取得失敗: {type(e).__name__}")
            return
        finally:
            self._update_dev_panel()
        self._chats = chats
        for child in self.chat_inner.winfo_children():
            child.destroy()
        for c in chats:
            target = c.get("partner") or c.get("targetUser") or c.get("user") or {}
            self._build_chat_row(target, c)
        if not chats:
            ttk.Label(self.chat_inner, text="(会話はまだありません)", foreground="#888").pack(anchor="w", padx=4, pady=4)

    def _build_chat_row(self, target: dict, chat: dict) -> None:
        bg = self.api.config.get("theme_color", "#313338") if self.api else "#313338"
        fg = self.api.config.get("theme_text_color", "#dbdee1") if self.api else "#dbdee1"
        row = tk.Frame(self.chat_inner, background=bg, cursor="hand2")
        row.pack(fill="x", pady=1)

        avatar = tk.Label(row, background=bg)
        avatar.pack(side="left", padx=6, pady=6)
        self._load_small_avatar(target.get("profilePictureFilePath"), avatar)

        text_frame = tk.Frame(row, background=bg)
        text_frame.pack(side="left", fill="x", expand=True, pady=6)
        tk.Label(text_frame, text=target.get("name", "?"), background=bg, foreground=fg, anchor="w",
                 font=("Yu Gothic UI", 10, "bold")).pack(fill="x", anchor="w")
        tk.Label(text_frame, text=chat.get("lastSentAt", ""), background=bg, foreground="#888", anchor="w",
                 font=("Yu Gothic UI", 8)).pack(fill="x", anchor="w")

        def open_this(_e=None):
            self.open_dm_window(target.get("id"), target.get("name", "?"), chat_id=chat.get("chatId"))

        widgets = [row, avatar, text_frame] + list(text_frame.winfo_children())
        for w in widgets:
            w.bind("<Button-1>", open_this)

        def on_enter(_e):
            for w in widgets:
                try:
                    w.configure(background="#3a3d44")
                except tk.TclError:
                    pass

        def on_leave(_e):
            for w in widgets:
                try:
                    w.configure(background=bg)
                except tk.TclError:
                    pass

        row.bind("<Enter>", on_enter)
        row.bind("<Leave>", on_leave)

    def _load_dm_image(self, filename: str | None, label: tk.Label) -> None:
        if not filename or not self.api:
            label.config(text="(画像なし)")
            return
        cache_key = f"dmimg:{filename}"
        cached = self._avatar_cache.get(cache_key)
        if cached is not None:
            label.config(image=cached, text="")
            label._img_ref = cached
            return
        url = self.api.image_url(filename)
        def worker():
            try:
                import requests as _requests
                resp = _requests.get(url, timeout=15)
                resp.raise_for_status()
                img = self._bytes_to_photoimage(resp.content, size=160)
                def apply():
                    self._avatar_cache[cache_key] = img
                    label._img_ref = img
                    label.config(image=img, text="")
                self.after(0, apply)
            except Exception as e:  # noqa: BLE001
                logger.warning("dm image load failed: %s", e)
                self.after(0, lambda: label.config(text="(画像読込失敗)"))
        threading.Thread(target=worker, daemon=True).start()

    def _play_dm_audio(self, filename: str | None) -> None:
        if not filename or not self.api:
            return
        logger.info("DM audio play: %s", filename)
        url = self.api.audio_url(filename)

        def worker():
            try:
                import requests as _requests
                import tempfile
                resp = _requests.get(url, timeout=20)
                resp.raise_for_status()
                suffix = _Path(filename).suffix or ".webm"
                with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
                    f.write(resp.content)
                    path = f.name
                # 既定の関連付けアプリ(ブラウザ等)で再生。追加の再生ライブラリは導入しない
                os.startfile(path)  # noqa: S606 - Windows専用
            except Exception as e:  # noqa: BLE001
                logger.exception("dm audio play failed")
                self.after(0, lambda: messagebox.showerror("再生失敗", f"{type(e).__name__}: {e}"))
        threading.Thread(target=worker, daemon=True).start()

    def open_dm_window(self, target_id, target_name: str = "?", chat_id=None) -> None:
        if not self.api or not target_id:
            return
        win = tk.Toplevel(self)
        win.title(f"DM: {target_name}")
        win.geometry("380x520")
        bg = self.api.config.get("theme_color", "#313338")
        fg = self.api.config.get("theme_text_color", "#dbdee1")
        win.configure(background=bg)

        msg_canvas = tk.Canvas(win, background=bg, highlightthickness=0)
        msg_scroll = tk.Scrollbar(
            win, orient="vertical", command=msg_canvas.yview,
            background="#3a3d44", troughcolor=bg, activebackground="#4a4d54",
            highlightthickness=0, borderwidth=0, relief="flat",
        )
        msg_inner = tk.Frame(msg_canvas, background=bg)
        msg_inner.bind("<Configure>", lambda e: msg_canvas.configure(scrollregion=msg_canvas.bbox("all")))
        msg_canvas.create_window((0, 0), window=msg_inner, anchor="nw")
        msg_canvas.configure(yscrollcommand=msg_scroll.set)
        msg_canvas.pack(side="top", fill="both", expand=True, padx=6, pady=6)
        msg_scroll.pack(side="right", fill="y")

        entry_row = tk.Frame(win, background=bg)
        entry_row.pack(fill="x", padx=8, pady=(0, 8))
        text_var = tk.StringVar()
        entry = tk.Entry(entry_row, textvariable=text_var, background="#3a3d44", foreground=fg,
                          insertbackground=fg, relief="flat", highlightthickness=1,
                          highlightbackground="#4a4d54", highlightcolor="#5865F2")
        entry.pack(side="left", fill="x", expand=True, ipady=4)

        attach_row = tk.Frame(win, background=bg)
        attach_row.pack(fill="x", padx=8, pady=(0, 4))

        def send_image_file():
            if not state["chat_id"]:
                return
            path = filedialog.askopenfilename(filetypes=[("画像", "*.png;*.jpg;*.jpeg;*.gif"), ("すべて", "*.*")])
            if not path:
                return
            try:
                self.api.send_image_message(state["chat_id"], path)
                logger.info("DM image sent: chat_id=%s target=%s file=%s", state["chat_id"], target_id, path)
                play_sound("message")
                load_history()
            except Exception as e:  # noqa: BLE001
                logger.exception("DM image send failed")
                play_sound("error")
                messagebox.showerror("送信失敗", f"{type(e).__name__}: {e}\n(フィールド名は推測のため外れている可能性があります)")
            finally:
                self._update_dev_panel()

        def send_voice_file():
            if not state["chat_id"]:
                return
            path = filedialog.askopenfilename(filetypes=[("音声", "*.m4a;*.mp3;*.wav;*.webm;*.aac"), ("すべて", "*.*")])
            if not path:
                return
            try:
                self.api.send_voice_message(state["chat_id"], path)
                logger.info("DM voice sent: chat_id=%s target=%s file=%s", state["chat_id"], target_id, path)
                play_sound("message")
                load_history()
            except Exception as e:  # noqa: BLE001
                logger.exception("DM voice send failed")
                play_sound("error")
                messagebox.showerror("送信失敗", f"{type(e).__name__}: {e}\n(フィールド名は推測のため外れている可能性があります)")
            finally:
                self._update_dev_panel()

        tk.Button(attach_row, text="🖼 画像を送る", command=send_image_file, background="#3a3d44", foreground=fg,
                  relief="flat", borderwidth=0).pack(side="left")
        tk.Button(attach_row, text="🎤 音声ファイルを送る", command=send_voice_file, background="#3a3d44", foreground=fg,
                  relief="flat", borderwidth=0).pack(side="left", padx=6)

        state = {"chat_id": None, "last_id": None, "messages": {}}  # messages: id -> message dict

        def format_time(sent_at: str) -> str:
            # "2026-07-19T03:12:15.000+09:00" -> "03:12"
            try:
                return sent_at.split("T")[1][:5]
            except Exception:
                return ""

        def render_all() -> None:
            for child in msg_inner.winfo_children():
                child.destroy()
            ordered = sorted(state["messages"].values(), key=lambda m: m.get("id", 0))
            for m in ordered:
                is_mine = str(m.get("userId")) == str(self.api.uid)
                row = tk.Frame(msg_inner, background=bg)
                row.pack(fill="x", pady=2, padx=4, anchor=("e" if is_mine else "w"))

                bubble_bg = "#5865F2" if is_mine else "#3a3d44"
                bubble_fg = "#ffffff"
                msg_type = m.get("messageType")

                if msg_type == "image":
                    bubble = tk.Label(row, background=bubble_bg, text="(画像読込中…)", foreground=bubble_fg, padx=4, pady=4)
                    self._load_dm_image(m.get("binaryFilePath"), bubble)
                elif msg_type == "voice":
                    play_time = m.get("playTime", 0) or 0
                    bubble = tk.Button(
                        row, text=f"▶ 再生 ({play_time:.1f}秒)", background=bubble_bg, foreground=bubble_fg,
                        relief="flat", borderwidth=0, padx=8, pady=5,
                        command=lambda fn=m.get("binaryFilePath"): self._play_dm_audio(fn),
                    )
                else:
                    text = m.get("textMessage") if msg_type == "text" else f"({msg_type})"
                    bubble = tk.Label(
                        row, text=text, background=bubble_bg, foreground=bubble_fg,
                        wraplength=220, justify="left", padx=8, pady=5,
                    )
                meta_text = format_time(m.get("sentAt", ""))
                if is_mine:
                    meta_text = ("既読 " if m.get("isRead") else "未読 ") + meta_text
                meta = tk.Label(row, text=meta_text, background=bg, foreground="#888", font=("Yu Gothic UI", 7))

                if is_mine:
                    meta.pack(side="right", padx=(0, 4))
                    bubble.pack(side="right")
                else:
                    bubble.pack(side="left")
                    meta.pack(side="left", padx=(4, 0))
            msg_canvas.update_idletasks()
            msg_canvas.yview_moveto(1.0)

        def load_history():
            try:
                info = self.api.open_chat(target_id, chat_id=chat_id)
            except Exception as e:  # noqa: BLE001
                messagebox.showerror("取得失敗", str(e))
                return
            finally:
                self._update_dev_panel()
            state["chat_id"] = info.get("meta", {}).get("chatId")
            messages = info.get("chatMessages", [])
            for m in messages:
                if m.get("id"):
                    state["messages"][m["id"]] = m
            render_all()
            ids = [m.get("id") for m in messages if m.get("id")]
            if ids:
                state["last_id"] = max(ids)
            if state["chat_id"]:
                try:
                    self.api.mark_messages_read(state["chat_id"])
                except Exception:  # noqa: BLE001 - 既読化の失敗は致命的でないので無視
                    pass
            schedule_poll()

        def apply_new_messages(info: dict) -> None:
            if not win.winfo_exists():
                return
            messages = info.get("chatMessages", [])
            if messages:
                for m in messages:
                    if m.get("id"):
                        state["messages"][m["id"]] = m
                render_all()
                ids = [m.get("id") for m in messages if m.get("id")]
                if ids:
                    state["last_id"] = max(state.get("last_id") or 0, max(ids))
                if any(str(m.get("userId")) != str(self.api.uid) for m in messages):
                    play_sound("message")
                    if state["chat_id"]:
                        try:
                            self.api.mark_messages_read(state["chat_id"])
                        except Exception:  # noqa: BLE001
                            pass
            schedule_poll()

        def poll_worker() -> None:
            if not win.winfo_exists() or not state["chat_id"]:
                return
            try:
                info = self.api.open_chat(
                    target_id, chat_id=state["chat_id"], current_last_message_id=state.get("last_id")
                )
            except Exception:  # noqa: BLE001 - 通信エラーは静かに無視して次回リトライ
                info = None
            if info is not None:
                self.after(0, lambda: apply_new_messages(info))
            else:
                schedule_poll()

        def schedule_poll() -> None:
            if not win.winfo_exists():
                return
            win._poll_job = win.after(6000, lambda: threading.Thread(target=poll_worker, daemon=True).start())

        def send():
            text = text_var.get().strip()
            if not text or not state["chat_id"]:
                return
            try:
                self.api.send_message(state["chat_id"], text)
                logger.info("DM sent: chat_id=%s target=%s text=%r", state["chat_id"], target_id, text[:80])
                play_sound("message")
                text_var.set("")
                load_history()
            except Exception as e:  # noqa: BLE001
                logger.exception("DM send failed: chat_id=%s target=%s", state["chat_id"], target_id)
                play_sound("error")
                messagebox.showerror("送信失敗", f"{type(e).__name__}: {e}\n(フィールド名は推測のため外れている可能性があります)")
            finally:
                self._update_dev_panel()

        send_btn = tk.Button(entry_row, text="送信", command=send, background="#5865F2", foreground="#fff",
                              activebackground="#4752C4", relief="flat", borderwidth=0, padx=10)
        send_btn.pack(side="left", padx=4)
        entry.bind("<Return>", lambda e: send())

        def on_close():
            job = getattr(win, "_poll_job", None)
            if job:
                try:
                    win.after_cancel(job)
                except Exception:
                    pass
            win.destroy()

        win.protocol("WM_DELETE_WINDOW", on_close)
        load_history()

    def refresh_friends(self) -> None:
        if not self.api:
            return
        for child in self.friend_list_frame.winfo_children():
            child.destroy()
        try:
            data = self.api.get_friends()
        except Exception as e:  # noqa: BLE001
            logger.warning("friend list failed: %s", e)
            return
        finally:
            self._update_dev_panel()
        users = data.get("users", []) if isinstance(data, dict) else []
        if not users:
            tk.Label(self.friend_list_frame, text="(フレンドなし)", foreground="#888").pack(anchor="w", padx=6)
            return
        for u in users:
            row = tk.Frame(self.friend_list_frame, background=self.cur_bg)
            row.pack(fill="x", padx=2, pady=1)
            avatar_lbl = tk.Label(row, background=self.cur_bg)
            avatar_lbl.pack(side="left")
            self._load_small_avatar(u.get("profilePictureFilePath"), avatar_lbl)
            btn = tk.Button(
                row, text=u.get("name", "?"), anchor="w", relief="flat", borderwidth=0,
                background=self.cur_bg, foreground=self.cur_fg, activebackground="#3a3d44",
                command=lambda uid=u.get("id"): self._show_user_popup_by_id(uid),
            )
            btn.pack(side="left", fill="x", expand=True)
            self._add_hover(btn, self.api.config.get("theme_color", "#313338"), "#3a3d44")

    def _load_small_avatar(self, filename: str | None, label: tk.Label) -> None:
        if not filename or not self.api:
            return
        cache_key = f"circ24:{filename}"
        cached = self._avatar_cache.get(cache_key)
        if cached is not None:
            label._img_ref = cached
            label.config(image=cached)
            return
        url = self.api.image_url(filename)
        if not url:
            return
        def worker():
            try:
                import requests as _requests
                resp = _requests.get(url, timeout=10)
                resp.raise_for_status()
                img = self._bytes_to_circular_photoimage(resp.content, size=24)
                def apply():
                    self._avatar_cache[cache_key] = img
                    label._img_ref = img
                    label.config(image=img)
                self.after(0, apply)
            except Exception:
                pass
        threading.Thread(target=worker, daemon=True).start()

    def _show_user_popup_by_id(self, user_id) -> None:
        if not self.api or not user_id:
            return
        self.show_section("search")
        try:
            profile = self.api.get_user(user_id)
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("取得失敗", str(e))
            return
        finally:
            self._update_dev_panel()
        self._render_user_in_search_tab(profile)

    def lookup_other_user(self) -> None:
        if not self.api:
            return
        uid = self.lookup_user_id_var.get().strip()
        if not uid:
            return
        if not uid.isdigit():
            messagebox.showerror("エラー", "idは数字で入力してください")
            return
        self.show_section("search")
        try:
            profile = self.api.get_user(uid)
            self._render_user_in_search_tab(profile)
        except Exception as e:  # noqa: BLE001
            logger.exception("lookup_other_user failed")
            messagebox.showerror("取得失敗", f"{type(e).__name__}: {e}")
        finally:
            self._update_dev_panel()

    def _show_user_popup(self, profile: dict) -> None:
        win = tk.Toplevel(self)
        win.title(f"ユーザー: {profile.get('name', '?')}")
        win.geometry("360x420")
        if self.api:
            win.configure(background=self.api.config.get("theme_color", "#313338"))
        frame = ttk.Frame(win, padding=12)
        frame.pack(fill="both", expand=True)

        img_row = ttk.Frame(frame)
        img_row.pack(fill="x")
        avatar_label = ttk.Label(img_row)
        avatar_label.pack(side="left")
        if self.api:
            url = self.api.image_url(profile.get("profilePictureFilePath"))
            if url:
                try:
                    import requests as _requests
                    resp = _requests.get(url, timeout=10)
                    resp.raise_for_status()
                    img = self._bytes_to_photoimage(resp.content, size=80)
                    win._avatar_ref = img  # 参照保持
                    avatar_label.config(image=img)
                except Exception:
                    avatar_label.config(text="(画像読込失敗)")

        ttk.Label(frame, text=profile.get("name", "?"), font=("Yu Gothic UI", 12, "bold")).pack(anchor="w", pady=(8, 0))
        ttk.Label(frame, text=f"年齢: {profile.get('age', '-')}").pack(anchor="w")
        ttk.Label(frame, text=profile.get("comment") or "", wraplength=320, justify="left").pack(anchor="w", pady=4)
        ttk.Label(
            frame,
            text=f"フォロワー: {profile.get('followerCount', '-')}   フォロー中: {profile.get('followeeCount', '-')}",
        ).pack(anchor="w", pady=(8, 0))
        ttk.Label(frame, text=f"ログイン状況: {profile.get('loginStatusWithUnit', '-')}").pack(anchor="w")
        created = self._extract_created_at(profile)
        ttk.Label(frame, text=f"アカウント作成時期: {created}").pack(anchor="w", pady=(4, 0))

        uid = profile.get("id")
        action_row = ttk.Frame(frame)
        action_row.pack(fill="x", pady=(10, 0))
        ttk.Button(action_row, text="フォロー", command=lambda: self._user_action(self.api.follow_user, uid, "フォローしました")).pack(side="left")
        ttk.Button(action_row, text="フレンド申請", command=lambda: self._user_action(self.api.send_friend_request, uid, "申請を送りました")).pack(side="left", padx=4)
        ttk.Button(action_row, text="ブロック", command=lambda: self._user_action(self.api.block_user, uid, "ブロックしました")).pack(side="left", padx=4)
        ttk.Button(action_row, text="DM", command=lambda: self.open_dm_window(uid, profile.get("name", "?"))).pack(side="left", padx=4)

    def _user_action(self, func, user_id, success_msg: str) -> None:
        if not self.api or not user_id:
            return
        try:
            func(user_id)
            self._set_status(success_msg)
        except Exception as e:  # noqa: BLE001
            logger.exception("user action failed")
            messagebox.showerror("失敗", f"{type(e).__name__}: {e}\n(APIのフィールド名は推測のため外れている可能性があります)")
        finally:
            self._update_dev_panel()

    def change_avatar(self) -> None:
        if not self.api:
            return
        path = filedialog.askopenfilename(filetypes=[("画像", "*.png;*.jpg;*.jpeg"), ("すべて", "*.*")])
        if not path:
            return
        try:
            self.api.set_profile_picture(path)
            self._set_status("アイコンを更新しました")
            self.refresh_profile()
        except Exception as e:  # noqa: BLE001
            logger.exception("set_profile_picture failed")
            messagebox.showerror("失敗", f"{type(e).__name__}: {e}")
        finally:
            self._update_dev_panel()

    def change_header(self) -> None:
        if not self.api:
            return
        path = filedialog.askopenfilename(filetypes=[("画像", "*.png;*.jpg;*.jpeg"), ("すべて", "*.*")])
        if not path:
            return
        try:
            self.api.set_header_image(path)
            self._set_status("ヘッダーを更新しました")
            self.refresh_profile()
        except Exception as e:  # noqa: BLE001
            logger.exception("set_header_image failed")
            messagebox.showerror("失敗", f"{type(e).__name__}: {e}")
        finally:
            self._update_dev_panel()

    def save_profile(self) -> None:
        if not self.api:
            return
        fields = {
            "name": self.profile_vars["name"].get(),
            "comment": self.profile_vars["comment"].get(),
        }
        age_text = self.profile_vars["age"].get().strip()
        if age_text.isdigit():
            fields["age"] = int(age_text)
        try:
            self.api.update_profile(**fields)
            logger.info("profile updated: %s", fields)
            self._set_status("プロフィールを更新しました")
            self.refresh_profile()
        except Exception as e:  # noqa: BLE001
            logger.exception("update_profile failed")
            messagebox.showerror("更新失敗", f"{type(e).__name__}: {e}")
        finally:
            self._update_dev_panel()

    def _set_status(self, text: str) -> None:
        self.status_var.set(text)


if __name__ == "__main__":
    app = KoetomoViewerApp()
    app.mainloop()
