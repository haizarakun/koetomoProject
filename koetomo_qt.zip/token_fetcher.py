"""
koetomo.fun の auth_token / uid / session_id を自動取得して config.json に書き込むツール。

ログイン方法（メール・Google・LINE・Twitterなど、どの方式でログインしても）を問わない。
ブラウザが実際にAPIへ送信したリクエストヘッダーをChrome DevTools Protocol (CDP) で
横取りするだけなので、ログイン手段そのものには一切関与しない。

依存: requests, websocket-client （どちらも `pip install requests websocket-client` で入る）
selenium / selenium-wire は不要。

ログはすべて token_fetcher.log （UTF-8）に出力する。Windowsコンソールの既定エンコーディング
(cp932など)にUnicode文字を直接印字して落ちる問題を避けるため、コンソールへの直接printは
行わない。
"""
from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import scrolledtext, ttk

import requests

if getattr(sys, "frozen", False):
    _BASE_DIR = Path(sys.executable).parent
else:
    _BASE_DIR = Path(__file__).parent

CONFIG_PATH = _BASE_DIR / "config.json"

# token_fetcher.py と qt_app.py(グループ通話・投稿リンク)で共有する専用Chromeプロファイル。
# 普段使いのデフォルトプロファイルを使う方式も試したが、既に通常のChromeが起動していると
# リモートデバッグポートを開けず失敗するため(実運用では常にChromeが開いている前提になり
# 現実的でなかった)、専用プロファイルに戻した。これなら「既に開いていて失敗する」問題が
# 起きず、かつtoken_fetcherでログインしたセッションをqt_app.py側でも確実に共有できる。
SHARED_CHROME_PROFILE_DIR = str(_BASE_DIR / ".koetomo_chrome_profile")
DEBUG_PORT = 9333
TARGET_URL_PART = "a.koetomo.fun/api"

CHROME_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
]

logging.basicConfig(
    filename=Path(__file__).parent / "token_fetcher.log",
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    encoding="utf-8",
)
logger = logging.getLogger(__name__)


def find_chrome() -> str:
    for path in CHROME_CANDIDATES:
        if Path(path).exists():
            return path
    raise FileNotFoundError(
        "chrome.exe が見つかりませんでした。CHROME_CANDIDATES に実際のパスを追加してください。"
    )


class TokenFetcherApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("koetomo auth-token 自動取得")
        self.geometry("600x400")

        self.worker: threading.Thread | None = None
        self.chrome_proc: subprocess.Popen | None = None

        frame = ttk.Frame(self, padding=10)
        frame.pack(fill="both", expand=True)

        ttk.Label(
            frame,
            text=(
                "「取得開始」でChromeを起動します。\n"
                "普段お使いのログイン方法（メール／Google／LINE／Twitterなど何でも）で\n"
                "koetomo.funにログインし、ルーム一覧を表示するなど操作してください。\n"
                "通信を検知したら自動でconfig.jsonに保存します。"
            ),
            wraplength=560,
            justify="left",
        ).pack(anchor="w", pady=(0, 8))

        name_row = ttk.Frame(frame)
        name_row.pack(anchor="w", pady=(0, 8), fill="x")
        ttk.Label(name_row, text="アカウント名:").pack(side="left")
        self.account_name_var = tk.StringVar(value="default")
        ttk.Entry(name_row, textvariable=self.account_name_var, width=20).pack(side="left", padx=6)
        ttk.Label(name_row, text="（複数アカウント管理用。既存名なら上書き）", foreground="#888").pack(side="left")

        self.start_btn = ttk.Button(frame, text="取得開始", command=self.start)
        self.start_btn.pack(anchor="w")

        self.log_widget = scrolledtext.ScrolledText(frame, height=16, state="disabled")
        self.log_widget.pack(fill="both", expand=True, pady=(8, 0))

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def log_line(self, text: str) -> None:
        logger.info(text)

        def _append() -> None:
            self.log_widget.config(state="normal")
            self.log_widget.insert("end", text + "\n")
            self.log_widget.see("end")
            self.log_widget.config(state="disabled")
        self.after(0, _append)

    def start(self) -> None:
        if self.worker and self.worker.is_alive():
            return
        self.start_btn.config(state="disabled")
        self.worker = threading.Thread(target=self._run, daemon=True)
        self.worker.start()

    def _run(self) -> None:
        try:
            self._fetch_and_save()
        except Exception as e:  # noqa: BLE001
            logger.exception("fetch failed")
            self.log_line(f"エラー: {type(e).__name__}: {e}（詳細は token_fetcher.log 参照）")
        finally:
            self.after(0, lambda: self.start_btn.config(state="normal"))

    # ---------- Chrome起動 ----------

    def _launch_chrome(self) -> None:
        chrome_path = find_chrome()
        Path(SHARED_CHROME_PROFILE_DIR).mkdir(parents=True, exist_ok=True)
        args = [
            chrome_path,
            f"--remote-debugging-port={DEBUG_PORT}",
            f"--user-data-dir={SHARED_CHROME_PROFILE_DIR}",
            "--remote-allow-origins=*",
            "--no-first-run",
            "--no-default-browser-check",
            "https://koetomo.fun",
        ]
        self.log_line(f"Chromeを起動しています… ({chrome_path})")
        self.chrome_proc = subprocess.Popen(args)

        for _ in range(30):
            try:
                requests.get(f"http://127.0.0.1:{DEBUG_PORT}/json/version", timeout=1)
                return
            except requests.RequestException:
                time.sleep(0.5)
        raise RuntimeError(
            "Chromeのデバッグポートに接続できませんでした。"
            "しばらく待って、もう一度お試しください。"
        )

    def _get_page_ws_url(self) -> str:
        resp = requests.get(f"http://127.0.0.1:{DEBUG_PORT}/json", timeout=5)
        targets = resp.json()
        for t in targets:
            if t.get("type") == "page" and "koetomo" in t.get("url", ""):
                return t["webSocketDebuggerUrl"]
        for t in targets:
            if t.get("type") == "page":
                return t["webSocketDebuggerUrl"]
        raise RuntimeError("対象タブが見つかりませんでした")

    # ---------- CDPでの監視 ----------

    def _fetch_and_save(self) -> None:
        import websocket  # websocket-client

        self._launch_chrome()
        time.sleep(1.5)
        ws_url = self._get_page_ws_url()
        self.log_line("DevTools Protocolに接続しました。監視を開始します…")

        ws = websocket.create_connection(ws_url, timeout=5)
        ws.settimeout(1.0)
        ws.send(json.dumps({"id": 1, "method": "Network.enable"}))

        pending_url: dict[str, str] = {}
        result: dict[str, str] = {}

        deadline = time.time() + 300  # 5分
        tick = 0
        try:
            while time.time() < deadline:
                try:
                    raw = ws.recv()
                except Exception:
                    tick += 1
                    if tick % 15 == 0:
                        self.log_line("…監視継続中（ログイン操作やルーム一覧の表示をすると検知しやすいです）")
                    continue

                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    continue

                method = msg.get("method")
                params = msg.get("params", {})

                if method == "Network.requestWillBeSent":
                    req_id = params.get("requestId")
                    url = params.get("request", {}).get("url", "")
                    if req_id:
                        pending_url[req_id] = url

                elif method == "Network.requestWillBeSentExtraInfo":
                    req_id = params.get("requestId")
                    url = pending_url.get(req_id, "")
                    if TARGET_URL_PART not in url:
                        continue
                    headers = params.get("headers", {})
                    lower = {k.lower(): v for k, v in headers.items()}
                    if "auth-token" in lower and "uid" in lower:
                        result["auth_token"] = lower["auth-token"]
                        result["uid"] = lower["uid"]
                        cookie = lower.get("cookie", "")
                        m = re.search(r"_session_id=([^;]+)", cookie)
                        if m:
                            result["session_id"] = m.group(1)
                        if all(k in result for k in ("auth_token", "uid", "session_id")):
                            logger.info("captured headers from url=%s", url)
                            break
        finally:
            ws.close()

        if not all(k in result for k in ("auth_token", "uid", "session_id")):
            self.log_line("5分以内に検知できませんでした。ログインしてルーム一覧を表示してみてください。")
            return

        self.log_line("検知しました。config.jsonに保存します。")
        self._save_config(result["auth_token"], result["uid"], result["session_id"])
        self.log_line(f"保存完了: {CONFIG_PATH.name}（アカウント名: {self.account_name_var.get()}）")
        self.log_line("このウィンドウとChromeを閉じて gui_app.py を起動してください。")

    def _save_config(self, auth_token: str, uid: str, session_id: str) -> None:
        from api import save_profile
        name = self.account_name_var.get().strip() or "default"
        save_profile(name, auth_token, uid, session_id, path=CONFIG_PATH)

    def _on_close(self) -> None:
        if self.chrome_proc and self.chrome_proc.poll() is None:
            self.chrome_proc.terminate()
        self.destroy()


if __name__ == "__main__":
    app = TokenFetcherApp()
    app.mainloop()
