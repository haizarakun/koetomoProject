@echo off
REM koetomoクライアント！ Qt版 を .exe 化するビルドスクリプト (Python 3.12固定)
REM 事前準備: Python 3.12 を https://www.python.org/downloads/ からインストールしておく
REM 使い方: このファイルをダブルクリックするだけ

echo ============================================
echo  koetomoクライアント！ (Qt版) をビルドします
echo  Python 3.12 を使用します（3.13/3.14は安定性の
echo  問題が確認されているため、意図的に使いません）
echo ============================================

py -3.12 --version >nul 2>nul
if errorlevel 1 (
    echo Python 3.12 が見つかりませんでした。
    echo https://www.python.org/downloads/ から Python 3.12.x をインストールしてから
    echo もう一度実行してください（インストール時に「Add to PATH」は付けなくてOKです）。
    pause
    exit /b 1
)

echo.
echo [使用するPythonを確認]
py -3.12 --version

echo.
echo [1/3] 依存パッケージをインストール中...
py -3.12 -m pip install -r requirements.txt --quiet
py -3.12 -m pip install pyinstaller --quiet
if errorlevel 1 (
    echo パッケージのインストールに失敗しました。
    pause
    exit /b 1
)

echo.
echo [2/3] koetomo_client.exe をビルド中...
py -3.12 -m PyInstaller --noconfirm --onefile --windowed --name koetomo_client ^
    --add-data "style.qss;." ^
    qt_app.py

echo.
echo [3/3] token_fetcher.exe をビルド中...
py -3.12 -m PyInstaller --noconfirm --onefile --windowed --name token_fetcher token_fetcher.py

echo.
echo 完了しました。dist フォルダの中に koetomo_client.exe と token_fetcher.exe ができています。
echo この2つを同じフォルダにコピーし、config.example.json も一緒に置いてください
echo （config.example.json は自動ではコピーされません。手動でコピーしてください）
echo.
echo 実行するPCにも別途 Python 3.12 相当のランタイムが同梱された状態で動きます
echo （PyInstallerは使ったPythonをexeに埋め込むため、実行側にPythonのインストールは不要です）。
pause
