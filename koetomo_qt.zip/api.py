"""
koetomo.fun の非公開APIへの薄いラッパー（閲覧専用ビューア用）。

自動入室・ポーリング監視・キーワード検知などのロジックは意図的に含めていない。
複数アカウント（プロファイル）切り替えと、開発者モード用の生レスポンス保持に対応。

開発者向けメモ: POST/PUT系メソッドの一部（フレンド申請・ブロック・DM送信・投稿等）は
実際のリクエストボディを観測できておらず、レスポンス構造からの推測実装です。
コード内の各メソッドdocstringに「推測」と明記しているので、動作しない場合はまず
そこを疑ってください。gui_app.pyの開発者モードをONにすると実際のAPIレスポンスが
画面上部に表示されるので、修正時はそれを見ながら調整すると早いです。
"""
from __future__ import annotations

import json
import logging
import sys
from pathlib import Path
from typing import Any

import requests

if getattr(sys, "frozen", False):
    # PyInstaller等でexe化された場合、__file__は一時展開フォルダを指してしまうため、
    # 実際のexeが置かれているフォルダを基準にする
    _BASE_DIR = Path(sys.executable).parent
else:
    _BASE_DIR = Path(__file__).parent

CONFIG_PATH = _BASE_DIR / "config.json"
BASE_URL = "https://a.koetomo.fun"
IMAGE_BASE_URL = "https://s3.ap-northeast-1.amazonaws.com/production.meetscom.com/images"
AUDIO_BASE_URL = "https://s3.ap-northeast-1.amazonaws.com/production.meetscom.com/audio"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/126.0.0.0")

logger = logging.getLogger(__name__)


class AuthError(RuntimeError):
    pass


class ConfigMissingError(RuntimeError):
    pass


def _default_config() -> dict:
    return {
        "profiles": {},
        "active_profile": None,
        "room_url_template": "https://koetomo.fun/talk-rooms/{id}",
        "theme_color": "#313338",
        "theme_text_color": "#dbdee1",
        "background_image_path": None,
        "developer_mode": False,
    }


def load_raw_config(path: Path = CONFIG_PATH) -> dict:
    """config.jsonを読み込み、旧形式(フラットなauth_token等)なら profiles.default に移行して返す。"""
    if not path.exists():
        raise ConfigMissingError(
            f"{path} が見つかりません。token_fetcher.py を実行するか、"
            "config.example.json をコピーして作成してください。"
        )
    data = json.loads(path.read_text(encoding="utf-8"))

    if "profiles" not in data:
        # 旧形式からの移行
        migrated = _default_config()
        if all(k in data for k in ("auth_token", "uid", "session_id")):
            migrated["profiles"]["default"] = {
                "auth_token": data["auth_token"],
                "uid": data["uid"],
                "session_id": data["session_id"],
            }
            migrated["active_profile"] = "default"
        for key in ("room_url_template", "theme_color", "developer_mode"):
            if key in data:
                migrated[key] = data[key]
        data = migrated
        save_raw_config(data, path)
        logger.info("config.jsonを旧形式からprofiles形式へ移行しました")

    for key, val in _default_config().items():
        data.setdefault(key, val)
    if data.get("room_url_template") in (
        "https://koetomo.fun/rooms/{token}",
        "https://koetomo.fun/{id}",
    ):
        data["room_url_template"] = "https://koetomo.fun/talk-rooms/{id}"
        save_raw_config(data, path)
        logger.info("room_url_template を新形式(talk-rooms)に自動更新しました")
    return data


def save_raw_config(data: dict, path: Path = CONFIG_PATH) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def save_profile(name: str, auth_token: str, uid: str, session_id: str, path: Path = CONFIG_PATH) -> None:
    if path.exists():
        data = load_raw_config(path)
    else:
        data = _default_config()
    data["profiles"][name] = {"auth_token": auth_token, "uid": uid, "session_id": session_id}
    data["active_profile"] = name
    save_raw_config(data, path)


class KoetomoAPI:
    def __init__(self, config_path: Path = CONFIG_PATH, profile_name: str | None = None,
                 network_lock=None):
        self.config_path = config_path
        self.config = load_raw_config(config_path)

        self.active_profile = profile_name or self.config.get("active_profile")
        profiles = self.config.get("profiles", {})
        if not profiles:
            raise ConfigMissingError("保存済みのアカウントがありません。token_fetcher.py を実行してください。")
        if self.active_profile not in profiles:
            self.active_profile = next(iter(profiles))
        prof = profiles[self.active_profile]
        self.auth_token: str = prof["auth_token"]
        self.uid: str = str(prof["uid"])
        self.session_id: str = prof["session_id"]

        self.room_url_template: str = self.config.get(
            "room_url_template", "https://koetomo.fun/talk-rooms/{id}"
        )
        self.developer_mode: bool = bool(self.config.get("developer_mode", False))

        self.session = requests.Session()
        # trust_env=False: requestsが環境変数のプロキシ設定や ~/.netrc、Windowsのレジストリ
        # (プロキシ自動検出)を毎回読みに行く挙動を止める。これらはOSのレジストリ/COM関連APIを
        # 呼ぶため、Qtのワーカースレッド(COM未初期化)から呼ぶとネイティブクラッシュ
        # (access violation / ヒープ破損)につながることが実際に確認できたため、無効化する。
        self.session.trust_env = False
        self.session.headers.update({
            "accept": "application/json, text/plain, */*",
            "accept-language": "ja-JP,ja;q=0.9",
            "origin": "https://koetomo.fun",
            "referer": "https://koetomo.fun/",
            "user-agent": UA,
        })
        # requests.Session は複数スレッドから同時に使うことは推奨されていない
        # (公式にスレッドセーフとは明言されていない)。koetomo_qtではQThreadPoolの
        # 複数ワーカースレッドから同じ KoetomoAPI インスタンスのメソッドが並行に
        # 呼ばれるため、実際の通信部分だけロックで直列化して事故を防ぐ。
        # network_lock が外部(呼び出し側アプリ)から渡された場合はそれを使い、
        # アプリ全体(画像ダウンロード等も含めて)で通信を1本化できるようにする。
        import threading
        self._session_lock = network_lock if network_lock is not None else threading.Lock()

        # 開発者モード用: 直近のリクエスト/レスポンスを保持
        self.last_request: dict[str, Any] = {}

    def list_profiles(self) -> list[str]:
        return list(self.config.get("profiles", {}).keys())

    def switch_profile(self, name: str) -> None:
        profiles = self.config.get("profiles", {})
        if name not in profiles:
            raise KeyError(f"プロファイル '{name}' は存在しません")
        prof = profiles[name]
        self.active_profile = name
        self.auth_token = prof["auth_token"]
        self.uid = str(prof["uid"])
        self.session_id = prof["session_id"]
        self.config["active_profile"] = name
        save_raw_config(self.config, self.config_path)

    def set_theme_color(self, color: str) -> None:
        self.config["theme_color"] = color
        save_raw_config(self.config, self.config_path)

    def set_developer_mode(self, enabled: bool) -> None:
        self.developer_mode = enabled
        self.config["developer_mode"] = enabled
        save_raw_config(self.config, self.config_path)

    def set_room_url_template(self, template: str) -> None:
        self.room_url_template = template
        self.config["room_url_template"] = template
        save_raw_config(self.config, self.config_path)

    def _headers(self) -> dict[str, str]:
        return {
            "auth-token": self.auth_token,
            "uid": self.uid,
            "cookie": f"_session_id={self.session_id}",
        }

    def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        url = f"{BASE_URL}{path}"
        with self._session_lock:
            logger.info("GET %s params=%s (profile=%s)", url, params, self.active_profile)
            resp = self.session.get(url, params=params, headers=self._headers(), timeout=10)

        self.last_request = {
            "url": resp.url,
            "status": resp.status_code,
            "raw_text": resp.text[:5000],
        }
        if self.developer_mode:
            logger.debug("response[%s]: %s", resp.status_code, resp.text[:2000])

        if resp.status_code in (401, 403):
            raise AuthError(
                "認証切れです。token_fetcher.py を再実行するか、ブラウザで再ログイン後トークンを更新してください。"
            )
        resp.raise_for_status()
        return resp.json()

    def get_rooms(self, page: int = 1, order: str = "opened_at_desc") -> list[dict]:
        data = self._get("/api/rooms", params={"page": page, "order": order})
        if isinstance(data, dict) and "rooms" in data:
            return data["rooms"]
        if isinstance(data, list):
            return data
        logger.warning("想定外のレスポンス形状: %r", type(data))
        return []

    # ---------- TL（フィード） ----------

    def get_feed_posts(self, page: int = 1) -> list[dict]:
        data = self._get("/api/feed_posts", params={"page": page})
        return data if isinstance(data, list) else []

    def get_feed_posts_multi(self, pages: int = 1) -> list[dict]:
        all_posts: list[dict] = []
        for p in range(1, pages + 1):
            posts = self.get_feed_posts(page=p)
            if not posts:
                break
            all_posts.extend(posts)
        return all_posts

    def image_url(self, filename: str | None) -> str | None:
        if not filename:
            return None
        return f"{IMAGE_BASE_URL}/{filename}"

    def audio_url(self, filename: str | None) -> str | None:
        if not filename:
            return None
        return f"{AUDIO_BASE_URL}/{filename}"

    def get_user(self, user_id: str | int | None = None) -> dict:
        uid = user_id or self.uid
        return self._get(f"/api/users/{uid}")

    def get_chats(self, page: int = 1) -> list[dict]:
        data = self._get("/api/chats", params={"page": page})
        return data if isinstance(data, list) else []

    def open_chat(self, target_id: int | str, chat_id: int | str | None = None,
                  current_last_message_id: int | str | None = None) -> dict:
        params = {"target_id": target_id}
        if chat_id:
            params["chat_id"] = chat_id
        if current_last_message_id:
            params["current_last_message_id"] = current_last_message_id
        return self._get("/api/chat/open", params=params)

    def send_message(self, chat_id: int | str, text: str) -> Any:
        """DM送信。フィールド名は推測(chatId/textMessage)。失敗する場合はここを調整。"""
        return self._mutate("POST", "/api/chat/send_message", {"chatId": chat_id, "textMessage": text})

    def send_image_message(self, chat_id: int | str, file_path: str) -> Any:
        """DMで画像を送信。フィールド名は推測。"""
        filename = self.upload_image_file(file_path)
        return self._mutate(
            "POST", "/api/chat/send_message",
            {"chatId": chat_id, "messageType": "image", "binaryFilePath": filename},
        )

    def send_voice_message(self, chat_id: int | str, file_path: str) -> Any:
        """DMで音声ファイルを送信。フィールド名は推測。"""
        info = self._mutate("POST", "/api/generate_audio_presigned_url")
        presigned_url = info["url"]
        with open(file_path, "rb") as f:
            data = f.read()
        resp = requests.put(presigned_url, data=data, timeout=30)
        resp.raise_for_status()
        from urllib.parse import urlparse
        filename = urlparse(presigned_url).path.rsplit("/", 1)[-1]
        return self._mutate(
            "POST", "/api/chat/send_message",
            {"chatId": chat_id, "messageType": "voice", "binaryFilePath": filename},
        )

    def mark_messages_read(self, chat_id: int | str) -> Any:
        return self._mutate("POST", "/api/chat/message_read", {"chatId": chat_id})

    def get_comments(self, post_id: int | str, page: int = 1) -> list[dict]:
        data = self._get(f"/api/feed_posts/{post_id}/comments", params={"page": page})
        return data if isinstance(data, list) else []

    def get_block_list(self, page: int = 1) -> list[dict]:
        data = self._get("/api/block_list", params={"page": page})
        if isinstance(data, dict) and "users" in data:
            return data["users"]
        return data if isinstance(data, list) else []

    def get_notices(self, page: int = 1) -> list[dict]:
        data = self._get("/api/notices", params={"page": page})
        return data if isinstance(data, list) else []

    def get_normal_notifications(self, page: int = 1) -> list[dict]:
        data = self._get("/api/normal_notifications", params={"page": page})
        return data if isinstance(data, list) else []

    def get_important_notifications(self, page: int = 1) -> list[dict]:
        data = self._get("/api/important_notifications", params={"page": page})
        if isinstance(data, dict):
            return data.get("userNotifications", [])
        return []

    def get_user_feed_posts(self, user_id: int | str, page: int = 1) -> list[dict]:
        """つぶやき(feed_posts)の、指定ユーザーの投稿履歴"""
        data = self._get("/api/feed_posts/history", params={"user_id": user_id, "page": page})
        return data if isinstance(data, list) else []

    def get_user_timeline_posts(self, user_id: int | str, page: int = 1) -> list[dict]:
        """話そう(timeline_posts)の、指定ユーザーの投稿履歴"""
        data = self._get("/api/timeline_posts/history", params={"user_id": user_id, "page": page})
        return data if isinstance(data, list) else []

    def get_friends(self, target_type: str = "friend", page: int = 1) -> dict:
        """target_type: friend / receive(申請を受けた) / send(申請を送った)"""
        return self._get("/api/myfriends", params={"page": page, "target_type": target_type})

    def send_friend_request(self, user_id: int | str) -> Any:
        return self._mutate("POST", "/api/friend_request/send", {"userId": user_id})

    def unfriend(self, user_id: int | str) -> Any:
        return self._mutate("POST", "/api/friend_request/unfriend", {"userId": user_id})

    def follow_user(self, user_id: int | str) -> Any:
        return self._mutate("POST", "/api/follow", {"userId": user_id})

    def block_user(self, user_id: int | str) -> Any:
        return self._mutate("POST", "/api/block", {"userId": user_id})

    def unblock_user(self, user_id: int | str) -> Any:
        return self._mutate("POST", "/api/unblock", {"userId": user_id})

    def search_users_by_name(self, name: str) -> list[dict]:
        """名前でユーザー検索(エンドポイント未確認・推測)。"""
        data = self._get("/api/users", params={"name": name})
        if isinstance(data, dict) and "users" in data:
            return data["users"]
        if isinstance(data, list):
            return data
        return []

    def _mutate(self, method: str, path: str, json_body: dict | None = None) -> Any:
        url = f"{BASE_URL}{path}"
        with self._session_lock:
            logger.info("%s %s body=%s (profile=%s)", method, url, json_body, self.active_profile)
            resp = self.session.request(method, url, json=json_body, headers=self._headers(), timeout=10)
        self.last_request = {"url": resp.url, "status": resp.status_code, "raw_text": resp.text[:5000]}
        if self.developer_mode:
            logger.debug("response[%s]: %s", resp.status_code, resp.text[:2000])
        if resp.status_code in (401, 403):
            raise AuthError("認証切れです。token_fetcher.py を再実行してください。")
        resp.raise_for_status()
        if resp.text:
            try:
                return resp.json()
            except ValueError:
                return resp.text
        return None

    def create_post(self, text: str) -> Any:
        """投稿する。フィールド名は推測(description)。失敗する場合はここを調整。"""
        return self._mutate("POST", "/api/feed_posts", {"description": text})

    def delete_post(self, post_id: int | str) -> Any:
        return self._mutate("DELETE", f"/api/feed_posts/{post_id}")

    def like_post(self, post_id: int | str) -> Any:
        return self._mutate("POST", f"/api/feed_posts/{post_id}/like")

    def bookmark_post(self, post_id: int | str) -> Any:
        return self._mutate("POST", f"/api/feed_posts/{post_id}/bookmark")

    def comment_post(self, post_id: int | str, text: str) -> Any:
        """コメントする。フィールド名は推測(comment)。失敗する場合はここを調整。"""
        return self._mutate("POST", f"/api/feed_posts/{post_id}/comment", {"comment": text})

    # ---------- プロフィール ----------

    def update_profile(self, **fields) -> Any:
        """自分のプロフィールを更新する。fields は comment/age/name などGETで見える項目名をそのまま使う。"""
        return self._mutate("PUT", f"/api/users/{self.uid}", fields)

    # ---------- 画像アップロード ----------

    def request_image_upload_url(self) -> dict:
        return self._mutate("POST", "/api/generate_image_presigned_url")

    def upload_image_file(self, file_path: str) -> str:
        """画像をアップロードし、プロフィール等で使うファイル名を返す。"""
        info = self.request_image_upload_url()
        presigned_url = info["url"]
        with open(file_path, "rb") as f:
            data = f.read()
        resp = requests.put(presigned_url, data=data, timeout=30)
        resp.raise_for_status()
        # presigned URLのパス末尾がファイル名
        from urllib.parse import urlparse
        filename = urlparse(presigned_url).path.rsplit("/", 1)[-1]
        return filename

    def set_profile_picture(self, file_path: str) -> Any:
        filename = self.upload_image_file(file_path)
        return self.update_profile(profilePictureFilePath=filename)

    def set_header_image(self, file_path: str) -> Any:
        filename = self.upload_image_file(file_path)
        try:
            return self._mutate("PUT", "/api/profile_header", {"headerImageFilePath": filename})
        except Exception:
            return self.update_profile(headerImageFilePath=filename)

    def get_rooms_multi(self, pages: int = 1, order: str = "opened_at_desc") -> list[dict]:
        """複数ページ分のルームをまとめて取得する。"""
        all_rooms: list[dict] = []
        for p in range(1, pages + 1):
            rooms = self.get_rooms(page=p, order=order)
            if not rooms:
                break
            all_rooms.extend(rooms)
        return all_rooms
