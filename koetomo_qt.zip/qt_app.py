"""
koetomoクライアント！ Qt(PySide6)版。

ブラウザエンジン(Chromium/WebView)を一切使わない、ネイティブ描画のデスクトップアプリ。
ロジックはkoetomo_viewerと同じ api.py (KoetomoAPI) をそのまま再利用している。

開発者向けメモ:
  - ネットワーク呼び出しはすべて素の threading.Thread で別スレッド化し、UIをブロックしない
    (QThreadPool/QRunnableは環境依存のネイティブクラッシュが確認されたため使用していない)
  - グループ通話・投稿(reCAPTCHA対策)は、意図的に webbrowser.open() でOS既定のブラウザ
    (普段使っているChrome等)に委譲している。特別なプロファイル指定やアプリ内蔵ブラウザは使わない
  - スタイルは style.qss (Discord風の配色・角丸) を読み込んで適用している
"""
from __future__ import annotations

import logging
import os
import sys
import threading as _threading
import webbrowser

CHROME_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
]


def open_in_browser(url: str, api: "KoetomoAPI | None" = None) -> None:
    """
    声とも(koetomo.fun)はログインを同時に1ブラウザでしか維持できないため、
    token_fetcher.pyでログインしたのと同じ専用Chromeプロファイルで開く。
    設定で任意のブラウザの実行ファイルパスを指定していれば、そちらを優先する
    (その場合はプロファイル指定なしで起動する)。
    """
    import subprocess
    custom_path = None
    if api is not None:
        custom_path = api.config.get("browser_path")
    if custom_path and Path(custom_path).exists():
        try:
            subprocess.Popen([custom_path, url])
            return
        except Exception as e:  # noqa: BLE001
            logger.warning("custom browser launch failed: %s", e)
    for p in CHROME_CANDIDATES:
        local = os.path.expandvars(p) if "%" in p else p
        if Path(local).exists():
            try:
                subprocess.Popen([local, url, f"--user-data-dir={SHARED_CHROME_PROFILE_DIR}"])
                return
            except Exception as e:  # noqa: BLE001
                logger.warning("Chrome launch failed: %s", e)
                break
    # Chromeが見つからない場合のみ、OS既定のブラウザにフォールバック
    webbrowser.open(url)

from pathlib import Path

import requests

from PySide6.QtCore import Qt, QObject, QSize, Signal, QTimer
from PySide6.QtGui import QPixmap, QIcon, QDesktopServices
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QListWidget, QListWidgetItem, QStackedWidget, QLineEdit,
    QTextEdit, QComboBox, QTableWidget, QTableWidgetItem, QHeaderView,
    QScrollArea, QFrame, QMessageBox, QDialog, QColorDialog, QFileDialog,
    QSplitter,
)

if getattr(sys, "frozen", False):
    BASE_DIR = Path(sys.executable).parent
else:
    BASE_DIR = Path(__file__).parent

# token_fetcher.pyと共有する専用Chromeプロファイル。普段使いのデフォルトプロファイルだと
# 「既にChromeが起動していると失敗する」問題があり実運用に耐えなかったため、
# token_fetcher.py側と同じ専用プロファイルに統一している(BASE_DIR基準で同じ場所)。
SHARED_CHROME_PROFILE_DIR = str(BASE_DIR / ".koetomo_chrome_profile")

logging.basicConfig(
    filename=str(BASE_DIR / "app.log"),
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    encoding="utf-8",
)
logger = logging.getLogger(__name__)

# どのPython/どの起動で発生した記録か後から確実に分かるよう、起動のたびに必ず記録する。
logger.info("=== 起動 === Python %s (%s) / %s", sys.version.split()[0], sys.executable, sys.platform)

# ネイティブレベルのクラッシュ(SIGSEGV等、Pythonの例外にすらならないもの)が起きた場合でも
# 手がかりを残すため、faulthandlerで別ファイルに書き出す。
# 過去の記録と混ざって分かりにくくならないよう、起動のたびに新規作成("w")する
# (追記("a")だと、別のPythonバージョンで実行した際の記録と混在してしまい、
#  原因の切り分けを誤らせることが実際にあったため)。
import faulthandler
_fault_log = open(BASE_DIR / "crash.log", "w", encoding="utf-8")
_fault_log.write(f"=== Python {sys.version} ({sys.executable}) ===\n\n")
_fault_log.flush()
faulthandler.enable(file=_fault_log, all_threads=True)


def _excepthook(exc_type, exc_value, exc_tb):
    """通常のPython例外が、どこにもcatchされず上まで漏れてきた場合の最終防衛ライン。
    デフォルトのままだとコンソールが無い起動方法(pythonw等)では何も見えずに消えてしまう。"""
    logger.error("Uncaught exception", exc_info=(exc_type, exc_value, exc_tb))


sys.excepthook = _excepthook

sys.path.insert(0, str(BASE_DIR))
from api import AuthError, ConfigMissingError, KoetomoAPI, load_raw_config, save_raw_config  # noqa: E402


# ---------- 非同期実行ヘルパー ----------

# ログ出力(logging)自体も、複数スレッドから同時に呼ばれるとクラッシュにつながることが
# 実際に確認できたため(logging内部のフレーム調査処理でaccess violation)、
# アプリ独自にもロックをかけて完全に1件ずつにする。標準のloggingは本来スレッドセーフの
# はずだが、今回の環境では実際にそこで落ちたため、保険として直列化する。
LOG_LOCK = _threading.Lock()


def safe_log_exception(message: str) -> None:
    with LOG_LOCK:
        logger.exception(message)


class Worker(QObject):
    """
    QThreadPool/QRunnableではなく、素のPython threading.Threadでバックグラウンド実行する。
    検証の結果、このアプリの環境ではQThreadPoolが生成するスレッド([Thread (pooled)]と
    表示される)の中でだけ、SSL・logging・netrcなど全く無関係な標準ライブラリの内部で
    ネイティブクラッシュ(access violation / ヒープ破損)が繰り返し発生した。
    一方、Qtを使っていないFlask版(koetomo_viewer、素のthreading.Threadでリクエストを
    処理している)では同じ処理内容で問題が起きていない。
    そのため、QThreadPoolのスレッド生成そのものが原因である可能性が高いと判断し、
    ここでは素の threading.Thread を使う方式に切り替えている。
    シグナル(finished/error)自体はQObjectのものをそのまま使い、メインスレッドへの
    受け渡し(QueuedConnection)はこれまで通り機能する。
    """
    finished = Signal(object)
    error = Signal(str)

    def __init__(self, fn, *args, **kwargs):
        super().__init__()
        self.fn = fn
        self.args = args
        self.kwargs = kwargs

    def start(self) -> None:
        thread = _threading.Thread(target=self._run, daemon=True)
        thread.start()

    def _run(self) -> None:
        try:
            result = self.fn(*self.args, **self.kwargs)
            self.finished.emit(result)
        except Exception as e:  # noqa: BLE001
            safe_log_exception("background task failed")
            self.error.emit(str(e))


def safe_widget_callback(fn):
    """
    タブ切替・一覧再読込等で対象のウィジェットが既に破棄された後に、遅れて非同期処理の
    結果(アイコン画像など)が届いて書き込もうとすると RuntimeError (Internal C++ object
    already deleted) でクラッシュ相当の動作になることがある。「間に合わなかっただけ」で
    実害は無いケースなので、そのケースだけ黙って無視する。
    """
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except RuntimeError as e:
            if "already deleted" in str(e) or "Internal C++ object" in str(e):
                logger.info("stale widget callback ignored: %s", e)
                return None
            raise
    return wrapper


_active_workers: set = set()


def run_async(fn, on_success=None, on_error=None, *args, **kwargs):
    worker = Worker(fn, *args, **kwargs)
    _active_workers.add(worker)

    def _cleanup(_result=None):
        _active_workers.discard(worker)

    worker.finished.connect(_cleanup, Qt.QueuedConnection)
    worker.error.connect(_cleanup, Qt.QueuedConnection)
    # 明示的にQueuedConnectionを指定し、コールバックが必ずメインスレッド(GUIスレッド)側で
    # 実行されるようにする。素のlambda/関数へのconnectはAutoConnectionだと接続先の
    # スレッドを判定できず、ワーカースレッド側でそのまま実行されてしまうことがあり、
    # それがGUI部品を直接触る処理と組み合わさると不定期なクラッシュの原因になる。
    if on_success:
        worker.finished.connect(safe_widget_callback(on_success), Qt.QueuedConnection)
    if on_error:
        worker.error.connect(safe_widget_callback(on_error), Qt.QueuedConnection)
    else:
        worker.error.connect(
            lambda msg: logger.warning("async error: %s", msg), Qt.QueuedConnection
        )
    worker.start()


def image_url(filename: str | None) -> str | None:
    if not filename:
        return None
    return f"https://s3.ap-northeast-1.amazonaws.com/production.meetscom.com/images/{filename}"


# 検証の結果、Python 3.14 環境でSSL通信を複数スレッドから並行実行すると、requests/ssl.py内部で
# "Windows fatal exception: code 0xc0000374" (STATUS_HEAP_CORRUPTION) というネイティブレベルの
# クラッシュが実際に発生することを crash.log で確認した。同時4件までへの制限では防ぎきれなかった
# ため、さらに踏み込んで「アプリ全体で同時に通信できるのは常に1件だけ」に強制する。
# これは api.py 側の通信(_get/_mutate)とも同じロックを共有し、アプリ全体でHTTP通信が
# 完全に直列化されるようにするための、アプリ側で用意する共有ロック。
NETWORK_LOCK = _threading.Lock()
_image_session = requests.Session()
_image_session.trust_env = False  # 理由はapi.py側の同様の箇所を参照


def download_image_bytes(url: str) -> bytes | None:
    """ワーカースレッドで安全に呼べる、ダウンロードだけを行う関数。QPixmap等のQtオブジェクトは
    ここでは一切作らない(QPixmapはGUIスレッド以外で触るとクラッシュしうるため)。"""
    with NETWORK_LOCK:
        try:
            resp = _image_session.get(url, timeout=10)
            resp.raise_for_status()
            return resp.content
        except Exception as e:  # noqa: BLE001
            logger.warning("image download failed: %s", e)
            return None


def pixmap_from_bytes(data: bytes | None, size: int | None = None) -> QPixmap | None:
    """必ずメインスレッド(GUIスレッド)側のコールバックから呼ぶこと。"""
    if not data:
        return None
    pix = QPixmap()
    pix.loadFromData(data)
    if pix.isNull():
        return None
    if size:
        pix = pix.scaled(size, size, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
    return pix


def cover_crop_pixmap(pix: QPixmap, target_w: int, target_h: int) -> QPixmap:
    """
    setScaledContents(True)は縦横比を無視して引き伸ばすため、バナー画像等が
    ビヨーンと歪んで見える原因になっていた。ここでは「アスペクト比を保ったまま
    領域いっぱいに拡大し、はみ出た分を中央基準で切り取る」方式(CSSのobject-fit: cover
    相当)にして、歪まないようにする。
    """
    scaled = pix.scaled(target_w, target_h, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
    x = max(0, (scaled.width() - target_w) // 2)
    y = max(0, (scaled.height() - target_h) // 2)
    return scaled.copy(x, y, target_w, target_h)


def round_pixmap(pix: QPixmap, size: int) -> QPixmap:
    from PySide6.QtGui import QPainter, QPainterPath
    rounded = QPixmap(size, size)
    rounded.fill(Qt.transparent)
    painter = QPainter(rounded)
    painter.setRenderHint(QPainter.Antialiasing)
    path = QPainterPath()
    path.addEllipse(0, 0, size, size)
    painter.setClipPath(path)
    scaled = pix.scaled(size, size, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
    painter.drawPixmap(0, 0, scaled)
    painter.end()
    return rounded


# ---------- メインウィンドウ ----------

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("koetomoクライアント！")
        self.resize(1180, 780)
        self.api: KoetomoAPI | None = None
        self._avatar_cache: dict[str, QPixmap] = {}

        self._build_ui()
        self._init_api()

        self.config_watch_timer = QTimer(self)
        self.config_watch_timer.timeout.connect(self._watch_config)
        self.config_watch_timer.start(3000)
        self._last_mtime = None

    # ---------- 初期化 ----------

    def _init_api(self) -> None:
        try:
            self.api = KoetomoAPI(network_lock=NETWORK_LOCK)
            self._refresh_account_combo()
            self.status_label.setText(f"アカウント: {self.api.active_profile}")
            self.refresh_all()
        except (ConfigMissingError, AuthError) as e:
            self.status_label.setText(str(e))
            QMessageBox.warning(self, "設定が必要です", f"{e}\ntoken_fetcher.py を実行してログインしてください。")

    def refresh_all(self) -> None:
        self.refresh_rooms()
        self.refresh_feed()
        self.refresh_profile()
        self.refresh_friends_sidebar()

    def _watch_config(self) -> None:
        if not self.api:
            return
        try:
            mtime = self.api.config_path.stat().st_mtime
        except OSError:
            return
        if self._last_mtime is not None and mtime != self._last_mtime:
            logger.info("config.json changed, auto-reloading")
            self._init_api()
        self._last_mtime = mtime

    # ---------- UI構築 ----------

    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # --- サイドバー ---
        sidebar = QWidget()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(240)
        side_layout = QVBoxLayout(sidebar)
        side_layout.setContentsMargins(8, 12, 8, 8)

        title = QLabel("koetomoクライアント！")
        title.setObjectName("appTitle")
        side_layout.addWidget(title)

        self.nav_buttons: dict[str, QPushButton] = {}
        for key, label in [
            ("rooms", "# グループ通話"), ("feed", "# タイムライン"), ("profile", "# プロフィール"),
            ("dm", "# DM"), ("search", "# 検索"), ("friends", "# フレンド"), ("notices", "# お知らせ"),
        ]:
            btn = QPushButton(label)
            btn.setObjectName("navBtn")
            btn.setCheckable(True)
            btn.clicked.connect(lambda _c, k=key: self.show_section(k))
            side_layout.addWidget(btn)
            self.nav_buttons[key] = btn

        side_layout.addWidget(QLabel("フレンド", objectName="sectionLabel"))
        self.friend_list_widget = QListWidget()
        self.friend_list_widget.setIconSize(QSize(22, 22))
        self.friend_list_widget.setObjectName("friendList")
        self.friend_list_widget.itemClicked.connect(self._on_friend_clicked)
        side_layout.addWidget(self.friend_list_widget, 1)

        account_row = QVBoxLayout()
        account_row.setSpacing(4)
        self.account_combo = QComboBox()
        self.account_combo.currentIndexChanged.connect(self._on_account_change)
        self.account_combo.setMinimumWidth(0)
        self.account_combo.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.account_combo.setMinimumContentsLength(6)
        account_row.addWidget(self.account_combo)

        icon_row = QHBoxLayout()
        icon_row.setSpacing(6)
        reload_btn = QPushButton("⟳")
        reload_btn.setFixedSize(32, 28)
        reload_btn.setToolTip("アカウント一覧を更新")
        reload_btn.clicked.connect(lambda: self._init_api())
        icon_row.addWidget(reload_btn)
        login_btn = QPushButton("＋")
        login_btn.setFixedSize(32, 28)
        login_btn.setToolTip("ログイン追加")
        login_btn.clicked.connect(self._launch_login)
        icon_row.addWidget(login_btn)
        settings_btn = QPushButton("⚙")
        settings_btn.setFixedSize(32, 28)
        settings_btn.setToolTip("設定")
        settings_btn.clicked.connect(self._open_settings)
        icon_row.addWidget(settings_btn)
        icon_row.addStretch(1)
        account_row.addLayout(icon_row)
        side_layout.addLayout(account_row)

        root.addWidget(sidebar)

        # --- メインエリア ---
        main_area = QWidget()
        main_layout = QVBoxLayout(main_area)
        main_layout.setContentsMargins(16, 8, 16, 16)

        status_row = QHBoxLayout()
        status_row.addStretch(1)
        self.status_label = QLabel("起動中…")
        self.status_label.setObjectName("statusLabel")
        status_row.addWidget(self.status_label)
        main_layout.addLayout(status_row)

        self.stack = QStackedWidget()
        main_layout.addWidget(self.stack, 1)

        self.section_indices: dict[str, int] = {}
        self.section_indices["rooms"] = self.stack.addWidget(self._build_rooms_page())
        self.section_indices["feed"] = self.stack.addWidget(self._build_feed_page())
        self.section_indices["profile"] = self.stack.addWidget(self._build_profile_page())
        self.section_indices["dm"] = self.stack.addWidget(self._build_dm_page())
        self.section_indices["search"] = self.stack.addWidget(self._build_search_page())
        self.section_indices["friends"] = self.stack.addWidget(self._build_friends_page())
        self.section_indices["notices"] = self.stack.addWidget(self._build_notices_page())

        root.addWidget(main_area, 1)

        self.show_section("rooms")

    def show_section(self, key: str) -> None:
        self.stack.setCurrentIndex(self.section_indices[key])
        for k, btn in self.nav_buttons.items():
            btn.setChecked(k == key)
        if key == "dm":
            self.refresh_chats()
        elif key == "friends":
            self.refresh_friends_page()
        elif key == "notices":
            self.refresh_notices()

    # ---------- グループ通話 ----------

    def _build_rooms_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        toolbar = QHBoxLayout()
        refresh_btn = QPushButton("一覧を更新")
        refresh_btn.clicked.connect(self.refresh_rooms)
        toolbar.addWidget(refresh_btn)
        self.rooms_order = QComboBox()
        self.rooms_order.addItems(["新しい順", "古い順", "人数が多い順"])
        self.rooms_order.currentIndexChanged.connect(self.refresh_rooms)
        toolbar.addWidget(self.rooms_order)
        self.rooms_pages = QComboBox()
        self.rooms_pages.addItems(["1ページ", "2ページ", "3ページ", "5ページ", "10ページ"])
        self.rooms_pages.currentIndexChanged.connect(self.refresh_rooms)
        toolbar.addWidget(self.rooms_pages)
        self.rooms_search = QLineEdit()
        self.rooms_search.setPlaceholderText("説明で検索")
        self.rooms_search.textChanged.connect(self._apply_room_filter)
        toolbar.addWidget(self.rooms_search)
        toolbar.addStretch(1)
        layout.addLayout(toolbar)

        self.rooms_table = QTableWidget(0, 5)
        self.rooms_table.setHorizontalHeaderLabels(["説明", "人数", "オーナー", "開始時刻", "参加者"])
        self.rooms_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.rooms_table.setColumnWidth(1, 50)
        self.rooms_table.setColumnWidth(2, 160)
        self.rooms_table.setColumnWidth(3, 190)
        self.rooms_table.setColumnWidth(4, 190)
        self.rooms_table.verticalHeader().setDefaultSectionSize(34)
        self.rooms_table.verticalHeader().setVisible(False)
        self.rooms_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.rooms_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.rooms_table.cellDoubleClicked.connect(self._open_selected_room)
        layout.addWidget(self.rooms_table, 1)

        open_btn = QPushButton("選択したグループ通話を開く")
        open_btn.clicked.connect(lambda: self._open_selected_room(self.rooms_table.currentRow(), 0))
        layout.addWidget(open_btn)
        self._all_rooms: list[dict] = []
        return page

    def refresh_rooms(self) -> None:
        if not self.api:
            return
        order_map = {"新しい順": "opened_at_desc", "古い順": "opened_at_asc", "人数が多い順": "member_count_desc"}
        order = order_map.get(self.rooms_order.currentText(), "opened_at_desc")
        run_async(self.api.get_rooms_multi, self._on_rooms_loaded, self._on_error, pages=int(self.rooms_pages.currentText().replace("ページ", "")), order=order)

    def _on_rooms_loaded(self, rooms: list[dict]) -> None:
        self._all_rooms = rooms
        self._apply_room_filter()
        self.status_label.setText(f"{len(rooms)}件のグループ通話を取得しました")

    def _apply_room_filter(self) -> None:
        keyword = self.rooms_search.text().strip()
        rooms = self._all_rooms
        if keyword:
            rooms = [r for r in rooms if keyword in (r.get("description") or "")]
        self.rooms_table.setRowCount(len(rooms))
        for i, r in enumerate(rooms):
            owner = r.get("ownerUser") or {}
            self.rooms_table.setItem(i, 0, QTableWidgetItem(r.get("description", "")))
            self.rooms_table.setItem(i, 1, QTableWidgetItem(str(len(r.get("members", []) or []))))
            self.rooms_table.setCellWidget(i, 2, self._make_user_chip(owner))
            self.rooms_table.setItem(i, 3, QTableWidgetItem(r.get("openedAt", "")))
            self.rooms_table.setCellWidget(i, 4, self._make_participants_row(r.get("members", []) or []))
            self.rooms_table.item(i, 0).setData(Qt.UserRole, r.get("id"))
        self._filtered_rooms = rooms

    def _make_user_chip(self, user: dict) -> QWidget:
        """アイコン+クリックで検索タブに飛べる名前ボタン（オーナー欄・参加者欄で共用）"""
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(2, 2, 2, 2)
        h.setSpacing(4)
        avatar = QLabel()
        avatar.setFixedSize(22, 22)
        h.addWidget(avatar)
        url = image_url(user.get("profilePictureFilePath"))
        if url:
            run_async(
                lambda: download_image_bytes(url),
                lambda data, lbl=avatar: lbl.setPixmap(round_pixmap(pixmap_from_bytes(data, 22), 22)) if pixmap_from_bytes(data, 22) else None,
                self._on_error,
            )
        name_btn = QPushButton(user.get("comment") or user.get("name") or str(user.get("id", "?")))
        name_btn.setObjectName("postName")
        name_btn.setCursor(Qt.PointingHandCursor)
        name_btn.clicked.connect(lambda: self._go_to_search(user.get("id")))
        h.addWidget(name_btn)
        h.addStretch(1)
        return w

    def _make_participants_row(self, members: list[dict]) -> QWidget:
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(2, 2, 2, 2)
        h.setSpacing(2)
        for m in members[:6]:
            avatar = QLabel()
            avatar.setFixedSize(22, 22)
            avatar.setCursor(Qt.PointingHandCursor)
            avatar.setToolTip(m.get("name", "?"))
            avatar.mousePressEvent = lambda _e, uid=m.get("id"): self._go_to_search(uid)
            h.addWidget(avatar)
            url = image_url(m.get("profilePictureFilePath"))
            if url:
                run_async(
                    lambda u=url: download_image_bytes(u),
                    lambda data, lbl=avatar: lbl.setPixmap(round_pixmap(pixmap_from_bytes(data, 22), 22)) if pixmap_from_bytes(data, 22) else None,
                    self._on_error,
                )
        h.addStretch(1)
        return w

    def _open_selected_room(self, row: int, _col: int) -> None:
        if row < 0 or row >= len(getattr(self, "_filtered_rooms", [])):
            return
        room = self._filtered_rooms[row]
        url = self.api.room_url_template.format(id=room["id"], token=room["id"])
        logger.info("opening room id=%s url=%s", room["id"], url)
        open_in_browser(url, self.api)
        self.status_label.setText(f"Chromeで開きました: {url}")

    # ---------- タイムライン ----------

    def _build_feed_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        toolbar = QHBoxLayout()
        refresh_btn = QPushButton("TL更新")
        refresh_btn.clicked.connect(self.refresh_feed)
        toolbar.addWidget(refresh_btn)
        self.feed_pages = QComboBox()
        self.feed_pages.addItems(["1ページ", "2ページ", "3ページ", "5ページ", "10ページ"])
        self.feed_pages.currentIndexChanged.connect(self.refresh_feed)
        toolbar.addWidget(self.feed_pages)
        post_btn = QPushButton("ブラウザで投稿する")
        post_btn.clicked.connect(lambda: open_in_browser("https://koetomo.fun/", self.api))
        toolbar.addWidget(post_btn)
        hint = QLabel("（投稿・コメントはreCAPTCHA対策のためブラウザで行います）")
        hint.setObjectName("hint")
        toolbar.addWidget(hint)
        toolbar.addStretch(1)
        layout.addLayout(toolbar)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.feed_inner = QWidget()
        self.feed_layout = QVBoxLayout(self.feed_inner)
        self.feed_layout.addStretch(1)
        scroll.setWidget(self.feed_inner)
        layout.addWidget(scroll, 1)
        return page

    def refresh_feed(self) -> None:
        if not self.api:
            return
        run_async(self.api.get_feed_posts_multi, self._on_feed_loaded, self._on_error, pages=int(self.feed_pages.currentText().replace("ページ", "")))

    def _on_feed_loaded(self, posts: list[dict]) -> None:
        self._clear_layout(self.feed_layout)
        self.feed_layout.addStretch(1)
        for p in posts:
            self.feed_layout.insertWidget(self.feed_layout.count() - 1, self._make_post_card(p))
        self.status_label.setText(f"TL {len(posts)}件取得しました")

    def _make_post_card(self, post: dict) -> QFrame:
        user = post.get("user", {})
        card = QFrame()
        card.setObjectName("postCard")
        v = QVBoxLayout(card)
        header = QHBoxLayout()

        avatar_lbl = QLabel()
        avatar_lbl.setFixedSize(32, 32)
        avatar_lbl.setCursor(Qt.PointingHandCursor)
        avatar_lbl.mousePressEvent = lambda _e, uid=user.get("id"): self._go_to_search(uid)
        header.addWidget(avatar_lbl)
        url = image_url(user.get("profilePictureFilePath"))
        if url:
            run_async(
                lambda: download_image_bytes(url),
                lambda data, lbl=avatar_lbl: lbl.setPixmap(round_pixmap(pixmap_from_bytes(data, 32), 32)) if pixmap_from_bytes(data, 32) else None,
                self._on_error,
            )

        name_lbl = QPushButton(user.get("name", "?"))
        name_lbl.setObjectName("postName")
        name_lbl.setCursor(Qt.PointingHandCursor)
        name_lbl.clicked.connect(lambda: self._go_to_search(user.get("id")))
        header.addWidget(name_lbl)
        meta = QLabel(f"{user.get('age', '')}歳 {post.get('createdAt', '')}" if user.get("age") else post.get("createdAt", ""))
        meta.setObjectName("postMeta")
        header.addWidget(meta)
        header.addStretch(1)
        v.addLayout(header)
        body_text = post.get("decodedDescription") or ""
        if body_text:
            body = QLabel(body_text)
            body.setWordWrap(True)
            v.addWidget(body)

        # 画像/音声投稿の表示。フィールド名(binaryFilePath/imageFilePaths等)は実際の
        # レスポンスを確認できていないため推測。存在しなければ何も表示しない。
        image_path = post.get("binaryFilePath") or post.get("imageFilePath")
        image_paths = post.get("imageFilePaths") or ([image_path] if image_path and post.get("postType") == "image" else [])
        for img_path in (image_paths or [])[:4]:
            img_lbl = QLabel("(画像読込中…)")
            img_lbl.setObjectName("hint")
            img_lbl.setMaximumWidth(320)
            v.addWidget(img_lbl)
            img_url = image_url(img_path)
            if img_url:
                def apply_post_image(data, lbl=img_lbl):
                    pix = pixmap_from_bytes(data, 280)
                    if pix:
                        lbl.setText("")
                        lbl.setPixmap(pix)
                    else:
                        lbl.setText("(画像の読込に失敗しました)")
                run_async(lambda u=img_url: download_image_bytes(u), apply_post_image, self._on_error)

        voice_path = post.get("voiceFilePath") or (post.get("binaryFilePath") if post.get("postType") == "voice" else None)
        if voice_path:
            play_time = post.get("playTime", 0) or 0
            voice_btn = QPushButton(f"▶ 音声を再生 ({play_time}秒)")
            voice_btn.setObjectName("secondaryBtn")
            voice_btn.clicked.connect(lambda p=voice_path: self._play_post_voice(p))
            v.addWidget(voice_btn)

        if not body_text and not image_paths and not voice_path:
            v.addWidget(QLabel("(投稿内容を表示できませんでした)", objectName="hint"))

        actions = QHBoxLayout()
        like_btn = QPushButton(f"♡ {post.get('likedCount', 0)}")
        like_btn.setObjectName("secondaryBtn")
        like_btn.clicked.connect(lambda: self._like_post(post["id"], like_btn))
        actions.addWidget(like_btn)
        bm_btn = QPushButton("☆ 保存")
        bm_btn.setObjectName("secondaryBtn")
        bm_btn.clicked.connect(lambda: run_async(self.api.bookmark_post, lambda _r: self.status_label.setText("保存しました"), self._on_error, post["id"]))
        actions.addWidget(bm_btn)
        actions.addStretch(1)
        v.addLayout(actions)
        return card

    def _play_post_voice(self, voice_path: str) -> None:
        url = f"https://s3.ap-northeast-1.amazonaws.com/production.meetscom.com/audio/{voice_path}"

        def worker():
            data = download_image_bytes(url)  # 中身はただのHTTP GETなので画像と共用可能
            if not data:
                return None
            import tempfile
            suffix = Path(voice_path).suffix or ".webm"
            with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
                f.write(data)
                return f.name

        def on_done(path):
            if path:
                os.startfile(path)  # noqa: S606 - Windows専用。既定の音声プレイヤーで再生
            else:
                QMessageBox.warning(self, "再生失敗", "音声の取得に失敗しました")

        run_async(worker, on_done, self._on_error)

    def _like_post(self, post_id, btn: QPushButton) -> None:
        def done(_r):
            btn.setText("♥ +1")
        run_async(self.api.like_post, done, self._on_error, post_id)

    # ---------- プロフィール ----------

    def _build_profile_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        self.profile_header_label = QLabel()
        self.profile_header_label.setFixedHeight(140)
        self.profile_header_label.setMinimumWidth(400)
        self.profile_header_label.setScaledContents(False)
        self.profile_header_label.setObjectName("profileHeader")
        layout.addWidget(self.profile_header_label)

        self.profile_avatar_label = QLabel()
        self.profile_avatar_label.setFixedSize(72, 72)
        self.profile_name_label = QLabel()
        self.profile_name_label.setObjectName("profileNameBig")

        header_row = QHBoxLayout()
        header_row.addWidget(self.profile_avatar_label)
        header_row.addWidget(self.profile_name_label)
        header_row.addStretch(1)
        layout.addLayout(header_row)

        img_btn_row = QHBoxLayout()
        avatar_btn = QPushButton("アイコン変更")
        avatar_btn.clicked.connect(self._change_avatar)
        img_btn_row.addWidget(avatar_btn)
        header_btn = QPushButton("ヘッダー変更")
        header_btn.clicked.connect(self._change_header)
        img_btn_row.addWidget(header_btn)
        img_btn_row.addStretch(1)
        layout.addLayout(img_btn_row)

        layout.addWidget(QLabel("名前"))
        self.profile_name_edit = QLineEdit()
        layout.addWidget(self.profile_name_edit)
        layout.addWidget(QLabel("自己紹介"))
        self.profile_comment_edit = QTextEdit()
        self.profile_comment_edit.setFixedHeight(80)
        layout.addWidget(self.profile_comment_edit)
        layout.addWidget(QLabel("年齢"))
        self.profile_age_edit = QLineEdit()
        layout.addWidget(self.profile_age_edit)

        btn_row = QHBoxLayout()
        reload_btn = QPushButton("読み込み直し")
        reload_btn.clicked.connect(self.refresh_profile)
        btn_row.addWidget(reload_btn)
        save_btn = QPushButton("保存")
        save_btn.clicked.connect(self._save_profile)
        btn_row.addWidget(save_btn)
        btn_row.addStretch(1)
        layout.addLayout(btn_row)

        self.profile_stats_label = QLabel()
        self.profile_stats_label.setObjectName("hint")
        layout.addWidget(self.profile_stats_label)
        layout.addStretch(1)
        return page

    def refresh_profile(self) -> None:
        if not self.api:
            return
        run_async(self.api.get_user, self._on_profile_loaded, self._on_error)

    def _on_profile_loaded(self, p: dict) -> None:
        self.profile_name_edit.setText(p.get("name", ""))
        self.profile_comment_edit.setPlainText(p.get("comment", "") or "")
        self.profile_age_edit.setText(str(p.get("age", "") or ""))
        self.profile_name_label.setText(p.get("name", ""))
        # アカウント切替欄に「default」ではなく実際のアカウント名を表示するため、
        # 取得できたタイミングでconfig.jsonにキャッシュしておく
        if self.api and p.get("name"):
            key = self.api.active_profile
            profiles = self.api.config.setdefault("profiles", {})
            if key in profiles and profiles[key].get("display_name") != p["name"]:
                profiles[key]["display_name"] = p["name"]
                save_raw_config(self.api.config, self.api.config_path)
                self._refresh_account_combo()
        self.profile_stats_label.setText(
            f"フォロワー: {p.get('followerCount', '-')}  フォロー中: {p.get('followeeCount', '-')}  "
            f"フレンド: {p.get('friendCount', '-')}\nログイン状況: {p.get('loginStatusWithUnit', '-')}"
        )
        url = image_url(p.get("profilePictureFilePath"))
        if url:
            run_async(lambda: download_image_bytes(url), self._set_profile_avatar, self._on_error)
        header_url = image_url(p.get("headerImageFilePath"))
        logger.info("profile header: path=%r url=%r", p.get("headerImageFilePath"), header_url)
        if header_url:
            run_async(lambda: download_image_bytes(header_url), self._set_profile_header, self._on_error)
        else:
            self.profile_header_label.clear()
            self.profile_header_label.setStyleSheet("background-color: #3a3d55; border-radius: 8px;")
        self._current_profile = p

    def _set_profile_header(self, data: bytes | None) -> None:
        pix = pixmap_from_bytes(data)
        if pix:
            self.profile_header_label.setScaledContents(False)
            self.profile_header_label.setStyleSheet("")
            self.profile_header_label.setPixmap(
                cover_crop_pixmap(pix, self.profile_header_label.width() or 400, 140)
            )

    def _set_profile_avatar(self, data: bytes | None) -> None:
        pix = pixmap_from_bytes(data, 72)
        if pix:
            self.profile_avatar_label.setPixmap(round_pixmap(pix, 72))

    def _save_profile(self) -> None:
        if not self.api:
            return
        fields = {
            "name": self.profile_name_edit.text(),
            "comment": self.profile_comment_edit.toPlainText(),
        }
        age_text = self.profile_age_edit.text().strip()
        if age_text.isdigit():
            fields["age"] = int(age_text)
        run_async(lambda: self.api.update_profile(**fields), lambda _r: self._on_profile_saved(), self._on_error)

    def _on_profile_saved(self) -> None:
        self.status_label.setText("プロフィールを更新しました")
        self.refresh_profile()

    def _change_avatar(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "アイコン画像を選択", "", "画像 (*.png *.jpg *.jpeg *.gif)")
        if not path:
            return
        run_async(lambda: self.api.set_profile_picture(path), lambda _r: self.refresh_profile(), self._on_error)

    def _change_header(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "ヘッダー画像を選択", "", "画像 (*.png *.jpg *.jpeg *.gif)")
        if not path:
            return
        run_async(lambda: self.api.set_header_image(path), lambda _r: self.refresh_profile(), self._on_error)

    # ---------- 検索 ----------

    def _build_search_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        toolbar = QHBoxLayout()
        self.search_id_edit = QLineEdit()
        self.search_id_edit.setPlaceholderText("user_id (数字)")
        self.search_id_edit.returnPressed.connect(self._do_search)
        toolbar.addWidget(self.search_id_edit)
        search_btn = QPushButton("検索")
        search_btn.clicked.connect(self._do_search)
        toolbar.addWidget(search_btn)
        toolbar.addStretch(1)
        layout.addLayout(toolbar)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.search_result_widget = QWidget()
        self.search_result_layout = QVBoxLayout(self.search_result_widget)
        self.search_result_layout.addWidget(QLabel("ここに検索結果が表示されます", objectName="hint"))
        self.search_result_layout.addStretch(1)
        scroll.setWidget(self.search_result_widget)
        layout.addWidget(scroll, 1)
        return page

    def _clear_layout(self, layout) -> None:
        """
        レイアウトの中身を再帰的に空にする。QLayout.takeAt()は子が「レイアウト」の場合
        widget()がNoneを返すため、そのまま素通りさせると中の部品(名前ラベル・投稿一覧等)が
        親から切り離されただけで実際には削除されず、次に描画するときに孤立した部品として
        残り続けてしまう(検索を繰り返すほど蓄積していく重大なバグだった)。
        """
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
                continue
            child_layout = item.layout()
            if child_layout:
                self._clear_layout(child_layout)

    def _go_to_search(self, user_id) -> None:
        if not user_id:
            return
        self.search_id_edit.setText(str(user_id))
        self.show_section("search")
        self._do_search()

    def _do_search(self) -> None:
        uid = self.search_id_edit.text().strip()
        if not uid.isdigit():
            QMessageBox.warning(self, "エラー", "idは数字で入力してください")
            return
        run_async(self.api.get_user, self._render_search_result, self._on_error, uid)

    def _render_search_result(self, profile: dict) -> None:
        self._clear_layout(self.search_result_layout)

        uid = profile.get("id")

        header_banner = QLabel()
        header_banner.setFixedHeight(100)
        header_banner.setMinimumWidth(400)
        header_banner.setScaledContents(False)
        header_url = image_url(profile.get("headerImageFilePath"))
        if header_url:
            def apply_header(data, lbl=header_banner):
                pix = pixmap_from_bytes(data)
                if pix:
                    lbl.setPixmap(cover_crop_pixmap(pix, lbl.width() or 400, 100))
            run_async(lambda: download_image_bytes(header_url), apply_header, self._on_error)
        else:
            header_banner.setStyleSheet("background-color: #3a3d55; border-radius: 8px;")
        self.search_result_layout.addWidget(header_banner)

        header = QHBoxLayout()
        avatar = QLabel()
        avatar.setFixedSize(80, 80)
        header.addWidget(avatar)
        url = image_url(profile.get("profilePictureFilePath"))
        if url:
            def apply_avatar(data, lbl=avatar):
                pix = pixmap_from_bytes(data, 80)
                if pix:
                    lbl.setPixmap(round_pixmap(pix, 80))
            run_async(lambda: download_image_bytes(url), apply_avatar, self._on_error)

        info_col = QVBoxLayout()
        name_lbl = QLabel(profile.get("name", "?"))
        name_lbl.setObjectName("profileNameBig")
        info_col.addWidget(name_lbl)
        info_col.addWidget(QLabel(f"年齢: {profile.get('age', '-')}"))
        comment = QLabel(profile.get("comment") or "")
        comment.setWordWrap(True)
        info_col.addWidget(comment)
        stats = QLabel(f"フォロワー: {profile.get('followerCount', '-')}  フォロー中: {profile.get('followeeCount', '-')}  フレンド: {profile.get('friendCount', '-')}")
        stats.setObjectName("hint")
        info_col.addWidget(stats)

        action_row = QHBoxLayout()
        follow_btn = QPushButton("フォロー")
        follow_btn.setObjectName("secondaryBtn")
        follow_btn.clicked.connect(lambda: run_async(self.api.follow_user, lambda _r: self.status_label.setText("フォローしました"), self._on_error, uid))
        action_row.addWidget(follow_btn)
        friend_btn = QPushButton("フレンド申請")
        friend_btn.setObjectName("secondaryBtn")
        friend_btn.clicked.connect(lambda: run_async(self.api.send_friend_request, lambda _r: self.status_label.setText("申請しました"), self._on_error, uid))
        action_row.addWidget(friend_btn)
        block_btn = QPushButton("ブロック")
        block_btn.setObjectName("secondaryBtn")
        block_btn.clicked.connect(lambda: run_async(self.api.block_user, lambda _r: self.status_label.setText("ブロックしました"), self._on_error, uid))
        action_row.addWidget(block_btn)
        dm_btn = QPushButton("DM")
        dm_btn.clicked.connect(lambda: self._open_dm_from_search(uid, profile.get("name", "?")))
        action_row.addWidget(dm_btn)
        action_row.addStretch(1)
        info_col.addLayout(action_row)

        header.addLayout(info_col, 1)
        self.search_result_layout.addLayout(header)

        tweets_label = QLabel("つぶやき")
        tweets_label.setObjectName("sectionLabel")
        self.search_result_layout.addWidget(tweets_label)
        tweets_box = QVBoxLayout()
        self.search_result_layout.addLayout(tweets_box)
        run_async(self.api.get_user_feed_posts, lambda posts: self._render_mini_posts(tweets_box, posts), self._on_error, uid)

        talks_label = QLabel("話そう")
        talks_label.setObjectName("sectionLabel")
        self.search_result_layout.addWidget(talks_label)
        talks_box = QVBoxLayout()
        self.search_result_layout.addLayout(talks_box)
        run_async(self.api.get_user_timeline_posts, lambda posts: self._render_mini_posts(talks_box, posts), self._on_error, uid)

        self.search_result_layout.addStretch(1)

    def _render_mini_posts(self, layout: QVBoxLayout, posts: list[dict]) -> None:
        if not posts:
            layout.addWidget(QLabel("(投稿なし)", objectName="hint"))
            return
        for p in posts:
            text = (p.get("decodedDescription") or "(画像/ボイス投稿)")[:80]
            layout.addWidget(QLabel(f"・{text}"))

    def _open_dm_from_search(self, uid, name) -> None:
        self.show_section("dm")
        self._open_dm(uid, name)

    # ---------- フレンド ----------

    def refresh_friends_sidebar(self) -> None:
        if not self.api:
            return
        run_async(self.api.get_friends, self._on_friends_sidebar_loaded, self._on_error)

    def _on_friends_sidebar_loaded(self, data: dict) -> None:
        self.friend_list_widget.clear()
        users = data.get("users", [])
        for u in users:
            item = QListWidgetItem(f"  {u.get('name', '?')}")
            item.setData(Qt.UserRole, u)
            self.friend_list_widget.addItem(item)
            url = image_url(u.get("profilePictureFilePath"))
            if url:
                def apply_icon(img_data, it=item):
                    pix = pixmap_from_bytes(img_data, 22)
                    if pix:
                        it.setIcon(QIcon(round_pixmap(pix, 22)))
                run_async(lambda u2=url: download_image_bytes(u2), apply_icon, self._on_error)
        self._friends_cache = users

    def _on_friend_clicked(self, item: QListWidgetItem) -> None:
        u = item.data(Qt.UserRole)
        if u:
            self._go_to_search(u.get("id"))

    def _build_friends_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        refresh_btn = QPushButton("更新")
        refresh_btn.clicked.connect(self.refresh_friends_page)
        layout.addWidget(refresh_btn)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.friends_page_inner = QWidget()
        self.friends_page_layout = QVBoxLayout(self.friends_page_inner)
        self.friends_page_layout.addStretch(1)
        scroll.setWidget(self.friends_page_inner)
        layout.addWidget(scroll, 1)
        return page

    def refresh_friends_page(self) -> None:
        if not self.api:
            return
        run_async(self.api.get_friends, self._on_friends_page_loaded, self._on_error)

    def _on_friends_page_loaded(self, data: dict) -> None:
        self._clear_layout(self.friends_page_layout)
        self.friends_page_layout.addStretch(1)
        users = data.get("users", [])
        if not users:
            self.friends_page_layout.insertWidget(0, QLabel("(フレンドがいません)", objectName="hint"))
            return
        for u in users:
            row = QFrame()
            row.setObjectName("friendRow")
            h = QHBoxLayout(row)
            avatar = QLabel()
            avatar.setFixedSize(32, 32)
            h.addWidget(avatar)
            url = image_url(u.get("profilePictureFilePath"))
            if url:
                def apply_avatar(data, lbl=avatar):
                    pix = pixmap_from_bytes(data, 32)
                    if pix:
                        lbl.setPixmap(round_pixmap(pix, 32))
                run_async(lambda u2=url: download_image_bytes(u2), apply_avatar, self._on_error)
            name_btn = QPushButton(u.get("name", "?"))
            name_btn.setObjectName("postName")
            name_btn.clicked.connect(lambda _c, uid=u.get("id"): self._go_to_search(uid))
            h.addWidget(name_btn)
            h.addWidget(QLabel(u.get("comment") or "", objectName="hint"), 1)
            dm_btn = QPushButton("DM")
            dm_btn.setObjectName("secondaryBtn")
            dm_btn.clicked.connect(lambda _c, uid=u.get("id"), n=u.get("name", "?"): self._open_dm_from_search(uid, n))
            h.addWidget(dm_btn)
            self.friends_page_layout.insertWidget(self.friends_page_layout.count() - 1, row)

    # ---------- お知らせ ----------

    def _build_notices_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        refresh_btn = QPushButton("更新")
        refresh_btn.clicked.connect(self.refresh_notices)
        layout.addWidget(refresh_btn)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.notices_inner = QWidget()
        self.notices_layout = QVBoxLayout(self.notices_inner)
        self.notices_layout.addStretch(1)
        scroll.setWidget(self.notices_inner)
        layout.addWidget(scroll, 1)
        return page

    def refresh_notices(self) -> None:
        if not self.api:
            return
        def fetch_all():
            return {
                "notices": self.api.get_notices(),
                "important": self.api.get_important_notifications(),
                "normal": self.api.get_normal_notifications(),
            }
        run_async(fetch_all, self._on_notices_loaded, self._on_error)

    def _on_notices_loaded(self, data: dict) -> None:
        self._clear_layout(self.notices_layout)
        self.notices_layout.addStretch(1)

        def add_section(title, items, text_key):
            self.notices_layout.insertWidget(self.notices_layout.count() - 1, QLabel(title, objectName="sectionLabel"))
            if not items:
                self.notices_layout.insertWidget(self.notices_layout.count() - 1, QLabel("(なし)", objectName="hint"))
                return
            for n in items:
                card = QFrame()
                card.setObjectName("postCard")
                v = QVBoxLayout(card)
                v.addWidget(QLabel(n.get("title") or n.get("message", ""), objectName="postName"))
                import re
                text = re.sub("<[^>]+>", "", n.get(text_key, "") or "")
                body = QLabel(text[:200])
                body.setWordWrap(True)
                v.addWidget(body)
                self.notices_layout.insertWidget(self.notices_layout.count() - 1, card)

        add_section("運営からのお知らせ", data.get("notices", []), "text")
        add_section("重要な通知", data.get("important", []), "message")
        add_section("通常の通知", data.get("normal", []), "message")

    # ---------- DM ----------

    def _build_dm_page(self) -> QWidget:
        page = QWidget()
        h = QHBoxLayout(page)
        splitter = QSplitter()
        h.addWidget(splitter)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        chat_refresh = QPushButton("更新")
        chat_refresh.clicked.connect(self.refresh_chats)
        left_layout.addWidget(chat_refresh)
        self.chat_list_widget = QListWidget()
        self.chat_list_widget.setIconSize(QSize(24, 24))
        self.chat_list_widget.setStyleSheet("QListWidget::item { border-bottom: 1px solid #232428; padding: 6px 2px; }")
        self.chat_list_widget.itemClicked.connect(self._on_chat_clicked)
        left_layout.addWidget(self.chat_list_widget, 1)
        left.setMaximumWidth(260)
        splitter.addWidget(left)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.dm_messages_inner = QWidget()
        self.dm_messages_layout = QVBoxLayout(self.dm_messages_inner)
        self.dm_messages_layout.addStretch(1)
        scroll.setWidget(self.dm_messages_inner)
        right_layout.addWidget(scroll, 1)
        self.dm_scroll_area = scroll

        attach_row = QHBoxLayout()
        img_btn = QPushButton("🖼 画像を送る")
        img_btn.setObjectName("secondaryBtn")
        img_btn.clicked.connect(self._send_dm_image)
        attach_row.addWidget(img_btn)
        voice_btn = QPushButton("🎤 音声ファイルを送る")
        voice_btn.setObjectName("secondaryBtn")
        voice_btn.clicked.connect(self._send_dm_voice)
        attach_row.addWidget(voice_btn)
        attach_row.addStretch(1)
        right_layout.addLayout(attach_row)

        input_row = QHBoxLayout()
        self.dm_text_edit = QLineEdit()
        self.dm_text_edit.returnPressed.connect(self._send_dm_text)
        input_row.addWidget(self.dm_text_edit, 1)
        send_btn = QPushButton("送信")
        send_btn.clicked.connect(self._send_dm_text)
        input_row.addWidget(send_btn)
        right_layout.addLayout(input_row)

        splitter.addWidget(right)
        self._current_chat_id = None
        self._current_target_id = None
        self._dm_poll_timer = QTimer(self)
        self._dm_poll_timer.timeout.connect(self._poll_dm)
        self._dm_last_id = None
        return page

    def refresh_chats(self) -> None:
        if not self.api:
            return
        run_async(self.api.get_chats, self._on_chats_loaded, self._on_error)

    def _on_chats_loaded(self, chats: list[dict]) -> None:
        self.chat_list_widget.clear()
        for c in chats:
            target = c.get("partner") or c.get("targetUser") or c.get("user") or {}
            item = QListWidgetItem(f"  {target.get('name', '?')}")
            item.setData(Qt.UserRole, (target.get("id"), target.get("name"), c.get("chatId")))
            url = image_url(target.get("profilePictureFilePath"))
            self.chat_list_widget.addItem(item)
            if url:
                def apply_icon(data, it=item):
                    pix = pixmap_from_bytes(data, 24)
                    if pix:
                        it.setIcon(QIcon(round_pixmap(pix, 24)))
                run_async(lambda u=url: download_image_bytes(u), apply_icon, self._on_error)

    def _on_chat_clicked(self, item: QListWidgetItem) -> None:
        target_id, name, chat_id = item.data(Qt.UserRole)
        self._open_dm(target_id, name, chat_id)

    def _open_dm(self, target_id, name, chat_id=None) -> None:
        self._current_target_id = target_id
        self._current_chat_id = chat_id
        self._dm_last_id = None
        self._dm_poll_timer.stop()
        # 会話を切り替えた瞬間に、直前の会話向けに飛んでいた通信の結果が後から届いて
        # 混ざり込むことがあった(重大バグ)。世代番号を進め、古い世代の結果は破棄する。
        self._dm_session_id = getattr(self, "_dm_session_id", 0) + 1
        session_id = self._dm_session_id

        def on_loaded(info):
            if session_id != self._dm_session_id:
                return  # 会話を切り替えた後に届いた古い結果は無視する
            self._on_dm_history_loaded(info)

        def on_error(msg):
            if session_id != self._dm_session_id:
                return
            self._on_dm_error(msg)

        run_async(
            lambda: self.api.open_chat(target_id, chat_id=chat_id),
            on_loaded, on_error,
        )

    def _on_dm_error(self, message: str) -> None:
        self._on_error(message)
        self._clear_layout(self.dm_messages_layout)
        self.dm_messages_layout.addStretch(1)
        self._show_dm_placeholder(f"取得に失敗しました: {message}")

    def _on_dm_history_loaded(self, info: dict) -> None:
        self._current_chat_id = info.get("meta", {}).get("chatId") or self._current_chat_id
        messages = info.get("chatMessages", [])
        self._render_dm_messages(messages, replace=True)
        if not messages:
            self._show_dm_placeholder("(まだメッセージがありません。下の欄から送ってみてください)")
        ids = [m.get("id") for m in messages if m.get("id")]
        if ids:
            self._dm_last_id = max(ids)
        if self._current_chat_id:
            run_async(self.api.mark_messages_read, None, lambda msg: logger.info("mark_read failed (ignored): %s", msg), self._current_chat_id)
        self._dm_poll_timer.start(6000)

    def _poll_dm(self) -> None:
        if not self._current_chat_id:
            return
        session_id = self._dm_session_id

        def on_result(info):
            if session_id != self._dm_session_id:
                return  # 会話を切り替えた後に届いたポーリング結果は無視する
            self._on_dm_poll_result(info)

        run_async(
            lambda: self.api.open_chat(self._current_target_id, chat_id=self._current_chat_id, current_last_message_id=self._dm_last_id),
            on_result, self._on_error,
        )

    def _on_dm_poll_result(self, info: dict) -> None:
        messages = info.get("chatMessages", [])
        if messages:
            self._render_dm_messages(messages, replace=False)
            ids = [m.get("id") for m in messages if m.get("id")]
            if ids:
                self._dm_last_id = max(self._dm_last_id or 0, max(ids))
            if self._current_chat_id:
                run_async(self.api.mark_messages_read, None, lambda msg: logger.info("mark_read failed (ignored): %s", msg), self._current_chat_id)

    def _show_dm_placeholder(self, text: str) -> None:
        lbl = QLabel(text, objectName="hint")
        lbl.setAlignment(Qt.AlignCenter)
        self.dm_messages_layout.insertWidget(0, lbl)

    def _render_dm_messages(self, messages: list[dict], replace: bool) -> None:
        if replace:
            self._clear_layout(self.dm_messages_layout)
            self.dm_messages_layout.addStretch(1)
        my_uid = str(self.api.uid) if self.api else ""
        for m in reversed(messages):
            mine = str(m.get("userId")) == my_uid
            row = QHBoxLayout()
            bubble = QLabel()
            bubble.setWordWrap(True)
            bubble.setObjectName("bubbleMine" if mine else "bubbleTheirs")
            if m.get("messageType") == "text":
                bubble.setText(m.get("textMessage", ""))
            elif m.get("messageType") == "image":
                bubble.setText("(画像メッセージ)")
            elif m.get("messageType") == "voice":
                bubble.setText(f"🎤 音声メッセージ ({m.get('playTime', 0)}秒)")
            else:
                bubble.setText(f"({m.get('messageType')})")
            if mine:
                row.addStretch(1)
                row.addWidget(bubble)
            else:
                row.addWidget(bubble)
                row.addStretch(1)
            self.dm_messages_layout.insertLayout(self.dm_messages_layout.count() - 1, row)
        QTimer.singleShot(50, lambda: self.dm_scroll_area.verticalScrollBar().setValue(
            self.dm_scroll_area.verticalScrollBar().maximum()))

    def _send_dm_text(self) -> None:
        text = self.dm_text_edit.text().strip()
        if not text or not self._current_chat_id:
            return
        def done(_r):
            self.dm_text_edit.clear()
            self._open_dm(self._current_target_id, None, self._current_chat_id)
        run_async(lambda: self.api.send_message(self._current_chat_id, text), done, self._on_error)

    def _send_dm_image(self) -> None:
        if not self._current_chat_id:
            QMessageBox.warning(self, "エラー", "先にDM相手を選んでください")
            return
        path, _ = QFileDialog.getOpenFileName(self, "画像を選択", "", "画像 (*.png *.jpg *.jpeg *.gif)")
        if not path:
            return
        run_async(
            lambda: self.api.send_image_message(self._current_chat_id, path),
            lambda _r: self._open_dm(self._current_target_id, None, self._current_chat_id),
            self._on_error,
        )

    def _send_dm_voice(self) -> None:
        if not self._current_chat_id:
            QMessageBox.warning(self, "エラー", "先にDM相手を選んでください")
            return
        path, _ = QFileDialog.getOpenFileName(self, "音声ファイルを選択", "", "音声 (*.m4a *.mp3 *.wav *.webm *.aac)")
        if not path:
            return
        run_async(
            lambda: self.api.send_voice_message(self._current_chat_id, path),
            lambda _r: self._open_dm(self._current_target_id, None, self._current_chat_id),
            self._on_error,
        )

    # ---------- アカウント ----------

    def _refresh_account_combo(self) -> None:
        if not self.api:
            return
        self.account_combo.blockSignals(True)
        self.account_combo.clear()
        profiles = self.api.config.get("profiles", {})
        for key in self.api.list_profiles():
            display_name = profiles.get(key, {}).get("display_name") or key
            self.account_combo.addItem(display_name, userData=key)
        idx = self.account_combo.findData(self.api.active_profile or "")
        if idx >= 0:
            self.account_combo.setCurrentIndex(idx)
        self.account_combo.blockSignals(False)

    def _on_account_change(self, index: int) -> None:
        if not self.api or index < 0:
            return
        key = self.account_combo.itemData(index)
        if not key or key == self.api.active_profile:
            return
        try:
            self.api.switch_profile(key)
            self.refresh_all()
            self.status_label.setText(f"アカウント切替: {self.account_combo.itemText(index)}")
        except KeyError as e:
            QMessageBox.warning(self, "エラー", str(e))

    def _launch_login(self) -> None:
        import subprocess
        try:
            launcher = sys.executable.replace("python.exe", "pythonw.exe")
            if not Path(launcher).exists():
                launcher = sys.executable
            subprocess.Popen([launcher, str(BASE_DIR / "token_fetcher.py")], cwd=str(BASE_DIR))
            QMessageBox.information(self, "ログイン", "ログイン用ウィンドウを起動しました。完了すると自動で反映されます。")
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "起動失敗", str(e))

    # ---------- 設定 ----------

    def _open_settings(self) -> None:
        dlg = SettingsDialog(self)
        dlg.exec()

    # ---------- 共通エラーハンドラ ----------

    def _on_error(self, message: str) -> None:
        self.status_label.setText(f"エラー: {message}")


class SettingsDialog(QDialog):
    def __init__(self, parent: MainWindow):
        super().__init__(parent)
        self.setWindowTitle("設定")
        self.resize(380, 480)
        self.main_win = parent
        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("リンクを開くブラウザ", objectName="sectionLabel"))
        browser_row = QHBoxLayout()
        self.browser_path_edit = QLineEdit(parent.api.config.get("browser_path", "") if parent.api else "")
        self.browser_path_edit.setPlaceholderText("空欄なら自動でChromeを使用")
        browser_row.addWidget(self.browser_path_edit)
        browse_btn = QPushButton("参照")
        browse_btn.clicked.connect(self._pick_browser_path)
        browser_row.addWidget(browse_btn)
        layout.addLayout(browser_row)
        save_browser_btn = QPushButton("保存")
        save_browser_btn.clicked.connect(self._save_browser_path)
        layout.addWidget(save_browser_btn)
        browser_hint = QLabel(
            "※声ともはログインを同時に1ブラウザでしか維持できないため、既定では"
            "token_fetcherでログインしたのと同じChromeを自動使用します。別のブラウザを"
            "使いたい場合のみ、そのブラウザの実行ファイル(.exe)を指定してください。",
            objectName="hint",
        )
        browser_hint.setWordWrap(True)
        layout.addWidget(browser_hint)

        color_row = QHBoxLayout()
        bg_btn = QPushButton("背景色")
        bg_btn.clicked.connect(lambda: self._pick_color("bg"))
        color_row.addWidget(bg_btn)
        text_btn = QPushButton("文字色")
        text_btn.clicked.connect(lambda: self._pick_color("text"))
        color_row.addWidget(text_btn)
        accent_btn = QPushButton("アクセント色")
        accent_btn.clicked.connect(lambda: self._pick_color("accent"))
        color_row.addWidget(accent_btn)
        layout.addLayout(color_row)

        from PySide6.QtWidgets import QCheckBox
        self.frame_checkbox = QCheckBox("ウィンドウ枠(タイトルバー)を表示する")
        self.frame_checkbox.setChecked(not bool(parent.api.config.get("frameless", False)) if parent.api else True)
        self.frame_checkbox.toggled.connect(self._toggle_frame)
        layout.addWidget(self.frame_checkbox)
        frame_hint = QLabel("※枠を非表示にした場合、閉じるにはAlt+F4を使ってください", objectName="hint")
        frame_hint.setWordWrap(True)
        layout.addWidget(frame_hint)

        github_btn = QPushButton("GitHubへ")
        github_btn.clicked.connect(lambda: QDesktopServices.openUrl("https://github.com/haizarakun/koetomoProject"))
        layout.addWidget(github_btn)

        layout.addWidget(QLabel("ログ", objectName="sectionLabel"))
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        try:
            log_path = BASE_DIR / "app.log"
            text = log_path.read_text(encoding="utf-8", errors="replace") if log_path.exists() else ""
            self.log_view.setPlainText("\n".join(text.splitlines()[-300:]))
        except Exception:  # noqa: BLE001
            pass
        layout.addWidget(self.log_view, 1)

        btn_row = QHBoxLayout()
        clear_btn = QPushButton("ログを削除")
        clear_btn.clicked.connect(self._clear_log)
        btn_row.addWidget(clear_btn)
        close_btn = QPushButton("閉じる")
        close_btn.clicked.connect(self.accept)
        btn_row.addWidget(close_btn)
        layout.addLayout(btn_row)

    def _pick_browser_path(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "ブラウザの実行ファイルを選択", "", "実行ファイル (*.exe)")
        if path:
            self.browser_path_edit.setText(path)

    def _save_browser_path(self) -> None:
        api = self.main_win.api
        if not api:
            return
        api.config["browser_path"] = self.browser_path_edit.text().strip()
        save_raw_config(api.config, api.config_path)
        QMessageBox.information(self, "保存", "保存しました。")

    def _pick_color(self, kind: str) -> None:
        color = QColorDialog.getColor()
        if not color.isValid():
            return
        app = QApplication.instance()
        api = self.main_win.api
        key_map = {"bg": "theme_color", "text": "theme_text_color", "accent": "accent_color"}
        if api:
            api.config[key_map[kind]] = color.name()
            save_raw_config(api.config, api.config_path)
        apply_theme_colors(
            app,
            bg=api.config.get("theme_color", "#313338") if api else "#313338",
            text=api.config.get("theme_text_color", "#dbdee1") if api else "#dbdee1",
            accent=api.config.get("accent_color", "#5865F2") if api else "#5865F2",
        )

    def _toggle_frame(self, checked: bool) -> None:
        api = self.main_win.api
        if api:
            api.config["frameless"] = not checked
            save_raw_config(api.config, api.config_path)
        win = self.main_win
        win.setWindowFlag(Qt.FramelessWindowHint, not checked)
        win.show()

    def _clear_log(self) -> None:
        if QMessageBox.question(self, "確認", "app.log を削除しますか？") == QMessageBox.Yes:
            (BASE_DIR / "app.log").write_text("", encoding="utf-8")
            self.log_view.clear()


def _resource_path(name: str) -> Path:
    """PyInstaller等でexe化された場合、静的リソース(style.qss等)は _MEIPASS 配下に
    展開されるため、そちらを優先的に探す。開発時はスクリプトと同じフォルダを見る。"""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        bundled = Path(sys._MEIPASS) / name
        if bundled.exists():
            return bundled
    return BASE_DIR / name


def apply_theme_colors(app: QApplication, bg: str = "#313338", text: str = "#dbdee1", accent: str = "#5865F2") -> None:
    qss = _resource_path("style.qss").read_text(encoding="utf-8")
    qss = qss.replace("#313338", bg).replace("#dbdee1", text).replace("#5865F2", accent)
    app.setStyleSheet(qss)


def main() -> None:
    app = QApplication(sys.argv)
    app.setApplicationName("koetomoクライアント！")
    qss_path = _resource_path("style.qss")
    if qss_path.exists():
        try:
            cfg = load_raw_config()
            apply_theme_colors(
                app,
                bg=cfg.get("theme_color", "#313338"),
                text=cfg.get("theme_text_color", "#dbdee1"),
                accent=cfg.get("accent_color", "#5865F2"),
            )
        except ConfigMissingError:
            app.setStyleSheet(qss_path.read_text(encoding="utf-8"))
    win = MainWindow()
    if win.api and win.api.config.get("frameless", False):
        win.setWindowFlag(Qt.FramelessWindowHint, True)
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
