// koetomo 通話拡張オーバーレイ (ISOLATED world)
//
// できること(確実):
//   - 相手ごとの個別音量調整 (audio要素のvolumeを直接操作)
//   - しゃべった時の光るアニメーション (Web AudioのAnalyserNodeで音量を見て光らせる)
//   - 自分のマイク音量メーター・ミュート (mic_hook.js経由)
//   - 入退室ログ(何時何分に接続/切断したか、接続時間) ※ "誰が"の名前紐付けはベストエフォート
(function () {
  if (window.__koetomoCallOverlayInstalled) return;
  window.__koetomoCallOverlayInstalled = true;

  const participants = new Map(); // audioEl -> { ctx, joinedAt, row, label, rafId }
  let panel, logList, micLevelBar, muteBtn, masterVolSlider;
  let micMuted = false;
  let masterVolume = 1.0;
  let roomMemberIds = []; // APIから取得した現在ルームのメンバーid一覧(未割当分から順に使う)
  let usedMemberIds = new Set();

  function extractRoomId() {
    const m = location.pathname.match(/\/talk-rooms\/(\d+)/);
    return m ? m[1] : null;
  }

  async function fetchRoomMemberIds() {
    const roomId = extractRoomId();
    console.log('[koetomo][ID解決] 現在のroomId =', roomId);
    if (!roomId) {
      console.warn('[koetomo][ID解決] URLからroomIdを取得できませんでした:', location.pathname);
      return;
    }
    try {
      for (let page = 1; page <= 2; page++) {  // 通話中は一覧から外れる場合が多いため深追いしない(軽量化)
        const res = await fetch(`https://a.koetomo.fun/api/rooms?page=${page}&order=opened_at_desc`, {
          credentials: 'include',
        });
        console.log(`[koetomo][ID解決] page=${page} status=${res.status}`);
        if (!res.ok) break;
        const rooms = await res.json();
        if (!Array.isArray(rooms) || rooms.length === 0) {
          console.log(`[koetomo][ID解決] page=${page} は空。検索終了`);
          break;
        }
        console.log(`[koetomo][ID解決] page=${page} 件数=${rooms.length} id一覧=`, rooms.map((r) => r.id));
        const room = rooms.find((r) => String(r.id) === String(roomId));
        if (room) {
          roomMemberIds = (room.members || []).map((m) => m.id).filter((id) => id != null);
          console.log('[koetomo][ID解決] 一致するルームを発見。メンバーid =', roomMemberIds);
          return;
        }
      }
      console.warn('[koetomo][ID解決] 5ページ探しても一致するルームが見つかりませんでした。roomId=', roomId,
        '（通話中は/api/roomsの一覧から外れている可能性があります）');
    } catch (e) {
      console.warn('[koetomo][ID解決] 取得失敗', e);
    }
  }

  function nextMemberId() {
    const id = roomMemberIds.find((i) => !usedMemberIds.has(i));
    if (id != null) {
      usedMemberIds.add(id);
      return id;
    }
    return null;
  }

  function fmtTime(d) {
    return d.toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  function fmtDuration(ms) {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return m > 0 ? `${m}分${sec}秒` : `${sec}秒`;
  }

  let unknownCounter = 0;
  const unresolvedLabels = []; // {nameEl, assigned:boolean} 後で実データが届いたら書き換える対象
  function guessLabel(audioEl) {
    const id = nextMemberId();
    if (id != null) return `ID:${id}`;
    unknownCounter += 1;
    return `ID不明#${unknownCounter}`;
  }

  function resolvePendingLabels() {
    // 新しくidが届いた際、既に「ID不明」表示になっている行を先着順で書き換える
    for (const entry of unresolvedLabels) {
      if (entry.assigned) continue;
      const id = nextMemberId();
      if (id == null) break;
      entry.nameEl.textContent = `ID:${id}`;
      entry.assigned = true;
    }
  }

  function buildPanel() {
    panel = document.createElement('div');
    panel.id = 'koetomo-call-overlay';
    panel.innerHTML = `
      <style>
        #koetomo-call-overlay {
          position: fixed; right: 8px; top: 8px; width: 260px; max-height: 90vh;
          background: rgba(20,20,24,0.92); color: #eee; font-family: -apple-system, "Hiragino Kaku Gothic ProN", Meiryo, sans-serif;
          font-size: 12px; border-radius: 10px; z-index: 2147483647; overflow: hidden;
          box-shadow: 0 4px 16px rgba(0,0,0,0.4); display: flex; flex-direction: column;
        }
        #koetomo-call-overlay .kco-head { padding: 8px 10px; font-weight: 600; background: rgba(88,101,242,0.9); display:flex; justify-content:space-between; align-items:center; cursor: move; }
        #koetomo-call-overlay .kco-mic { padding: 8px 10px; border-bottom: 1px solid rgba(255,255,255,0.1); }
        #koetomo-call-overlay .kco-mic-bar-bg { height: 6px; background: #333; border-radius: 3px; overflow: hidden; margin-top: 4px; }
        #koetomo-call-overlay .kco-mic-bar-fg { height: 100%; width: 0%; background: #57F287; transition: width 80ms linear; }
        #koetomo-call-overlay .kco-mute-btn { margin-top: 6px; width: 100%; padding: 4px; border: none; border-radius: 6px; cursor: pointer; background: #4a4a52; color: #fff; }
        #koetomo-call-overlay .kco-mute-btn.muted { background: #ed4245; }
        #koetomo-call-overlay .kco-section-label { padding: 6px 10px 2px; color: #999; font-size: 10px; }
        #koetomo-call-overlay .kco-participants { max-height: 160px; overflow-y: auto; }
        #koetomo-call-overlay .kco-p-row { padding: 4px 10px; display:flex; align-items:center; gap:6px; }
        #koetomo-call-overlay .kco-glow { width: 10px; height: 10px; border-radius: 50%; background: #555; flex-shrink:0; transition: box-shadow 80ms, background 80ms; }
        #koetomo-call-overlay .kco-glow.speaking { background: #57F287; box-shadow: 0 0 8px 3px rgba(87,242,135,0.8); }
        #koetomo-call-overlay .kco-p-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        #koetomo-call-overlay .kco-p-vol { width: 60px; }
        #koetomo-call-overlay .kco-log { max-height: 160px; overflow-y: auto; padding: 4px 10px 8px; }
        #koetomo-call-overlay .kco-log div { padding: 2px 0; color: #ccc; border-bottom: 1px dashed rgba(255,255,255,0.06); }
        #koetomo-call-overlay .kco-toggle { cursor: pointer; font-size: 11px; opacity: 0.8; }
      </style>
      <div class="kco-head"><span>koetomo 通話パネル</span><span class="kco-toggle" id="kco-collapse">▾</span></div>
      <div id="kco-body">
        <div class="kco-mic">
          自分のマイク音量
          <div class="kco-mic-bar-bg"><div class="kco-mic-bar-fg" id="kco-mic-bar"></div></div>
          <button class="kco-mute-btn" id="kco-mute-btn">🎙 ミュートにする</button>
        </div>
        <div class="kco-mic" style="border-bottom:1px solid rgba(255,255,255,0.1);">
          声とも全体の音量（このタブの声とも音声のみ。他サイトやPC全体には影響しません）
          <input type="range" id="kco-master-vol" min="0" max="150" value="100" style="width:100%">
        </div>
        <div class="kco-section-label">参加者（音量調整・しゃべり検知）</div>
        <div class="kco-participants" id="kco-participants"></div>
        <div class="kco-section-label">入退室ログ</div>
        <div class="kco-log" id="kco-log"></div>
      </div>
    `;
    document.documentElement.appendChild(panel);

    logList = panel.querySelector('#kco-log');
    micLevelBar = panel.querySelector('#kco-mic-bar');
    muteBtn = panel.querySelector('#kco-mute-btn');
    masterVolSlider = panel.querySelector('#kco-master-vol');
    masterVolSlider.addEventListener('input', () => {
      masterVolume = Math.min(1.5, masterVolSlider.value / 100);
      applyAllVolumes();
    });

    muteBtn.addEventListener('click', () => {
      window.dispatchEvent(new CustomEvent('koetomo:set-mute', { detail: { muted: !micMuted } }));
    });

    const collapseBtn = panel.querySelector('#kco-collapse');
    const body = panel.querySelector('#kco-body');
    collapseBtn.addEventListener('click', () => {
      const hidden = body.style.display === 'none';
      body.style.display = hidden ? '' : 'none';
      collapseBtn.textContent = hidden ? '▾' : '▸';
    });

    const head = panel.querySelector('.kco-head');
    let dragging = false, dx = 0, dy = 0;
    head.addEventListener('mousedown', (e) => {
      dragging = true; dx = e.clientX - panel.offsetLeft; dy = e.clientY - panel.offsetTop;
    });
    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      const maxLeft = window.innerWidth - panel.offsetWidth - 4;
      const maxTop = window.innerHeight - panel.offsetHeight - 4;
      const left = Math.max(4, Math.min(maxLeft, e.clientX - dx));
      const top = Math.max(4, Math.min(maxTop, e.clientY - dy));
      panel.style.left = left + 'px';
      panel.style.top = top + 'px';
      panel.style.right = 'auto';
    });
    document.addEventListener('mouseup', () => { dragging = false; });
  }

  function addLog(text, kind) {
    if (!logList) return;
    const line = document.createElement('div');
    line.textContent = `[${fmtTime(new Date())}] ${text}`;
    if (kind === 'join') line.style.color = '#57F287';
    else if (kind === 'leave') line.style.color = '#ed4245';
    logList.insertBefore(line, logList.firstChild);
  }

  function attachParticipant(audioEl) {
    if (participants.has(audioEl)) return;
    const label = guessLabel(audioEl);
    const joinedAt = Date.now();

    const row = document.createElement('div');
    row.className = 'kco-p-row';
    row.innerHTML = `
      <div class="kco-glow"></div>
      <div class="kco-p-name">${label}</div>
      <input type="range" class="kco-p-vol" min="0" max="150" value="100">
    `;
    panel.querySelector('#kco-participants').appendChild(row);
    const nameEl = row.querySelector('.kco-p-name');
    if (label.startsWith('ID不明')) {
      unresolvedLabels.push({ nameEl, assigned: false });
    }

    const glow = row.querySelector('.kco-glow');
    const slider = row.querySelector('.kco-p-vol');
    slider.addEventListener('input', () => {
      applyVolume(audioEl, slider);
    });

    let analyser = null, ctx = null, rafId = null;
    try {
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      const src = ctx.createMediaStreamSource(audioEl.srcObject);
      analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      src.connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);
      const loop = () => {
        analyser.getByteFrequencyData(data);
        let sum = 0;
        for (let i = 0; i < data.length; i++) sum += data[i];
        const level = sum / data.length / 255;
        glow.classList.toggle('speaking', level > 0.06);
        rafId = requestAnimationFrame(loop);
      };
      loop();
    } catch (e) {
      console.warn('[koetomo] participant analyser failed', e);
    }

    participants.set(audioEl, { joinedAt, label, ctx, rafId, row, slider });
    applyVolume(audioEl, slider);
    addLog(`${label} が入室しました`, 'join');
  }

  function applyVolume(audioEl, slider) {
    const individual = Math.min(1, slider.value / 100);
    audioEl.volume = Math.max(0, Math.min(1, individual * masterVolume));
  }

  function applyAllVolumes() {
    participants.forEach((p, audioEl) => applyVolume(audioEl, p.slider));
  }

  function detachParticipant(audioEl) {
    const p = participants.get(audioEl);
    if (!p) return;
    if (p.rafId) cancelAnimationFrame(p.rafId);
    if (p.ctx) p.ctx.close().catch(() => {});
    if (p.row) p.row.remove();
    participants.delete(audioEl);
    addLog(`${p.label} が退出しました（在室 ${fmtDuration(Date.now() - p.joinedAt)}）`, 'leave');
  }

  function scanForAudio(root) {
    if (!(root instanceof Element) && !(root instanceof Document)) return;
    const els = root.querySelectorAll ? root.querySelectorAll('audio') : [];
    els.forEach((el) => {
      if (el.srcObject && el.srcObject.getAudioTracks && el.srcObject.getAudioTracks().length > 0) {
        attachParticipant(el);
      }
    });
  }

  function startObserving() {
    scanForAudio(document);
    const mo = new MutationObserver((mutations) => {
      for (const m of mutations) {
        m.addedNodes.forEach((n) => {
          if (n.nodeType !== 1) return;
          scanForAudio(document);
          scanForAudio(n);
        });
        m.removedNodes.forEach((n) => {
          if (n.nodeType !== 1) return;
          if (n.tagName === 'AUDIO' && participants.has(n)) detachParticipant(n);
          if (n.querySelectorAll) {
            n.querySelectorAll('audio').forEach((el) => {
              if (participants.has(el)) detachParticipant(el);
            });
          }
        });
      }
    });
    mo.observe(document.documentElement, { childList: true, subtree: true });

    // srcObjectの遅延セットに追従するための保険の定期再走査(軽量)
    setInterval(() => scanForAudio(document), 2000);
  }

  window.addEventListener('koetomo:mic-level', (e) => {
    if (micLevelBar) micLevelBar.style.width = Math.min(100, Math.round(e.detail.level * 140)) + '%';
  });
  // fetch横取りで得た確実な参加者idリスト(推測探索より優先)
  window.addEventListener('koetomo:room-user-ids', (e) => {
    let ids = [];
    try {
      const parsed = typeof e.detail === 'string' ? JSON.parse(e.detail) : e.detail;
      ids = parsed.ids || [];
    } catch (err) {
      console.warn('[koetomo][ID解決] room-user-idsイベントの解析に失敗', err, e.detail);
      return;
    }
    ids.forEach((id) => {
      if (!roomMemberIds.includes(id)) roomMemberIds.push(id);
    });
    console.log('[koetomo][ID解決] fetch横取りでメンバーid取得:', ids);
    resolvePendingLabels();
  });

  window.addEventListener('koetomo:mute-changed', (e) => {
    micMuted = !!e.detail.muted;
    if (muteBtn) {
      muteBtn.classList.toggle('muted', micMuted);
      muteBtn.textContent = micMuted ? '🔇 ミュート解除' : '🎙 ミュートにする';
    }
  });

  function isCallPage() {
    return /\/talk-rooms\//.test(location.pathname);
  }

  // ---------- 常時表示の設定アイコン + 通話履歴 ----------
  const HISTORY_KEY = 'koetomoCallHistory';
  let miniGear, historyPanel;
  let currentCallStart = null;
  let currentRoomId = null;

  function saveHistoryEntry(entry) {
    if (!chrome?.storage?.local) return;
    chrome.storage.local.get(HISTORY_KEY, (res) => {
      const list = res[HISTORY_KEY] || [];
      list.unshift(entry);
      while (list.length > 100) list.pop(); // 軽量化のため直近100件のみ保持
      chrome.storage.local.set({ [HISTORY_KEY]: list });
    });
  }

  function buildMiniGear() {
    if (miniGear) return;
    miniGear = document.createElement('div');
    miniGear.id = 'koetomo-mini-gear';
    miniGear.textContent = '⚙';
    miniGear.style.cssText = `
      position: fixed; right: 10px; top: 10px; width: 42px; height: 42px; border-radius: 50%;
      background: rgba(30,30,34,0.9); color: #fff; display:flex; align-items:center; justify-content:center;
      cursor: pointer; z-index: 2147483647; font-size: 22px; box-shadow: 0 2px 8px rgba(0,0,0,0.5);
    `;
    document.documentElement.appendChild(miniGear);

    // ドラッグで移動可能に(クリックとドラッグを区別する)
    let dragging = false, moved = false, startX = 0, startY = 0;
    miniGear.addEventListener('mousedown', (e) => {
      dragging = true; moved = false; startX = e.clientX; startY = e.clientY;
      e.preventDefault();
    });
    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      if (Math.abs(e.clientX - startX) > 3 || Math.abs(e.clientY - startY) > 3) moved = true;
      if (!moved) return;
      const maxLeft = window.innerWidth - miniGear.offsetWidth - 4;
      const maxTop = window.innerHeight - miniGear.offsetHeight - 4;
      miniGear.style.left = Math.max(4, Math.min(maxLeft, e.clientX - 21)) + 'px';
      miniGear.style.top = Math.max(4, Math.min(maxTop, e.clientY - 21)) + 'px';
      miniGear.style.right = 'auto';
    });
    document.addEventListener('mouseup', () => {
      if (dragging && !moved) toggleHistoryPanel();
      dragging = false;
    });
  }

  function toggleHistoryPanel() {
    if (historyPanel) {
      historyPanel.remove();
      historyPanel = null;
      return;
    }
    historyPanel = document.createElement('div');
    historyPanel.id = 'koetomo-history-panel';
    historyPanel.style.cssText = `
      position: fixed; right: 40px; top: 8px; width: 280px; max-height: 70vh; overflow-y: auto;
      background: rgba(20,20,24,0.95); color: #eee; font-size: 12px; border-radius: 8px; padding: 10px;
      z-index: 2147483647; font-family: -apple-system, "Hiragino Kaku Gothic ProN", Meiryo, sans-serif;
      box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    `;
    historyPanel.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
        <div style="font-weight:600;">通話履歴（直近100件・端末ローカル保存）</div>
        <button id="koetomo-history-clear-all" style="background:#ed4245;border:none;color:#fff;border-radius:4px;padding:2px 6px;cursor:pointer;font-size:10px;">全削除</button>
      </div>
      <div id="koetomo-history-list">読み込み中…</div>
    `;
    document.documentElement.appendChild(historyPanel);

    historyPanel.querySelector('#koetomo-history-clear-all').addEventListener('click', () => {
      if (!confirm('通話履歴をすべて削除しますか？')) return;
      chrome.storage.local.set({ [HISTORY_KEY]: [] }, () => renderHistoryList());
    });

    function renderHistoryList() {
      if (!chrome?.storage?.local) return;
      chrome.storage.local.get(HISTORY_KEY, (res) => {
        const list = res[HISTORY_KEY] || [];
        const box = historyPanel.querySelector('#koetomo-history-list');
        if (list.length === 0) {
          box.textContent = '(まだ記録がありません)';
          return;
        }
        box.innerHTML = '';
        list.forEach((e, idx) => {
          const row = document.createElement('div');
          row.style.cssText = 'padding:4px 0;border-bottom:1px dashed rgba(255,255,255,0.08);display:flex;justify-content:space-between;align-items:flex-start;gap:6px;';
          row.innerHTML = `
            <div>ルーム ${e.roomId} ・ ${e.date}<br>入室 ${e.startTime} 〜 退室 ${e.endTime}（${e.duration}）</div>
            <button data-idx="${idx}" style="background:transparent;border:none;color:#888;cursor:pointer;font-size:12px;">✕</button>
          `;
          row.querySelector('button').addEventListener('click', () => {
            chrome.storage.local.get(HISTORY_KEY, (res2) => {
              const list2 = res2[HISTORY_KEY] || [];
              list2.splice(idx, 1);
              chrome.storage.local.set({ [HISTORY_KEY]: list2 }, () => renderHistoryList());
            });
          });
          box.appendChild(row);
        });
      });
    }
    renderHistoryList();
  }

  function startCallHistoryTracking() {
    const roomId = extractRoomId();
    if (!roomId || roomId === currentRoomId) return;
    currentRoomId = roomId;
    currentCallStart = new Date();
  }

  function endCallHistoryTracking() {
    if (!currentRoomId || !currentCallStart) return;
    const end = new Date();
    const durMs = end - currentCallStart;
    const min = Math.floor(durMs / 60000);
    const sec = Math.floor((durMs % 60000) / 1000);
    saveHistoryEntry({
      roomId: currentRoomId,
      date: currentCallStart.toLocaleDateString('ja-JP'),
      startTime: fmtTime(currentCallStart),
      endTime: fmtTime(end),
      duration: `${min}分${sec}秒`,
    });
    currentRoomId = null;
    currentCallStart = null;
  }

  function init() {
    if (!isCallPage() || panel) return;
    buildPanel();
    fetchRoomMemberIds().then(() => startObserving());
    startCallHistoryTracking();
    window.dispatchEvent(new CustomEvent('koetomo:query-mic-state'));
  }

  function initAlways() {
    buildMiniGear();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => { initAlways(); init(); });
  } else {
    initAlways();
    init();
  }

  let lastPath = location.pathname;
  setInterval(() => {
    if (location.pathname !== lastPath) {
      const wasCall = /\/talk-rooms\//.test(lastPath);
      lastPath = location.pathname;
      if (wasCall && !isCallPage()) endCallHistoryTracking();
      if (isCallPage()) {
        startCallHistoryTracking();
        if (!panel) init();
      }
    }
  }, 1000);
  window.addEventListener('beforeunload', endCallHistoryTracking);
})();
