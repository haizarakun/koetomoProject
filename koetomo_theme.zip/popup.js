const STORAGE_KEY = 'koetomoDarkMode';
const DEFAULT_STATE = { enabled: true, color: '#121212' };

const enabledToggle = document.getElementById('enabledToggle');
const customColor = document.getElementById('customColor');
const currentLabel = document.getElementById('currentLabel');
const swatches = document.querySelectorAll('.swatch');

function render(state) {
  enabledToggle.checked = state.enabled;
  customColor.value = state.color;
  currentLabel.textContent = `現在の色: ${state.color}`;
  swatches.forEach((s) => {
    s.classList.toggle('active', s.dataset.color.toLowerCase() === state.color.toLowerCase());
  });
}

function getState(cb) {
  chrome.storage.sync.get(STORAGE_KEY, (res) => {
    cb(res[STORAGE_KEY] || DEFAULT_STATE);
  });
}

function save(state) {
  chrome.storage.sync.set({ [STORAGE_KEY]: state });
  render(state);
}

getState(render);

enabledToggle.addEventListener('change', () => {
  getState((state) => {
    state.enabled = enabledToggle.checked;
    save(state);
  });
});

customColor.addEventListener('input', () => {
  getState((state) => {
    state.color = customColor.value;
    save(state);
  });
});

swatches.forEach((s) => {
  s.addEventListener('click', () => {
    getState((state) => {
      state.color = s.dataset.color;
      save(state);
    });
  });
});
