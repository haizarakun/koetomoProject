// koetomo 通話拡張: マイクフック (MAIN world)
//
// ページの navigator.mediaDevices.getUserMedia をラップし、実際に取得された
// マイクの MediaStreamTrack への参照を保持する。これにより:
//   - ミュート/ミュート解除 (track.enabled の切り替え)
//   - 自分の声の音量メーター (Web Audio の AnalyserNode)
// が、WebRTCのシグナリング自体には一切手を出さずに実現できる。
//
// ISOLATED world (call_overlay.js) とは直接オブジェクトを共有できないため、
// window に CustomEvent を投げてブリッジする。
(function () {
  if (window.__koetomoMicHookInstalled) return;
  window.__koetomoMicHookInstalled = true;

  let localStream = null;
  let audioCtx = null;
  let analyser = null;
  let levelTimer = null;

  // 実サイトがルーム参加者情報を取得する fetch("/api/users?ids[]=...") を横取りして
  // 現在の通話メンバーidを確実に取得する(ID:xxxxの解決を/api/rooms一覧の推測探索より確実にする)
  const origFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    try {
      const url = typeof input === 'string' ? input : input.url;
      if (url && url.includes('/api/users') && url.includes('ids%5B%5D=') || (url && url.includes('/api/users') && url.includes('ids[]='))) {
        const u = new URL(url, location.href);
        const ids = u.searchParams.getAll('ids[]').map((v) => Number(v)).filter((v) => !isNaN(v));
        if (ids.length > 0) {
          // MAIN world と ISOLATED world 間ではCustomEventのdetailに複雑なオブジェクトを
          // そのまま渡すと届かないことがあるため、文字列化して渡す
          window.dispatchEvent(new CustomEvent('koetomo:room-user-ids', { detail: JSON.stringify({ ids }) }));
        }
      }
    } catch (e) {
      // 監視自体の失敗はサイト動作に影響させない
    }
    return origFetch(input, init);
  };

  const origGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);

  navigator.mediaDevices.getUserMedia = async function (constraints) {
    const stream = await origGetUserMedia(constraints);
    if (constraints && constraints.audio && stream.getAudioTracks().length > 0) {
      localStream = stream;
      setupLocalAnalyser(stream);
      window.dispatchEvent(new CustomEvent('koetomo:mic-acquired'));
    }
    return stream;
  };

  function setupLocalAnalyser(stream) {
    try {
      if (audioCtx) audioCtx.close();
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioCtx.createMediaStreamSource(stream);
      analyser = audioCtx.createAnalyser();
      analyser.fftSize = 512;
      source.connect(analyser);
      startLevelLoop();
    } catch (e) {
      // AudioContextはユーザー操作前だと生成できないことがあるため、失敗しても致命的ではない
      console.warn('[koetomo] local analyser setup failed', e);
    }
  }

  function startLevelLoop() {
    if (levelTimer) clearInterval(levelTimer);
    const data = new Uint8Array(analyser.frequencyBinCount);
    levelTimer = setInterval(() => {
      if (!analyser) return;
      analyser.getByteFrequencyData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i++) sum += data[i];
      const level = sum / data.length / 255; // 0.0-1.0
      window.dispatchEvent(new CustomEvent('koetomo:mic-level', { detail: { level } }));
    }, 120);
  }

  // ISOLATED world側からのミュート指示を受ける
  window.addEventListener('koetomo:set-mute', (e) => {
    if (!localStream) return;
    const muted = !!(e.detail && e.detail.muted);
    localStream.getAudioTracks().forEach((t) => {
      t.enabled = !muted;
    });
    window.dispatchEvent(new CustomEvent('koetomo:mute-changed', { detail: { muted } }));
  });

  window.addEventListener('koetomo:query-mic-state', () => {
    const muted = localStream ? !localStream.getAudioTracks().some((t) => t.enabled) : null;
    window.dispatchEvent(new CustomEvent('koetomo:mute-changed', { detail: { muted } }));
  });
})();
