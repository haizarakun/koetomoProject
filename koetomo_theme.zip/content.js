// 声とも ダークモード content script
// SPA的に描画されるUIにも MutationObserver で追従して色を上書きする
(function () {
  const STORAGE_KEY = 'koetomoDarkMode';
  const DEFAULT_STATE = { enabled: true, color: '#121212' };
  const LUMINANCE_THRESHOLD = 0.55; // これより明るい背景色は暗色に置き換える
  const TEXT_LUMINANCE_THRESHOLD = 0.25; // これより暗い文字色は明るくする
  const LARGE_PANEL_RATIO = 0.2; // ビューポート面積比でこれを超える背景は色に関わらず暗色化
  const BASE_STYLE_ID = 'koetomo-dark-base-style';

  let currentColor = DEFAULT_STATE.color;
  let enabled = DEFAULT_STATE.enabled;
  let observer = null;
  let processed = new WeakSet();

  function hexToRgb(hex) {
    let h = hex.replace('#', '');
    if (h.length === 3) h = h.split('').map((c) => c + c).join('');
    const n = parseInt(h, 16);
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  }

  function relLuminance({ r, g, b }) {
    const a = [r, g, b].map((v) => {
      v /= 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2];
  }

  function parseRgbString(str) {
    if (!str) return null;
    const m = str.match(/rgba?\(\s*(\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\s*\)/);
    if (!m) return null;
    const alpha = m[4] === undefined ? 1 : parseFloat(m[4]);
    if (alpha === 0) return null; // 透明は無視
    return { r: +m[1], g: +m[2], b: +m[3] };
  }

  function textColorFor(bgHex) {
    // 選んだ背景色自体の明るさから、載せる文字色を決める（黒背景なら明るい文字）
    const lum = relLuminance(hexToRgb(bgHex));
    return lum > 0.4 ? '#111111' : '#e8e8e8';
  }

  function ensureBaseStyle() {
    let tag = document.getElementById(BASE_STYLE_ID);
    if (!tag) {
      tag = document.createElement('style');
      tag.id = BASE_STYLE_ID;
      (document.head || document.documentElement).appendChild(tag);
    }
    const fg = textColorFor(currentColor);
    tag.textContent = `
      html, body {
        background-color: ${currentColor} !important;
        color: ${fg} !important;
      }
      input, textarea, select {
        background-color: ${currentColor} !important;
        color: ${fg} !important;
      }
      ::selection { background: #3a3a40; }

      /* ヘッダー/ナビが背景と同化して見えなくなる問題への対策:
         強制的にコントラストを確保する */
      header, nav, [role="banner"], [class*="header" i], [class*="Header" i], [class*="navbar" i] {
        background-color: ${currentColor} !important;
        border-bottom: 1px solid rgba(255,255,255,0.08) !important;
      }
      header *, nav *, [role="banner"] *, [class*="header" i] *, [class*="Header" i] * {
        color: ${fg} !important;
      }
      header svg, nav svg, [role="banner"] svg, [class*="header" i] svg, [class*="Header" i] svg,
      header path, nav path, [role="banner"] path, [class*="header" i] path, [class*="Header" i] path {
        fill: ${fg} !important;
        stroke: ${fg} !important;
      }

      /* 全体的にDiscordらしい丸み・フォントへ寄せる(タグセレクタのみ・崩れにくい範囲で) */
      button, input, textarea, select, a[class] {
        border-radius: 8px !important;
      }
      img[class*="avatar" i], img[class*="icon" i], img[class*="profile" i] {
        border-radius: 50% !important;
      }
      body, button, input, textarea, select {
        font-family: "gg sans", "Yu Gothic UI", "Hiragino Kaku Gothic ProN", Meiryo, sans-serif !important;
      }
    `;
  }

  function removeBaseStyle() {
    const tag = document.getElementById(BASE_STYLE_ID);
    if (tag) tag.remove();
  }

  function darkenElement(el) {
    if (!(el instanceof Element) || processed.has(el)) return;
    if (el.id === BASE_STYLE_ID) return;

    const cs = getComputedStyle(el);
    const bg = parseRgbString(cs.backgroundColor);
    let sizeUnknown = false;
    if (bg) {
      let shouldOverride = relLuminance(bg) > LUMINANCE_THRESHOLD;
      if (!shouldOverride) {
        // 輝度は低くても、画面の大部分を覆う色付きパネル(青い通話背景など)は
        // ボタン等の意図的な配色とは区別して強制的に暗色化する
        const rect = el.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) {
          sizeUnknown = true; // まだ描画・レイアウトされていない → 後で再評価
        } else {
          const viewportArea = window.innerWidth * window.innerHeight;
          const area = rect.width * rect.height;
          if (viewportArea > 0 && area / viewportArea > LARGE_PANEL_RATIO) {
            shouldOverride = true;
          }
        }
      }
      if (shouldOverride) {
        el.style.setProperty('background-color', currentColor, 'important');
        el.style.setProperty('background-image', 'none', 'important');
      }
    }

    const fg = parseRgbString(cs.color);
    if (fg && relLuminance(fg) < TEXT_LUMINANCE_THRESHOLD) {
      el.style.setProperty('color', textColorFor(currentColor), 'important');
    }

    // 通話画面のミュート/スピーカー等のSVGアイコン(fill/stroke)にも追従
    const tag = el.tagName.toLowerCase();
    if (tag === 'svg' || tag === 'path' || tag === 'circle' || tag === 'rect') {
      const fill = parseRgbString(cs.fill);
      if (fill && relLuminance(fill) < TEXT_LUMINANCE_THRESHOLD) {
        el.style.setProperty('fill', textColorFor(currentColor), 'important');
      }
      const stroke = parseRgbString(cs.stroke);
      if (stroke && relLuminance(stroke) < TEXT_LUMINANCE_THRESHOLD) {
        el.style.setProperty('stroke', textColorFor(currentColor), 'important');
      }
    }

    if (!sizeUnknown) processed.add(el);
  }

  function scan(root) {
    if (!enabled || !root) return;
    if (root.nodeType === Node.ELEMENT_NODE) {
      darkenElement(root);
      if (root.shadowRoot) scan(root.shadowRoot);
    }
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
    let node = walker.nextNode();
    while (node) {
      darkenElement(node);
      if (node.shadowRoot) scan(node.shadowRoot); // open モードの Shadow DOM にも追従
      node = walker.nextNode();
    }
  }

  let fallbackTimer = null;
  function startFallbackRescan() {
    if (fallbackTimer) return;
    // 通話画面はcanvas/WebRTC由来の再描画が多く、MutationObserverが拾いきれない
    // ケースがあるため、軽い保険として定期的に再走査する（processed済みはスキップされるので低コスト）
    fallbackTimer = setInterval(() => {
      if (!enabled) return;
      scan(document.body || document.documentElement);
    }, 3000);
  }
  function stopFallbackRescan() {
    if (fallbackTimer) {
      clearInterval(fallbackTimer);
      fallbackTimer = null;
    }
  }

  function startObserver() {
    if (observer) return;
    observer = new MutationObserver((mutations) => {
      if (!enabled) return;
      for (const m of mutations) {
        m.addedNodes.forEach((n) => scan(n));
        if (m.type === 'attributes' && m.target) {
          processed.delete(m.target);
          darkenElement(m.target);
        }
      }
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['style', 'class'],
    });
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }

  function apply() {
    if (!enabled) {
      removeBaseStyle();
      stopObserver();
      stopFallbackRescan();
      return;
    }
    processed = new WeakSet();
    ensureBaseStyle();
    scan(document.body || document.documentElement);
    startObserver();
    startFallbackRescan();
  }

  function loadState(cb) {
    if (!chrome?.storage?.sync) {
      cb();
      return;
    }
    chrome.storage.sync.get(STORAGE_KEY, (res) => {
      const state = res[STORAGE_KEY] || DEFAULT_STATE;
      currentColor = state.color || DEFAULT_STATE.color;
      enabled = state.enabled !== false;
      cb();
    });
  }

  if (chrome?.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'sync' || !changes[STORAGE_KEY]) return;
      const state = changes[STORAGE_KEY].newValue || DEFAULT_STATE;
      currentColor = state.color || DEFAULT_STATE.color;
      enabled = state.enabled !== false;
      apply();
    });
  }

  function init() {
    loadState(apply);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
